package com.test;

import java.io.File;
import java.util.ArrayList;

import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Read_XL {
	
	@Test
	public ArrayList<String> fetchData(String fileLocation, String sheetname) throws Exception {
		fileLocation="D:\\\\PromoQA-Automation\\\\Test\\\\src\\\\main\\\\resources\\\\TestInput.xls";
		sheetname="TestInput";
		Workbook wb = null;
		String[][] dataTable = null;
		try {
			File f = new File(fileLocation);
			wb = Workbook.getWorkbook(f);
		}   catch (BiffException e) {
	        e.printStackTrace();
	    }
		
		// TO get the access to the sheet
		Sheet sh = wb.getSheet(sheetname);

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();


		//Get no of rows
		int totalNoOfRows = sh.getRows();
		//String dataRows[] = rowRange.split(",");
		
		ArrayList<String> rangeRequired = new ArrayList<>();

				for(int j=1; j<=totalNoOfRows; j++) {
					
					for(int i=0;i<=totalNoOfCols;i++) {
					String data=sh.getCell(0, j).toString();
					rangeRequired.add(data);
					System.out.println(data);
					}
					
				}			
			return rangeRequired;
		}
	}



package com.test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import com.actions.Base2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(utils.TestListener.class)

public class Report extends Base2 {
	
	public WebDriver driver;
	public Base2 action;
 
	
	@BeforeSuite
	public void verifyExcelReportASetupDriver() throws IOException {
		driver = setUpDriver();		
		action= new Base2();
	}

		@BeforeTest
		public void Login() { // This block is for Login method
			//action.setDriver(super.getDriver());
			action= new Base2();
			action.driver=driver;
			driver.get(
					"https://selfservetst.adb.org/OA_HTML/RF.jsp?function_id=31549&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&oas=JyjBWRUW5F3Onyf4SLatCQ..&params=y7NM-whTl8VKOg3FaPO9EagP1MB5tCIbSjH24MYQ88tmSeI3c9ElI0SNDd.mOw.n");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.id("unamebean")).sendKeys("Lnasi");
			driver.findElement(By.id("pwdbean")).sendKeys("testuser1234");
			driver.findElement(By.id("SubmitButton")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
			//Clicking on ADB TD Payments 
			 if (driver.findElements(By.xpath("//*[contains(text(), 'ADB TD Payments Administrator')]")).size()>0) {
				// clicking on ADB TD Payments Administrator
				driver.findElement(By.xpath("//*[contains(text(), 'ADB TD Payments Administrator')]")).click();
				action.impWait(30);
				}
		}

		@Test(priority = 1, groups="one") 
		public void testcase_4_1_1() {
			Reporter.log("===============Test case-4.1.1 validation started===============");
			action.waitForElement(By.id("N436"));
			action.scrolltoObject(By.id("N436"), "clicking on ADB Extracted Disbursement Vouchers Report");
			driver.findElement(By.id("N436")).click();
			action.impWait(30);
			// Entering Extract date
			action.type(By.id("N310"), "17-Mar-2022");
			// Clicking on continue
			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
			// Clicking on Submit
			driver.findElement(By.id("FndReqSubmit")).click();
			// Clicking on Ok button
			driver.findElement(By.xpath("//button[@title='&OK']")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Clicking on Refresh button
			driver.findElement(By.id("Refresh_uixr")).click();
			// Block for validation of Phase status
			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
						.getAttribute("textContent");
				boolean flag = false;
				while (!flag) {
					if (Phse == null) {
						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						driver.findElement(By.id("Refresh_uixr")).click();
						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
								.getAttribute("textContent");
					} else if (Phse.contains("Completed")) {
						Reporter.log(Phse);
						flag = true;
						break;
					} else {
						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						driver.findElement(By.id("Refresh_uixr")).click();
						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
								.getAttribute("textContent");
					}
				}
			}
			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);

		}

		@Test(priority = 2)
		public void testcase_4_1_2() {
			Reporter.log("===============Test case-4.1.2 validation started===============");
			action.scrolltoObject(By.id("N436"), "clicking on ADB Extracted Disbursement Vouchers Report");
			// clicking on ADB Extracted Disbursement Vouchers for Currency Purchase Report
			driver.findElement(By.id("N436")).click();
			// Entering Extract date
			action.type(By.id("N310"), "17-Mar-2022");		
			// clicking layout
			driver.findElement(By.id("Fndcplayoutlink")).click();
			// select PDF format
			// Clicking on continue
			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
			// Clicking on Submit
			driver.findElement(By.id("FndReqSubmit")).click();
			// Clicking on Ok button
			driver.findElement(By.xpath("//button[@title='&OK']")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Clicking on Refresh button
			driver.findElement(By.id("Refresh_uixr")).click();
			// Block for validation of Phase status & Output button
			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
						.getAttribute("textContent");
				boolean flag = false;
				while (!flag) {
					if (Phse == null) {
						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						driver.findElement(By.id("Refresh_uixr")).click();
						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
								.getAttribute("textContent");
					} else if (Phse.contains("Completed")) {
						Reporter.log(Phse);
						flag = true;
						break;
					} else {
						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						driver.findElement(By.id("Refresh_uixr")).click();
						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
								.getAttribute("textContent");
					}
				}
			}
			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");

			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		}

//		@Test(priority = 3)
//		public void testcase_4_1_3() {
//			Reporter.log("===============Test case-4.1.3 validation started===============");
//			action.scrolltoObject(By.id("N436"), "clicking on ADB Extracted Disbursement Vouchers Report");
//			// clicking on ADB Extracted Disbursement Vouchers for Currency Purchase Report
//			driver.findElement(By.id("N436")).click();
//			// Entering Extract date		
//			action.type(By.id("N310"), "17-Mar-2022");
//			// clicking layout
//			driver.findElement(By.id("Fndcplayoutlink")).click();
//			// select Excel format
//			action.type(By.xpath("//input[@title='Format']"), "EXCEL");
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//			// Block for validation of Phase status & Output button
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//		}
//
//		@Test(priority = 4, testName = "4.2.1-Currency purchase-pdf direct")
//		public void testcase_4_2_1() {
//			Reporter.log("===============Test case-4.2.1 validation started===============");
//			action.scrolltoObject(By.id("N430"), "ADB Extracted Disbursement Vouchers for Currency Purchase Report");
//			// clicking on ADB Extracted Disbursement Vouchers for Currency Purchase Report
//			driver.findElement(By.id("N430")).click();
//			// Entering Extract date
//			action.type(By.id("N310"), "17-Mar-2022");
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//			// Block for validation of Output status
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//		}
//
//		@Test(priority = 5, testName = "4.2.2-Currency purchase-Layout_PDF")
//		public void testcase_4_2_2() {
//			Reporter.log("===============Test case-4.2.2 validation started===============");
//			action.scrolltoObject(By.id("N430"), "ADB Extracted Disbursement Vouchers for Currency Purchase Report");
//			// clicking on ADB Extracted Disbursement Vouchers for Currency Purchase Report
//			driver.findElement(By.id("N430")).click();
//			// Entering Extract date
//					action.type(By.id("N310"), "17-Mar-2022");
//			// clicking layout
//			driver.findElement(By.id("Fndcplayoutlink")).click();
//			// select PDF format
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//			// Block for validation of Phase status & Output button
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//		}
//
//		@Test(priority = 6, testName = "4.2.3-Currency purchase-Layout_Excel")
//		public void testcase_4_2_3() {
//			Reporter.log("===============Test case-4.2.3 validation started===============");
//			action.scrolltoObject(By.id("N430"), "ADB Extracted Disbursement Vouchers for Currency Purchase Report");
//			// clicking on ADB Extracted Disbursement Vouchers for Currency Purchase Report
//			driver.findElement(By.id("N430")).click();
//			// Entering Extract date
//					action.type(By.id("N310"), "17-Mar-2022");
//			// clicking layout
//			driver.findElement(By.id("Fndcplayoutlink")).click();
//			// select Excel format
//					action.type(By.xpath("//input[@title='Format']"), "EXCEL");
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//			// Block for validation of Phase status & Output button
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//		}
//
//		@Test(priority = 7, testName = "4.3.1-DisbVouchers-paramerts")
//		public void testcase_4_3_1() {
//			Reporter.log("===============Test case-4.3.1 validation started===============");
//			action.scrolltoObject(By.id("N430"), "ADB Processed Disbursement Vouchers Report");
//
//			// clicking on ADB Processed Disbursement Vouchers Report
//			driver.findElement(By.id("N484")).click();
//
//			// waitForElement(By.id("N310"));
//			// Processed date from
//			action.type(By.id("N310"), "05-May-2022");
//			// Processed date to
//			action.type(By.id("N311"), "05-May-2022");
//			// Value Date from
//			action.type(By.id("N312"), "01-May-2022");
//			// Value Date to
//			action.type(By.id("N313"), "30-May-2022");
//			// Product
//			action.type(By.id("N314"), "LOAN");
//			// Remitted currency
//			action.type(By.id("N315"), "USD");
//			// Entering Remit amount from
//			action.type(By.id("N316"), "1000");
//			// Entering Remit amount To
//			action.type(By.id("N317"), "1000000");
//			// Entering Remit USD from
//			action.type(By.id("N318"), "1000");
//			// Entering Remit USD To
//			action.type(By.id("N319"), "1000000");
//			// Cost currency
//			action.type(By.id("N3110"), "USD");
//			// cost amount range from
//			action.type(By.id("N3111"), "1000");
//			// cost amount range to
//			action.type(By.id("N3112"), "1000000");
//			// cost USD amount range from
//			action.type(By.id("N3113"), "1000");
//			// cost USD amount range to
//			action.type(By.id("N3114"), "1000000");
//			// Status
//			action.type(By.id("N3115"), "PAYMENT PROCESSING IN PROGRESS");
//			// Paymode
//			action.type(By.id("N3116"), "SWIFT");
//
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//
//			// Block for validation of Phase status and Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//		}
//
//		@Test(priority = 8, testName = "4.3.2-DisbVouchers-paramerts-pdf direct")
//		public void testcase_4_3_2() {
//			Reporter.log("===============Test case-4.3.2 validation started===============");
//
//			action.scrolltoObject(By.id("N430"), "ADB Processed Disbursement Vouchers Report");
//
//			// clicking on ADB Processed Disbursement Vouchers Report
//			driver.findElement(By.id("N484")).click();
//
//			// waitForElement(By.id("N310"));
//			// Processed date from
//			action.type(By.id("N310"), "05-May-2022");
//			// Processed date to
//			action.type(By.id("N311"), "05-May-2022");
//
//			// clicking layout
//			driver.findElement(By.id("Fndcplayoutlink")).click();
//			// select PDF format
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//
//			// Block for validation of Phase status and Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//		}
//
//		@Test(priority = 9, testName = "4.3.3-DisbVouchers-paramerts-excel")
//		public void testcase_4_3_3() {
//			Reporter.log("===============Test case-4.3.3 validation started===============");
//
//			action.scrolltoObject(By.id("N430"), "ADB Processed Disbursement Vouchers Report");
//
//			// clicking on ADB Processed Disbursement Vouchers Report
//			driver.findElement(By.id("N484")).click();
//
//			// waitForElement(By.id("N310"));
//			// Processed date from
//			action.type(By.id("N310"), "05-May-2022");
//			// Processed date to
//			action.type(By.id("N311"), "05-May-2022");
//
//			// clicking layout
//			driver.findElement(By.id("Fndcplayoutlink")).click();
//			// select excel format
//			action.type(By.xpath("//input[@title='Format']"), "EXCEL");
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//
//			// Block for validation of Phase status and Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//		}
//
//		@Test(priority = 10, testName = "4.4.1-ReconcilationTrans")
//		public void testcase_4_4_1() {
//			Reporter.log("===============Test case-4.4.1 validation started===============");
//
//			action.scrolltoObject(By.id("N424"), "ADB End Of Day Reconciliation Of Transactions Processed");
//
//			// clicking on ADB Processed Disbursement Vouchers Report
//			driver.findElement(By.id("N424")).click();
//
//			// waitForElement(By.id("N310"));
//			// Processed date
//			action.type(By.id("N310"), "05-May-2022");
//
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//
//			// Block for validation of Phase status and Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//			Reporter.log("==================Test case completed==================");
//
//		}
//
//		@Test(priority = 11, testName = "4.4.2-ReconcilationTrans-pdf direct")
//		public void testcase_4_4_2() {
//			Reporter.log("===============Test case-4.4.2 validation started===============");
//
//			action.scrolltoObject(By.id("N424"), "ADB End Of Day Reconciliation Of Transactions Processed");
//
//			// clicking on ADB Processed Disbursement Vouchers Report
//			driver.findElement(By.id("N424")).click();
//
//			// waitForElement(By.id("N310"));
//			// Processed date
//			action.type(By.id("N310"), "05-May-2022");
//
//			// clicking layout
//			driver.findElement(By.id("Fndcplayoutlink")).click();
//			// select PDF format
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//
//			// Block for validation of Phase status and Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//			Reporter.log("==================Test case completed==================");
//		}
//
//		@Test(priority = 12, testName = "4.4.3-DisbVouchers-paramerts-excel")
//		public void testcase_4_4_3() {
//			Reporter.log("===============Test case-4.4.3 validation started===============");
//
//			action.scrolltoObject(By.id("N424"), "ADB End Of Day Reconciliation Of Transactions Processed");
//
//			// clicking on ADB Processed Disbursement Vouchers Report
//			driver.findElement(By.id("N424")).click();
//
//			// waitForElement(By.id("N310"));
//			// Processed date
//			action.type(By.id("N310"), "05-May-2022");
//
//			// clicking layout
//			driver.findElement(By.id("Fndcplayoutlink")).click();
//			// select EXCEL format
//			action.type(By.xpath("//input[@title='Format']"), "EXCEL");
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//
//			// Block for validation of Phase status and Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//			Reporter.log("==================Test case completed==================");
//		}
//
//		@Test(priority = 13, testName = "4.5.1-FundingReqReport")
//		public void testcase_4_5_1() {
//
//			Reporter.log("===============Test case-4.5.1 validation started===============");
//
//		action.scrolltoObject(By.id("N448"), "ADB Funding Requirements Report");
//
//		// clicking on ADB Fund Req Report
//		driver.findElement(By.id("N448")).click();
//
//		// Enter Parameters
//		// Cost bank
//		String cost="0-800471-001";
//		action.type(By.id("N310"),cost );
//		// date
//		String date="09-May-2022";
//		action.type(By.id("N311"), date);
//		// Code from
//		String from="001";
//		action.type(By.id("N312"), from);
//		// Code to
//		String to ="152";
//		action.type(By.id("N313"), to );
//		// Level of detail
//		action.type(By.id("N314"), "Detail");
//
//		// Clicking on continue
//		driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//		// Clicking on Submit
//		driver.findElement(By.id("FndReqSubmit")).click();
//
//		// Clicking on Ok button
//		driver.findElement(By.xpath("//button[@title='&OK']")).click();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//		// Clicking on Refresh button
//		driver.findElement(By.id("Refresh_uixr")).click();
//
//		// Clicking details
//		if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//			String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//					.getAttribute("textContent");
//			boolean flag = false;
//			while (!flag) {
//				if (Phse == null) {
//					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//					driver.findElement(By.id("Refresh_uixr")).click();
//					Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//							.getAttribute("textContent");
//				} else if (Phse.contains("Completed")) {
//					Reporter.log(Phse);
//					flag = true;
//					break;
//				} else {
//					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//					driver.findElement(By.id("Refresh_uixr")).click();
//					Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//							.getAttribute("textContent");
//				}
//			}
//		}
//		action.waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
//		action.click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
//		action.click(By.xpath("//*[@id=\"paraHideShow\"]/div/a"), "show");
//		String details=driver.findElement(By.xpath("(//*[@id=\"paraHideShow\"]/div)[2]"))
//				.getAttribute("textContent");
//		Reporter.log(details);
//		
//		//Validation of details generated
//		String costt=driver.findElement(By.xpath("//span[@id='N71']")).getText();
//		String datee=driver.findElement(By.xpath("//span[@id='N701']")).getText();
//		String Fromm=driver.findElement(By.xpath("//span[@id='N72']")).getText();
//		String Too=driver.findElement(By.xpath("//span[@id='N73']")).getText();
//		
//		Reporter.log("-------Below are Generated values in report------- ");
//		
//		Reporter.log("Cost Bank Account  is -"+costt);
//		if(cost.contains(costt)) {
//		     Reporter.log("Cost Bank Account  is generated in report is matching with given value i.e Expected Value is "+cost +"," +" Actual Value is "+costt);	
//		} else {
//			Reporter.log("Cost Bank Account  is generated in report is Not matching with given value "+cost);
//		}
//		
//		Reporter.log("Funded Date- value in report is -"+datee);
//		if(date.contains(datee)) {
//			  Reporter.log("Funded Date from generated in report is matching with given value i.e Expected Value is "+date +"," +" Actual Value is "+datee);
//		} else {
//			Reporter.log("Funded Date generated in report is Not matching with given value "+date);
//		}
//		
//		Reporter.log("Funded Code From	- value in report is -"+Fromm);
//		if(from.contains(Fromm)) {
//			  Reporter.log("Funded Code From generated in report is matching with given value i.e Expected Value is "+from +"," +" Actual Value is "+Fromm);
//		} else {
//			Reporter.log("Funded Code From generated in report is Not matching with given value "+from);
//		}
//		
//		Reporter.log("Funded Code To	- value in report is -"+Too);
//		if(to.contains(Too)) {
//			  Reporter.log("Funded Code To generated in report is matching with given value i.e Expected Value is "+to +"," +" Actual Value is "+to);
//		} else {
//			Reporter.log("Funded Code To generated in report is Not matching with given value "+Too);
//		}
//		
//		Reporter.log("==================Test case completed==================");
//		}
//
//		@Test(priority = 14, testName = "4.5.2--pdf ")
//		public void testcase_4_5_2() {
//			Reporter.log("===============Test case-4.5.2 validation started===============");
//
//			action.scrolltoObject(By.id("N448"), "ADB Funding Requirements Report");
//
//			// clicking on ADB Fund Req Report
//			driver.findElement(By.id("N448")).click();
//
//			// date
//			action.type(By.id("N311"), "09-May-2022");
//
//			// Level of detail
//			action.type(By.id("N314"), "Detail");
//
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on details
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
//			action.click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
//
//			// back to req
//			action.click(By.xpath("//a[@id='ReturnToRequests']"), "back");
//
//			action.click(By.xpath("//a[@id='N3:item111:0']//img"), "Republish");
//
//			action.type(By.xpath("//input[@id='Fndcplayformatname']"), "PDF");
//
//			action.click(By.xpath("//button[@id='SaveButton_uixr']"), "Apply");
//
//			action.click(By.xpath("//button[@id='OKButton']"), "Ok");
//
//			// Click Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//			Reporter.log("==================Test case completed==================");
//		}
//
//		@Test(priority = 15, testName = "4.5.3-excel")
//		public void testcase_4_5_3() {
//			Reporter.log("===============Test case-4.5.3 validation started===============");
//
//			action.scrolltoObject(By.id("N448"), "ADB Funding Requirements Report");
//
//			// clicking on ADB Fund Req Report
//			driver.findElement(By.id("N448")).click();
//
//			// date
//			action.type(By.id("N311"), "09-May-2022");
//
//			// Level of detail
//			action.type(By.id("N314"), "Detail");
//
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on details
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
//			action.click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
//
//			// back to req
//			action.click(By.xpath("//a[@id='ReturnToRequests']"), "back");
//
//			action.click(By.xpath("//a[@id='N3:item111:0']//img"), "Republish");
//
//			action.type(By.xpath("//input[@id='Fndcplayformatname']"), "EXCEL");
//
//			action.click(By.xpath("//button[@id='SaveButton_uixr']"), "Apply");
//
//			action.click(By.xpath("//button[@id='OKButton']"), "Ok");
//
//			// Click Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//			Reporter.log("==================Test case completed==================");
//		}
//		
//		
//		@Test(priority = 16, testName = "4.6.1-FundingReqReport")
//		public void testcase_4_6_1() {
//
//			Reporter.log("===============Test case-4.6.1 validation started===============");
//
//			action.scrolltoObject(By.id("N442"), "ADB Processed Disbursement Voucher Volume Report");
//
//			// clicking on ADB Fund Req Report
//			driver.findElement(By.id("N442")).click();
//
//			// Enter Parameters
//			// Process date from
//			String FromD="09-May-2022";
//			String ToD="09-May-2022";
//			action.type(By.id("N310"), FromD);
//			//  Process date to
//			action.type(By.id("N311"), ToD);
//			
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on Refresh button
//			driver.findElement(By.id("Refresh_uixr")).click();
//
//			// Clicking details
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
//			action.click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
//			action.click(By.xpath("//*[@id=\"paraHideShow\"]/div/a"), "show");
//			
//			//Validation of details generated
//			String details=driver.findElement(By.xpath("(//*[@id=\"paraHideShow\"]/div)[2]"))
//					.getAttribute("textContent");
//			Reporter.log(details);
//			
//			String From=driver.findElement(By.xpath("//span[@id='N700']")).getText();
//			String To=driver.findElement(By.xpath("//span[@id='N701']")).getText();
//			Reporter.log("-------Below are Generated values in report------- ");
//			Reporter.log("Processed Date From- value in report is -"+From);
//			if(FromD.contains(From)) {
//			     Reporter.log("Processed Date from generated in report is matching with given value i.e Expected Value is "+FromD +"," +" Actual Value is "+From);	
//			} else {
//				Reporter.log("Processed Date from generated in report is Not matching with given value "+From);
//			}
//			
//			Reporter.log("Processed Date To- value in report is -"+To);
//			if(ToD.contains(To)) {
//				  Reporter.log("Processed Date from generated in report is matching with given value i.e Expected Value is "+ToD +"," +" Actual Value is "+To);
//			} else {
//				Reporter.log("Processed Date To generated in report is Not matching with given value "+From);
//			}
//			
//			Reporter.log("==================Test case completed==================");
//
//		
//		}
//		
//		@Test(priority = 17, testName = "4.6.2-pdf")
//		public void testcase_4_6_2() {
//			Reporter.log("===============Test case-4.6.2 validation started===============");
//
//			action.scrolltoObject(By.id("N448"), "ADB Funding Requirements Report");
//
//			// clicking on ADB Fund Req Report
//			driver.findElement(By.id("N448")).click();
//
//			// Process date from
//					action.type(By.id("N310"), "09-May-2022");
//					//  Process date to
//					action.type(By.id("N311"), "09-May-2022");
//
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on details
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
//			action.click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
//
//			// back to req
//			action.click(By.xpath("//a[@id='ReturnToRequests']"), "back");
//
//			action.click(By.xpath("//a[@id='N3:item111:0']//img"), "Republish");
//
//			action.type(By.xpath("//input[@id='Fndcplayformatname']"), "PDF");
//
//			action.click(By.xpath("//button[@id='SaveButton_uixr']"), "Apply");
//
//			action.click(By.xpath("//button[@id='OKButton']"), "Ok");
//
//			// Click Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//			Reporter.log("==================Test case completed==================");
//		}
//		
//		@Test(priority = 18, testName = "4.6.3-excel")
//		public void testcase_4_6_3() {
//			Reporter.log("===============Test case-4.6.3 validation started===============");
//
//			action.scrolltoObject(By.id("N448"), "ADB Funding Requirements Report");
//
//			// clicking on ADB Fund Req Report
//			driver.findElement(By.id("N448")).click();
//
//			// Process date from
//					action.type(By.id("N310"), "09-May-2022");
//					//  Process date to
//					action.type(By.id("N311"), "09-May-2022");
//
//			// Clicking on continue
//			driver.findElement(By.xpath("(//button[@title='Continue'])[1]")).click();
//
//			// Clicking on Submit
//			driver.findElement(By.id("FndReqSubmit")).click();
//
//			// Clicking on Ok button
//			driver.findElement(By.xpath("//button[@title='&OK']")).click();
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//			// Clicking on details
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
//			action.click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
//
//			// back to req
//			action.click(By.xpath("//a[@id='ReturnToRequests']"), "back");
//
//			action.click(By.xpath("//a[@id='N3:item111:0']//img"), "Republish");
//
//			action.type(By.xpath("//input[@id='Fndcplayformatname']"), "EXCEL");
//
//			action.click(By.xpath("//button[@id='SaveButton_uixr']"), "Apply");
//
//			action.click(By.xpath("//button[@id='OKButton']"), "Ok");
//
//			// Click Output
//			if (driver.findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
//				String Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//						.getAttribute("textContent");
//				boolean flag = false;
//				while (!flag) {
//					if (Phse == null) {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					} else if (Phse.contains("Completed")) {
//						Reporter.log(Phse);
//						flag = true;
//						break;
//					} else {
//						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//						driver.findElement(By.id("Refresh_uixr")).click();
//						Phse = driver.findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
//								.getAttribute("textContent");
//					}
//				}
//			}
//			action.waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
//			action.click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");
//
//			driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
//
//			Reporter.log("==================Test case completed==================");
//		}

		@AfterMethod
		public void PDFValidate() {
			try {
				File dir = new File("Y:\\Abhipsa");
				File[] files = dir.listFiles();
				if (files == null || files.length == 0) {
					Reporter.log("There is no file in the folder");
				}

				File lastModifiedFile = files[0];
				for (int a = 1; a < files.length; a++) {
					if (lastModifiedFile.lastModified() < files[a].lastModified()) {
						lastModifiedFile = files[a];
					}
				}
				String k = lastModifiedFile.toString();
				System.out.println(lastModifiedFile);
				Path p = Paths.get(k);
				String file = p.getFileName().toString();
				Reporter.log("Generated file is " + file);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if (driver.findElements(By.xpath("(//a[@class='x15'][normalize-space()='Home'])[1]")).size() > 0) {
				// driver.findElement(By.xpath("//*[contains(text(),
				// 'Home')]")).click();
				driver.findElement(By.xpath("(//a[@class='x15'][normalize-space()='Home'])[1]")).click();
			}
	        
			 if (driver.findElements(By.xpath("//*[contains(text(), 'ADB TD Payments Administrator')]")).size()>0) {
			// clicking on ADB TD Payments Administrator
			driver.findElement(By.xpath("//*[contains(text(), 'ADB TD Payments Administrator')]")).click();
			}

		}

		@AfterTest
		public void Testclosure() {
			Reporter.log("Test Execution is completed");
		}

		@AfterClass
		public void closebrowser() {
			driver.close();
		}

	}

	
	



package com.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.actions.BaseMethods;
import com.dataprovider.DataProviderClass;
import ExtentReports.ExtentTestManager;

@Listeners(utils.TestListener.class)

public class verifyingDrivers extends BaseMethods {
	// Object creation for Actions Class
	//BaseMethods action = new BaseMethods();
	
	@Test(priority = 1, dataProvider = "getData", dataProviderClass = DataProviderClass.class) // ----for dataprovider
	public void drivers(String Username, String Password) throws Exception {
		ExtentTestManager.startTest("drivers").assignCategory("login");
		getDriver().get("https://www.gmail.com");
		getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		generateInfoReport(Username);
		generateInfoReport(Password);
		ExtentTestManager.endTest();

		/*
		 * @FindBy (how=How.CLASS_NAME,using="laptop-desktop-only") WebElement btn;
		 */
	}

	

}

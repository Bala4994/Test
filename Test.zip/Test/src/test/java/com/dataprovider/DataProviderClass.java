package com.dataprovider;

import org.testng.annotations.DataProvider;

import com.excelread.excelReading;

public class DataProviderClass {
	
	@DataProvider
	public static String[][] getData() throws Exception {

		return excelReading.fetchData("D:\\Testing\\Automation\\Frmwrk\\Maven-TestNG-FrameWork-With-DataProvider-ExcelRead\\Test\\src\\main\\resources\\TestInput.xls", "Drivers");

	}
}

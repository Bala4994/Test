package com.actions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;

import com.relevantcodes.extentreports.LogStatus;
import utils.Logs;

import ExtentReports.ExtentManager;
import ExtentReports.ExtentTestManager;
import utils.Reporting;

public class BaseMethods {
	private String LEFTBOLDTAG = "<b style=\"color:  green;\"/>";
	private String RIGHTBOLDTAG = "</b>";
	public WebDriver driver;
	
	
//	public void setDriver(WebDriver driver) {
//		this.driver = driver;
//		SetUp();
//	}
//	
//	public void SetUp() {
//		System.setProperty("webdriver.chrome.driver",	"C:\\Users\\BaLU\\Downloads\\chromedriver_win32\\chromedriver.exe");
//		driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		//driver.manage().window().maximize();
//	}
//
//	
//	public WebDriver getDriver() {
//		return this.driver;
//	}

	
	
	public WebDriverWait wait;

	public WebDriver getDriver() {
		return driver;
	}

	@BeforeClass
	public void setup() {
		System.setProperty("webdriver.chrome.driver",	"C:\\Users\\BaLU\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();

		wait = new WebDriverWait(driver, 15);
		
		driver.manage().window().maximize();
		
		System.out.println(driver);
		}

	@AfterClass
	public void teardown() {
		driver.quit();
	}
	
	

	// ============Reporting=====
	public void generateInfoReport(String infoText) {
		ExtentTestManager.getTest().log(LogStatus.INFO, infoText);
		Logs.logAndConsole(infoText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

	}

	public void generateBoldInfo(String infoText) {
		ExtentTestManager.getTest().log(LogStatus.INFO, getBoldText(infoText));
		Logs.logAndConsole(
				getBoldText(infoText).replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

	}

	public void generatePassReportWithNoScreenShot(String passText) {
		ExtentTestManager.getTest().log(LogStatus.PASS, passText);
		Logs.logAndConsole(passText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
	}

	public void generateFailReport(String text) {
		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

		ExtentTestManager.getTest().log(LogStatus.FAIL, text);
		try {
			ExtentTestManager.getTest().log(LogStatus.FAIL,
					ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
		} catch (Exception e) {

		}
	}

	public void generatePassReportWithScreenShot(String text) {

		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n\n"));
		ExtentTestManager.getTest().log(LogStatus.PASS, text);
		ExtentTestManager.getTest().log(LogStatus.PASS, ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
	}

	private String getScreenshot() {
		String destination = null;
		try {
//			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
//			TakesScreenshot ts = (TakesScreenshot) driver;
//			File source = ts.getScreenshotAs(OutputType.FILE);
//			destination = "Screenshots/" + String.valueOf(System.nanoTime()) + dateName + ".png";
//			File finalDestination = new File(ExtentManager.reportLocation + "/" + destination);
//			FileUtils.copyFile(source, finalDestination);

		} catch (Exception e) {
		}
		return destination;
	}

	public String getBoldText(String data) {
		return LEFTBOLDTAG + data + RIGHTBOLDTAG;
	}

}

package ExtentReports;

import java.io.IOException;
import java.util.Date;
import java.util.List;

//import com.galenframework.reports.GalenTestInfo;
//import com.galenframework.reports.HtmlReportBuilder;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {
    static ExtentReports extent;
   
    public final static String reportLocation  = "Reports/Automation_Reports_" + (new Date()).toString().replace(":", "_").replace(" ", "_");
    final static String filePath  = reportLocation+"/SummaryReport.html";
    public synchronized static ExtentReports getReporter() {
        if (extent == null) {
            extent = new ExtentReports(filePath, true);
        }
        
        return extent;
    }
    
    
    
    
}

package utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.relevantcodes.extentreports.LogStatus;

import ExtentReports.ExtentManager;
import ExtentReports.ExtentTestManager;

public class Reporting {
	private String LEFTBOLDTAG = "<b style=\"color:  green;\"/>";
	private String RIGHTBOLDTAG = "</b>";
	public void generateInfoReport(String infoText) {
		ExtentTestManager.getTest().log(LogStatus.INFO, infoText);
		Logs.logAndConsole(infoText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

	}

	public void generateBoldInfo(String infoText) {
		ExtentTestManager.getTest().log(LogStatus.INFO, getBoldText(infoText));
		Logs.logAndConsole(
				getBoldText(infoText).replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

	}

	public void generatePassReportWithNoScreenShot(String passText) {
		ExtentTestManager.getTest().log(LogStatus.PASS, passText);
		Logs.logAndConsole(passText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
	}

	public void generateFailReport(String text) {
		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

		ExtentTestManager.getTest().log(LogStatus.FAIL, text);
		try {
			ExtentTestManager.getTest().log(LogStatus.FAIL,
					ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
		} catch (Exception e) {

		}
	}

	public void generatePassReportWithScreenShot(String text) {

		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n\n"));
		ExtentTestManager.getTest().log(LogStatus.PASS, text);
		ExtentTestManager.getTest().log(LogStatus.PASS, ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
	}

	private String getScreenshot() {
		String destination = null;
		try {
//			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
//			TakesScreenshot ts = (TakesScreenshot) driver;
//			File source = ts.getScreenshotAs(OutputType.FILE);
//			destination = "Screenshots/" + String.valueOf(System.nanoTime()) + dateName + ".png";
//			File finalDestination = new File(ExtentManager.reportLocation + "/" + destination);
//			FileUtils.copyFile(source, finalDestination);

		} catch (Exception e) {
		}
		return destination;
	}

	public String getBoldText(String data) {
		return LEFTBOLDTAG + data + RIGHTBOLDTAG;
	}

}

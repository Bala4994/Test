package org.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.utils.ExtentReport;



public class Base {
	public WebDriver driver;
	public Properties prop;
	public static boolean isDownloadable = true;
	public boolean isPdf;
	//public boolean isExcelValidate;
	private String LEFTBOLDTAG = "<b style=\"color:  green;\"/>";
	private String RIGHTBOLDTAG = "</b>";
	
	public WebDriver getDriver() {
		return this.driver;
	}
	
	

	public WebDriver setUpDriver() throws IOException {
		prop = new Properties();
		FileInputStream fin = new FileInputStream(System.getProperty("user.dir")
				+ "\\src\\main\\resources\\config.properties");
		//FileInputStream fin = new FileInputStream(System.getProperty("C:\\Users\\BIH\\Downloads\\ADBAutomationEnhance\\src\\main\\resources\\config.properties"));
		prop.load(fin);
		String browserChoosen = prop.getProperty("browser");
		if (browserChoosen.equals("chrome")) {
		
			System.setProperty("webdriver.chrome.driver",	System.getProperty("user.dir")+ "\\src\\main\\resources\\Drivers\\chromedriver.exe");
			driver = getDriverWithDesiredCapability();

		} else if (browserChoosen.equals("edge")) {

			System.setProperty("webdriver.edge.driver",
					System.getProperty("user.dir") + "\\webdrivers\\msedgedriver.exe");
			driver = new EdgeDriver();
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}

	public WebDriver getDriverWithDesiredCapability() {
		if (isDownloadable) {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");
			HashMap<String, Object> prefs = new HashMap<String, Object>();
			if (isPdf) {
				prefs.put("download.default_directory", System.getProperty("user.dir")+"\\downloadedReports\\PDF");
				prefs.put("plugins.always_open_pdf_externally", true);
			} else {
				prefs.put("download.default_directory", System.getProperty("user.dir")+"\\downloadedReports\\Excel");
			}

			options.setExperimentalOption("prefs", prefs);
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(cap);
		} else {
			driver = new ChromeDriver();
		}

		return driver;
	}
	
	public void takeScreenShot(String testCaseName, WebDriver driver, boolean isFailed) throws IOException
	{
		TakesScreenshot ts =(TakesScreenshot) driver;
		String ScreenShotPath;
		File source = ts.getScreenshotAs(OutputType.FILE);
		if(isFailed) {
			 ScreenShotPath = System.getProperty("user.dir")+"\\ScreenShotsReports\\Failed\\"+testCaseName+".png";
		} else {
			 ScreenShotPath = System.getProperty("user.dir")+"\\ScreenShotsReports\\Success\\"+testCaseName+".png";
		}
		
		FileUtils.copyFile(source,new File(ScreenShotPath));
	}
	
	public boolean scrolltoObject(By by, String locator) {
		Exception e1 = null;
		boolean flag = false;
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			int yPosition = driver.findElement(by).getLocation().getY();
			js.executeScript(new StringBuilder().append("window.scroll(300,")
					.append(yPosition - driver.manage().window().getSize().getHeight() / 2).append(")").toString(),
					new Object[0]);
			flag = true;
		} catch (Exception e) {
			e1 = e;
			flag = false;
		} finally {
			System.out.println("Scrolling to Object " + flag);
		}
		return flag;

	}

	public boolean waitForElement(By by) {
		try {
			// WebDriverWait wait = new WebDriverWait(driver,
			// Integer.parseInt(getProperty("waitForElementTimeOut").trim()));
			StaticWait(1);
			WebDriverWait wait = new WebDriverWait( driver, 30);
			WebElement element = (WebElement) wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			System.out.println("element is displayed");
			return element.isDisplayed();
		} catch (Exception e) {
			StaticWait(2);
			//waitForPageLoad(5);
			try {
				WebDriverWait wait = new WebDriverWait( driver, 30);
				WebElement element = (WebElement) wait.until(ExpectedConditions.visibilityOfElementLocated(by));

				return element.isDisplayed();
			} catch (Exception localException1) {
			}

		}
		return false;
	}

	public void waitForPageLoad(int seconds) {
		try {
			// if (getProperty("PageLoadStrategy").equalsIgnoreCase("none"))
			for (int i = 0; (i < seconds) && ((((Long) ((JavascriptExecutor) driver).executeScript("return jQuery.active", new Object[0])).longValue() != 0L)
					|| (!((JavascriptExecutor) driver).executeScript("return document.readyState", new Object[0])
							.toString().equals("complete"))); i++) {
				Thread.sleep(1000L);
			}
		} catch (Exception localException) {
		}
	}
	
	public boolean waitForPageLoad() {

		return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("loaded")
	            || ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
	}

	public boolean click(By locator, String locatorName) {
		String exception = "";
		boolean flag = false;

			try {
				waitForElement(locator);
				try {
					driver.findElement(locator).click();
					System.out.println("Click performed on "+locatorName);
				} catch (TimeoutException localTimeoutException) {
				} catch (ElementClickInterceptedException e) {

					try {
						driver.findElement(locator).click();
						System.out.println("Click performed on "+locatorName);
						flag = true;
					} catch (Exception e2) {
						System.out.println("Click not performed on "+locatorName);
						flag = false;
					}
				}
				flag = true;

			} catch (Exception e) {

			}
		return flag;
	}
	
	public void type(By by, String name) {
		//StaticWait(2);
		try {
			waitForElement(by);
			driver.findElement(by).clear();
			driver.findElement(by).sendKeys(name);
			System.out.println("Entered data "+name);
		} catch (Exception e) {
			System.out.println("Unable to enter data"+name);
		}
	}
	
	public void impWait(int i) {
		driver.manage().timeouts().implicitlyWait(i, TimeUnit.SECONDS);
	}
	
	public void StaticWait(int i)
	         {
	           try
	           {
	          Thread.sleep(i * 1000);
	           }
	           catch (Exception localException)
	           {
	           }
	         }
	
//	public void generateInfoReport(String infoText) {
//		ExtentTestManager.getTest().log(LogStatus.INFO, infoText);
//		Logs.logAndConsole(infoText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
//
//	}
//
//	public void generateBoldInfo(String infoText) {
//		ExtentTestManager.getTest().log(LogStatus.INFO, getBoldText(infoText));
//		Logs.logAndConsole(
//				getBoldText(infoText).replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
//
//	}
//
//	public void generatePassReportWithNoScreenShot(String passText) {
//		ExtentTestManager.getTest().log(LogStatus.PASS, passText);
//		Logs.logAndConsole(passText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
//	}
//
//	public void generateFailReport(String text) {
//		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
//
//		ExtentTestManager.getTest().log(LogStatus.FAIL, text);
//		try {
//			ExtentTestManager.getTest().log(LogStatus.FAIL,
//					ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
//		} catch (Exception e) {
//
//		}
//	}
//
//	public void generatePassReportWithScreenShot(String text) {
//
//		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n\n"));
//		ExtentTestManager.getTest().log(LogStatus.PASS, text);
//		ExtentTestManager.getTest().log(LogStatus.PASS, ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
//	}

	private String getScreenshot() {
		String destination = null;
		try {
//			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
//			TakesScreenshot ts = (TakesScreenshot) driver;
//			File source = ts.getScreenshotAs(OutputType.FILE);
//			destination = "Screenshots/" + String.valueOf(System.nanoTime()) + dateName + ".png";
//			File finalDestination = new File(ExtentManager.reportLocation + "/" + destination);
//			FileUtils.copyFile(source, finalDestination);

		} catch (Exception e) {
		}
		return destination;
	}

	public String getBoldText(String data) {
		return LEFTBOLDTAG + data + RIGHTBOLDTAG;
	}
	
	@BeforeSuite
	public void beforeSuite() {
		
	}
	
	@AfterSuite
public void afterSuite() {
		
	}
	
	@BeforeMethod
public void beforeMethod() {
		
	}
	
	@AfterMethod
public void afterMethod() {
		
	}
	
	
	

}

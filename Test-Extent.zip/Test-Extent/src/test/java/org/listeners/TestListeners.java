package org.listeners;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.Objects;

import org.common.Base;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.utils.ExtentReport;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


public class TestListeners  extends Base implements ITestListener, ISuiteListener{
	
	
	
	public void onStart(ISuite suite) {
		try {
			ExtentReport.startReport();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	

	public void onFinish(ISuite suite) {
		try {
			ExtentReport.endReport();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	

	public void onTestStart(ITestResult result) {
		ExtentReport.startTest(result.getMethod().getMethodName());
		
	}

	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
			 
				ExtentReport.test.pass(result.getMethod().getMethodName() +" is passed");
		
	}

	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
			
				ExtentReport.test.fail(result.getMethod().getMethodName() +" is Failed");
				//attach screenshot
		
	}

	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
				ExtentReport.test.skip(result.getMethod().getMethodName() +" is skipped");
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
	
}

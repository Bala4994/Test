package org.utils;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.Objects;

import org.common.Base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {
	
//	private ExtentReport() {
//		
//	}
	
	public  static ExtentReports extent;
	public static ExtentTest test;
	
	public static void startReport() throws Exception {
		//if(Objects.nonNull(extent)) {
		extent = new ExtentReports();
		final File CONF = new File("src\\main\\resources\\extentconfig.xml");
		ExtentSparkReporter spark = new ExtentSparkReporter("target/AutomationReport.html");
		spark.loadXMLConfig(CONF);

//		spark.config().setTheme(Theme.DARK);
//		spark.config().setDocumentTitle("MyReport");
//		spark.config().setReportName("Automation Report Gen");
		extent.attachReporter(spark);
	//}
	}
	
	public static void endReport() throws Exception {
		if(Objects.nonNull(extent)) {
		extent.flush();
		}
		Desktop.getDesktop().browse(new File("target/AutomationReport.html").toURI());
	}
	
	public static void startTest(String testName) {
		test=extent.createTest(testName);
		//use for test.pass test.fail etc--
	}
	
	public void Pass(String pass) {
		test.pass(pass);
		
		
	}
	
	
	
	
}

package com.extentreport;

import org.common.Base;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.utils.ExtentReport;


@Listeners(org.listeners.TestListeners.class)

public class Test1 extends Base{
	
	
	public WebDriver driver;
	public Base action;
 
	@BeforeSuite
	public void setUp() throws Exception {
		ExtentReport.startReport();
		
		driver = setUpDriver();		
		action= new Base();
	}
	
	
	@Test(priority=1)
	public void login() throws Exception {
	
	getDriver().get("https://www.gmail.com");
	
	
	}

}

package com.extentreport;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;
import org.common.*;
public class BasicExtentReport extends Base{
	public ExtentReports extent;
	public WebDriver driver;
	public Base action;
 
	@BeforeSuite
	public void setUp() throws Exception {
		extent = new ExtentReports();
		final File CONF = new File("src\\main\\resources\\extentconfig.xml");
		ExtentSparkReporter spark = new ExtentSparkReporter("target/AutomationReport.html");
		spark.loadXMLConfig(CONF);
		
		driver = setUpDriver();		
		action= new Base();
		
		
//		spark.config().setTheme(Theme.DARK);
//		spark.config().setDocumentTitle("MyReport");
//		spark.config().setReportName("Automation Report Gen");
		extent.attachReporter(spark);
	}
	
	
	@Test(priority=1)
	public void login() throws Exception {
	ExtentTest test=extent.createTest("login Test").assignCategory("Report1");
	getDriver().get("https://www.gmail.com");
	test.pass("login started");
	test.info("logged in with");
	test.info(MarkupHelper.createLabel("Login success", ExtentColor.GREEN));
	test.pass("Gmail opened", MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
	}
	
	@Test(priority=2)
	public void login1() throws Exception {	
	ExtentTest test1=extent.createTest("login Test1").assignCategory("Report1");
	getDriver().get("https://www.google.com");
	test1.fail("login failed");
	test1.info("logged in with");
	test1.info(MarkupHelper.createLabel("Login success", ExtentColor.RED));
	test1.pass("google opened", MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
	test1.fail("Gmail not opened", MediaEntityBuilder.createScreenCaptureFromBase64String(getScreenshotasBase64()).build());
	
	}
	
	@AfterSuite
	public void tearDown() throws Exception {
		extent.flush();
		Desktop.getDesktop().browse(new File("target/AutomationReport.html").toURI());
	}
	
	@AfterClass
	public void close() {
		getDriver().close();
	}
	
	public String getScreenshotPath() throws Exception {
		File source= ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		String path=System.getProperty("user.dir")+"/Screenshots/image.png";
		FileUtils.copyFile(source, new File(path));
		return path;
	}
	
	public String getScreenshotasBase64() throws Exception {
		File source= ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		String path=System.getProperty("user.dir")+"/Screenshots/image.png";
		FileUtils.copyFile(source, new File(path));
		byte[] imageBytes = IOUtils.toByteArray(new FileInputStream(path));
		
		return Base64.getEncoder().encodeToString(imageBytes);
	}
	
	public String getScrnshtasBase64() {
		return ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.BASE64);
	}
	
}
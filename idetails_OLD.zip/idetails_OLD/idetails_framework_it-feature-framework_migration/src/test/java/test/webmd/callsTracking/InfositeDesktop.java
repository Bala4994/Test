package test.webmd.callsTracking;
import org.openqa.selenium.By;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;
import com.webmd.automation.utilities.ExtentTestManager;
public class InfositeDesktop {
	public ActionMethods action;
	public Videos_Tracking videos=new Videos_Tracking();
	//public Videos_Tracking_idetails video=new Videos_Tracking_idetails();

	@BeforeClass(alwaysRun=true)
	public void startUpinfositeBrowser(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser();
		
	}
	
	@Test(dataProvider = "infositeData",priority=1, groups = {"infosite" },dataProviderClass=DataProviderClass.class)
	public void verifyInfositeProgramFunctionality(String TicketNumber,String SFID,String UserName,String Password,String TacticID,String PromoID,String ProgramURL,String environment) throws Exception{
		action.generateBoldInfo("Ticket Number : " + TicketNumber + "<br> SF ID : " +SFID + "<br>  Program URL  : " +ProgramURL ); 
		action.login(UserName,Password);
		action.startNewHar();
		action.get(ProgramURL);
		action.staticWait(6);
		/*action.generatePassReport("Sponsred Title:"+action.getText(By.xpath("//*[@class='header-statement']/span")));
		action.generateReport(action.getDriver().getTitle().equalsIgnoreCase("Information from Industry"), "Window Title Matched:"+action.getBoldText(action.getDriver().getTitle()), "Window Title Not Matched:"+action.getBoldText(action.getDriver().getTitle()));
		action.staticWait(3);
		action.VerifyInfositeLoadcall(SFID, environment);
		action.validateImages(action.getproxyServer(), environment,SFID);
		action.validateDoubleclickTags(action.getproxyServer(), environment,SFID);
		action.infositeapicalls(TacticID, PromoID, environment);
		action.clickOnInfositeinternalLinks(action.getDriver(), action.getproxyServer(), SFID, environment);
		action.VerifyinfositeArticlenavigation(action.getDriver(), action.getproxyServer(), SFID, environment, ProgramURL);
		action.infositedropoff(TacticID, PromoID, environment);*/
		//action.VerifyinfositeArticlenavigation(action.getDriver(), action.getproxyServer(), SFID, environment);
		
	}
	
	/*@Test(dataProvider = "infositeData",priority=2, groups = {"infosite" },dataProviderClass=DataProviderClass.class)
	public void verifyInfositeProgramPollFunctionality(String TicketNumber,String SFID,String UserName,String Password,String TacticID,String PromoID,String ProgramURL,String environment) throws Exception{
		action.VerifyInfositeMultipleFunctionalities_ByArticles(action.getDriver(), action, action.getproxyServer(), SFID, environment, "poll", ProgramURL);
	}
	@Test(dataProvider = "infositeData",priority=3, groups = {"infosite"},dataProviderClass=DataProviderClass.class)
	public void verifyInfositeProgramExternalLinksFunctionality(String TicketNumber,String SFID,String UserName,String Password,String TacticID,String PromoID,String ProgramURL,String environment) throws Exception{
		
		action.VerifyInfositeMultipleFunctionalities_ByArticles(action.getDriver(), action, action.getproxyServer(), SFID, environment, "extlinks", ProgramURL);
		
	}*/
	
	@Test(dataProvider = "infositeData",priority=4, groups = {"infosite"},dataProviderClass=DataProviderClass.class)
	public void verifyInfositeProgramVideoFunctionality(String TicketNumber,String SFID,String UserName,String Password,String TacticID,String PromoID,String ProgramURL,String environment) throws Exception{
		
		//action.VerifyInfositeMultipleFunctionalities_ByArticles(action.getDriver(), action, action.getproxyServer(), SFID, environment, "videos", ProgramURL);
		//videos.performMultipleVideoTracking(action.getDriver(), action);
		//videos.trackHeartBeatCallsForMultipleVideos(action.getDriver(), action, SFID);
		videos.performMultipleVideoTracking(action.getDriver(), action);
	}
	

	/*@Test(dataProvider = "infositeData",priority=5, groups = {"infosite" },dataProviderClass=DataProviderClass.class)
	public void verifyInfositeProgramVideoHeartBeatFunctionality(String TicketNumber,String SFID,String UserName,String Password,String TacticID,String PromoID,String ProgramURL,String environment) throws Exception{
		action.VerifyInfositeMultipleFunctionalities_ByArticles(action.getDriver(), action, action.getproxyServer(), SFID, environment, "hearbeatcalls", ProgramURL);
	
	}*/
	@AfterClass(alwaysRun=true)
	public void shutDowninfositeBrowser() throws Throwable {
		action.driver.quit();
		action.getproxyServer().stop();

	}
	
}

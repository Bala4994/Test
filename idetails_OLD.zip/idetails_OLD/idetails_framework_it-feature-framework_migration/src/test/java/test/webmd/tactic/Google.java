package test.webmd.tactic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
//import com.utility.Logs;
import com.webmd.automation.utilities.ExtentTestManager;

public class Google {
	public WebDriver driver;
	
		
	@BeforeSuite
	public void LoginPageTest(){
		ExtentTestManager.startTest("Sample");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\BaLU\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver(); 
		ExtentTestManager.endTest();
		
	}
	

	
	@Test(priority=1)
	public void loginPageTitleTest() throws Exception{
		ExtentTestManager.startTest("Test");
		
		driver.get("www.google.com");		
		Thread.sleep(3000);
		System.out.println("=======");
		
		
		ExtentTestManager.endTest();
	}
	
	
	
	
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}

}

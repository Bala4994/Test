package test.webmd.callsTracking;

import org.openqa.selenium.By;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;


public class IOSWebSGV {

	public ActionMethods action;

	@BeforeClass(alwaysRun=true)
	public void startUpSGVIOSBrowser(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser();
		
	}
	
	@Test(dataProvider = "getSGVData", groups = { "sgvios" },dataProviderClass=DataProviderClass.class)
	public void VerifySGVMobileIOSAdFunctionalTest(String SFID, String tacticID, String promoID, String SGVUserName,
			String SGVPassword, String layerOpenCall, String callAfter3Seconds, String layerCloseCall,
			String newsArticle, String emedicineArticle, String drugMonographArticle, String newsArticleName,
			String emedicineArticleName, String monographArticleName, String onsiteURL, String BrowserType, String env)
			throws Exception {
		action.IOSWeblogin(SGVUserName,SGVPassword);
		action.generatePassReport("================= News Article Verification Started ===========");
		action.startNewHar();
		action.get(newsArticle);
		action.validateSGVCallDisplayed(SFID, newsArticle);
		action.generatePassReport("Sponsred Title:"+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		action.validateImages(action.getproxyServer(), env,SFID);
		action.clickAllradioButtons(action.getDriver(), By.xpath("//*[@id='contentblock']//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.mobileSGVValuesValidations(SFID);
		action.validateAPICalls(tacticID, promoID,env);
		action.verifynoCacheTS3(SFID);
		action.testLayerLinksIosWeb(action.getDriver(), action.getproxyServer(), SFID, env);		
		action.startNewHar();
		action.click(By.id("agtCloseBtn"), "Close SGV Layer");
		action.verifyC20Values(action.getproxyServer(),"alm_cs,"+SFID);
		action.verifyNoCount(SFID);
		
		action.generatePassReport("=================  Emedicine Article Verification Started ===========");
		action.startNewHar();
		action.get(emedicineArticle);
		action.validateSGVCallDisplayed(SFID, emedicineArticle);
		action.generatePassReport("Sponsred Title:"+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		action.validateImages(action.getproxyServer(), env,SFID);
		action.clickAllradioButtons(action.getDriver(), By.xpath("//*[@id='contentblock']//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.mobileSGVValuesValidations(SFID);
		action.validateAPICalls(tacticID, promoID,env);
		action.verifynoCacheTS3(SFID);
		action.testLayerLinksIosWeb(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.click(By.id("agtCloseBtn"), "Close SGV Layer");
		action.verifyC20Values(action.getproxyServer(),"alm_cs,"+SFID);
		action.verifyNoCount(SFID);
		
		action.generatePassReport("=================  MonographArticle Article Verification Started ===========");
		action.startNewHar();
		action.get(drugMonographArticle);
		action.validateSGVCallDisplayed(SFID, drugMonographArticle);
		action.generatePassReport("Sponsred Title:"+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		action.validateImages(action.getproxyServer(), env,SFID);
		action.clickAllradioButtons(action.getDriver(), By.xpath("//*[@id='contentblock']//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.mobileSGVValuesValidations(SFID);
		action.validateAPICalls(tacticID, promoID,env);
		action.verifynoCacheTS3(SFID);
		action.testLayerLinksIosWeb(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.click(By.id("agtCloseBtn"), "Close SGV Layer");
		action.verifyC20Values(action.getproxyServer(),"alm_cs,"+SFID);
		action.verifyNoCount(SFID);
	}

	
	

	@AfterClass(alwaysRun=true)
	public void shutDownSGVIOSBrowser() throws Throwable {
		action.driver.quit();

	}

}

package test.webmd.callsTracking;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;

@Listeners(com.webmd.automation.utilities.Listener.class)
public class IOSAppSGV {

	public ActionMethods action;

	@BeforeClass
	public void startUpLogin(ITestContext ctx) throws Throwable {
		
		action = new ActionMethods(ctx);
		action.launchBrowser();
		//action.driver.manage().deleteAllCookies();
		//AppiumDriver driver=new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
		
	}

	@Test(dataProvider = "getSGVData", groups = { "mobile", "sgv" },dataProviderClass=DataProviderClass.class)
	public void VerifySGVMobileIOSappAdFunctionalTest(String SFID, String tacticID, String promoID, String SGVUserName,
			String SGVPassword, String layerOpenCall, String callAfter3Seconds, String layerCloseCall,
			String newsArticle, String emedicineArticle, String drugMonographArticle, String newsArticleName,
			String emedicineArticleName, String monographArticleName, String onsiteURL, String BrowserType, String env)
			throws Exception {
		
		action.IOSapplogin(SGVUserName,SGVPassword );
		action.generatePassReport("================= News Article Verification Started ===========");
		action.startNewHar();
		action.click(By.xpath("(//*[@text='Main_NavBar']/*[@class='UIAButton'])[1]"), "clicking on NEWS and Perspective");
		action.click(By.xpath("//*[@text='News & Perspective']"), "clicking on NEWS and Perspective search box");
		action.click(By.xpath("//*[@placeholder='Search Medscape']"), "clicking on search button");
		action.getDriver().findElement(By.xpath("//*[@placeholder='Search News & Perspective']")).sendKeys(newsArticleName);
		action.click(By.xpath("//*[@text='Search']"), "Clicking on Search button");
		
		WebDriverWait wait = new WebDriverWait(action.getDriver(),30);
		
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='"+newsArticleName+"']")));
		action.click(By.xpath("//*[@text='"+newsArticleName+"']"), "Clicking on  News article");
		Thread.sleep(5000);
		action.validateAPICalls(BrowserType, BrowserType, env);
			
		action.testLayerLinksAndroidApp(action.getDriver(), action.getproxyServer(), SFID, env);	
		action.click(By.xpath("//*[@text='Close']"), "Clicking on close button");
		
		action.generatePassReport("=================  Emedicine Article Verification Started ===========");
		
		action.startNewHar();
		action.click(By.xpath("//*[@text='nav back']"), "navigating back");
		action.click(By.xpath("//*[@text='Drugs &  Diseases']"), "clicking on Drugs & Diseases");
		action.click(By.xpath("//*[@text='Clear text']"), "Clearing the text in Testbox");
		action.getDriver().findElement(By.xpath("//*[@placeholder='Search Drugs & Diseases']")).sendKeys(emedicineArticleName);
		action.click(By.xpath("//*[@accessibilityLabel='Search']"), "Clicking on Search button");
	    wait = new WebDriverWait(action.getDriver(),30);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='"+emedicineArticleName+"']")));
		action.click(By.xpath("//*[@text='"+emedicineArticleName+"']"), "Clicking on  emedicine article");
		Thread.sleep(5000);
		action.validateAPICalls(BrowserType, BrowserType, env);
		
		action.testLayerLinksAndroidApp(action.getDriver(), action.getproxyServer(), SFID, env);	
		
		action.click(By.xpath("//*[@text='Close']"), "Clicking on close button");
		
		action.generatePassReport("=================  MonographArticle Article Verification Started ===========");
		action.startNewHar();
		action.click(By.xpath("//*[@text='nav back']"), "navigating back");
		action.click(By.xpath("//*[@text='Clear text']"), "Clearing the text in Testbox");
		action.getDriver().findElement(By.xpath("//*[@placeholder='Search Drugs & Diseases']")).sendKeys(monographArticleName);
		action.click(By.xpath("//*[@accessibilityLabel='Search']"), "Clicking on Search button");
	    wait = new WebDriverWait(action.getDriver(),30);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='"+monographArticleName+"']")));
		action.click(By.xpath("//*[@text='"+monographArticleName+"']"), "Clicking on monograph article");
		Thread.sleep(5000);
		action.validateAPICalls(BrowserType, BrowserType, env);
		
		action.testLayerLinksAndroidApp(action.getDriver(), action.getproxyServer(), SFID, env);	
		
		action.click(By.xpath("//*[@text='Close']"), "Clicking on close button");
	}
	
	
	@AfterClass
	public void shutDownLogin() throws Throwable {
		action.driver.quit();
	}
}
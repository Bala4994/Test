
package test.webmd.callsTracking;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;
import com.webmd.automation.utilities.Logs;

import io.appium.java_client.AppiumDriver;

@Listeners(com.webmd.automation.utilities.Listener.class)
public class IOSAppHeadLine {

	public ActionMethods action;

	@BeforeClass(alwaysRun=true)
	
public void startUpLogin(ITestContext ctx) throws Throwable {
		
		action = new ActionMethods(ctx);
		action.launchBrowser();
		//action.driver.manage().deleteAllCookies();
		//AppiumDriver driver=new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
		
	}
	@Test(dataProvider = "getHeadlineData", groups = { "web", "headLine" }, dataProviderClass = DataProviderClass.class)
	public void VerifyHeadlineAndroidappAdFunctionalTest(String sno, String SFID, String headLineTactic,
			String headLineActivity, String adtitle, String headLineUser, String headLineUserPassword,
			String cpActivityParticipation, String cpActivityHeadImpr, String CPActivityImpr, String cpCallFilter,
			String articleid, String env, String sslNetworkFilter, String trackerMarker, String desktopPosition,
			String BrowserType) throws Exception {

		action.IOSapplogin("mobileuser98","oklahoma" );
		action.generatePassReport("================= Splash promro Ad Verification Started ===========");
		action.startNewHar();

		//waitForSplashPromoAd(action.getIOSDriver(), "//*[contains(text(),'"+adtitle+"')]");

		//waitForSplashPromoAd(action.getIOSDriver(),"How Much Attention Do You Pay to Animal Studies?");
		waitForSplashPromoAd(action.getAppiumDriver(),"//*[contains(text(),'How Much Attention Do You Pay to Animal Studies?')]");
		
		//action.waitForSplashPromoAd(action.getIOSDriver(),"Help limit joint damage and achieve clearer skin in PsA patients", headLineTactic, headLineActivity,env);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity ,env);
		WebDriverWait wait = new WebDriverWait(action.driver, 30);
	
		action.generatePassReport("================= News and perspective Ad Verification Started ===========");

		action.click(By.xpath("(//*[@text='Main_NavBar']/*[@class='UIAButton'])[1]"), "clicking on menu");
		action.click(By.xpath("//*[@text='News & Perspective']"), "clicking on NEWS and Perspective search box");

		int count1 = 0;
		while (count1 < 60) {

			/*if (isElementAvailable(action.driver, "//*[contains(text(),'" + adtitle + "')]")) {

				//action.click(By.xpath("//*[@text='" + adtitle + "']"), "clicking on surfaced ad " + adtitle);
				action.click(By.xpath("//*[@contentDescription='Navigate up']"), "clicking on close layer ");

				break;
			}*/
			//if (isElementAvailable(action.driver, "//*[contains(text(),'" + adtitle + "')]")) {
			if (action.isElementAvailable(action.driver, "Stephen Hawking Dies at 76")) {
				//action.click(By.xpath("//*[@text='" + adtitle + "']"), "clicking on surfaced ad " + adtitle);
				action.click(By.xpath("//*[contains(text(),'How Much Attention Do You Pay to Animal Studies?')]"), "clicking on surfaced ad " + adtitle);
				
				Thread.sleep(1000);
				action.click(By.xpath("//*[@contentDescription='Navigate up']"), "clicking on close layer ");

				break;
			}
			else {
				// action.swipe(665, 393, 734, 1293, 512);
				  action.getAppiumDriver().swipe(667, 582, 853, 1374, 519);
				//Thread.sleep(1000);
				count1++;
			}
		}
	}

	/*private  boolean waitForSplashPromoAd(AppiumDriver<WebElement> driver, String element) throws InterruptedException {
		boolean isElementPresent = false;
		int noOfIterations = 0;

		while (noOfIterations < 20) {
			ArrayList<WebElement> listOfEle = new ArrayList<>();
			
			boolean adsDisplayed =false;
			for (int j = 0; j <=8 ; j++) {
				Logs.info("Swipes done "+j);
				List<WebElement> ifiLinks = driver
						.findElements(By.xpath("//*[@text='Information from Industry']//preceding-sibling::*[@XCElementType='XCUIElementTypeStaticText'][contains(@value,'"+element+"')]"));
					
				if (ifiLinks.size()>0) {
					System.out.println("Ad loaded in current page");
					action.generatePassReportWithScreenShot("Ad displayed "+element);
					adsDisplayed =true;
					break;
					
				}
				listOfEle.addAll(ifiLinks);
				//Thread.sleep(2000);
			} 
			if (adsDisplayed) {
				break;	
			}
			
		    driver.swipe(667, 582, 853, 1374, 519);
			
			noOfIterations++;
		}
		return isElementPresent;

	}
*/
	private static boolean waitForSplashPromoAd(AppiumDriver driver, String element) 
	{
		boolean isElementPresent=false;
		int noOfIterations=0;
		int count=0;
		try
		{
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.MILLISECONDS); 
			
			
				while(noOfIterations<5)
				{
					while(count<120)
					{
						try
						{
					
						driver.findElement(By.xpath(element)).click();						
						isElementPresent=true;
						 
						return isElementPresent;
						}
						
						catch(Exception e)
						{
							count++;
							Thread.sleep(500);
							continue;
						}
					}
					driver.swipe(328, 226, 274, 1133, 336);
					noOfIterations++;
				}
					
					
					
				
			return isElementPresent;
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			return isElementPresent;
		}
		
	}
	
	public static boolean isElementAvailable(WebDriver driver, String element) {

		boolean isElementPresent = false;
		try {

			try {
				if (driver.findElement(By.xpath(element)).isDisplayed()) {
					isElementPresent = true;
					return isElementPresent;
				}

				Thread.sleep(10000);
			}

			catch (Exception e) {

			}

			return isElementPresent;

		}

		catch (Exception e) {
			e.printStackTrace();
			return isElementPresent;
		}
	}

	// ((AndroidDeviceActionShortcuts) action.getDriver()).pressKeyCode(66);

	@AfterClass
	public void shutDownLogin() throws Throwable {
		action.driver.quit();
	}

}

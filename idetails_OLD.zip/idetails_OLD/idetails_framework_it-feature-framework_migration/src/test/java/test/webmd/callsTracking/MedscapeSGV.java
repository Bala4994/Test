package test.webmd.callsTracking;

import org.openqa.selenium.By;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;


public class MedscapeSGV {

	public ActionMethods action;

	@BeforeClass(alwaysRun=true)
	public void startUpSGVBrowser(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser();
		
	}
	
	@Test(dataProvider = "getSGVData", groups = {"sgvweb" },dataProviderClass=DataProviderClass.class)
	public void VerifySGVWebAdFunctionalTest(String SFID, String tacticID, String promoID, String SGVUserName,
			String SGVPassword,String Branded,String MessageCategory, String layerOpenCall, String callAfter3Seconds, String layerCloseCall,
			String newsArticle, String emedicineArticle, String drugMonographArticle, String newsArticleName,
			String emedicineArticleName, String monographArticleName, String onsiteURL, String ticketNo, String env)
			throws Exception {
		
		action.generateBoldInfo("Ticket Number : " + ticketNo + "<br> SF ID : " +SFID + "<br>  Tactic  : " +tacticID ); 
		action.login(SGVUserName,SGVPassword);
		action.generateBoldInfo("================= News Article Verification Started ===========");
		action.startNewHar();
		action.get(newsArticle);
		action.validateSGVCallDisplayed(SFID, newsArticle);
		action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
		action.validateImages(action.getproxyServer(), env,SFID);
		//action.clickAllradioButtons(action.getDriver(), By.xpath("//div[@id=\"nDlayer_plate\"]//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		action.verifynoCacheTS3(SFID);	
		//verify layer links
		//action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);	sgvtestLayerLinks	
		action.sgvtestLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.click(By.id("nDlayer_close"), "Close SGV Layer");
		action.verifyNoCount(SFID);
		action.generateBoldInfo("=================  Emedicine Article Verification Started ===========");
		action.startNewHar();
		action.get(emedicineArticle);
		action.validateSGVCallDisplayed(SFID, emedicineArticle);
		action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
		action.validateImages(action.getproxyServer(), env,SFID);
		//action.clickAllradioButtons(action.getDriver(), By.xpath("//div[@id=\"nDlayer_plate\"]//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		action.verifynoCacheTS3(SFID);	
		action.sgvtestLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.click(By.id("nDlayer_close"), "Close SGV Layer");
		action.verifyNoCount(SFID);
		action.generateBoldInfo("=================  MonographArticle Article Verification Started ===========");
		action.startNewHar();
		action.get(drugMonographArticle);
		action.validateSGVCallDisplayed(SFID, drugMonographArticle);
		action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
		action.validateImages(action.getproxyServer(), env,SFID);
		//action.clickAllradioButtons(action.getDriver(), By.xpath("//div[@id=\"nDlayer_plate\"]//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);  
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);  
		action.verifynoCacheTS3(SFID);
		action.sgvtestLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.pageRefresh();
		action.click(By.id("nDlayer_close"), "Close SGV Layer");
		action.verifyNoCount(SFID);
	}

	
	@Test(dataProvider = "getSGVData", groups = { "sgvandroid" },dataProviderClass=DataProviderClass.class)
	public void VerifySGVMobileAndriodAdFunctionalTest(String SFID, String tacticID, String promoID, String SGVUserName,
			String SGVPassword,String Branded,String MessageCategory, String layerOpenCall, String callAfter3Seconds, String layerCloseCall,
			String newsArticle, String emedicineArticle, String drugMonographArticle, String newsArticleName,
			String emedicineArticleName, String monographArticleName, String onsiteURL, String ticketNo, String env)
			throws Exception {
		
		action.generateBoldInfo("Ticket Number : " + ticketNo + "<br> SF ID : " +SFID + "<br>  Tactic  : " +tacticID ); 
		
		action.login(SGVUserName,SGVPassword);
		action.generateBoldInfo("================= News Article Verification Started ===========");
		action.startNewHar();
		action.get(newsArticle);
		action.validateSGVCallDisplayed(SFID, newsArticle);
		action.generatePassReport("Sponsred Title:"+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		action.validateImages(action.getproxyServer(), env,SFID);
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		action.verifynoCacheTS3(SFID);		
		//verify layer links
		action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);		
		action.startNewHar();
		action.pageRefresh();
		action.click(By.id("agtCloseBtn"), "Close SGV Layer");
		action.verifyNoCount(SFID);
		
		action.generateBoldInfo("=================  Emedicine Article Verification Started ===========");
		action.startNewHar();
		action.get(emedicineArticle);
		action.validateSGVCallDisplayed(SFID, emedicineArticle);
		action.generatePassReport("Sponsred Title:"+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		action.verifynoCacheTS3(SFID);
		action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.click(By.id("agtCloseBtn"), "Close SGV Layer");
		action.verifyNoCount(SFID);
		action.generateBoldInfo("=================  MonographArticle Article Verification Started ===========");
		action.startNewHar();
		action.get(drugMonographArticle);
		action.validateSGVCallDisplayed(SFID, drugMonographArticle);
		action.generatePassReport("Sponsred Title:"+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		action.verifynoCacheTS3(SFID);
		action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.pageRefresh();
		action.click(By.id("agtCloseBtn"), "Close SGV Layer");
		action.verifyNoCount(SFID);
	}
	@Test(dataProvider = "getDMSGVData", groups = {"dmsgvweb" },dataProviderClass=DataProviderClass.class)
	public void VerifyDMSGVWebAdFunctionalTest(String SFID, String tacticID, String promoID, String SGVUserName,
			String SGVPassword,String Branded,String MessageCategory, String layerOpenCall, String callAfter3Seconds, String layerCloseCall,String drugMonographArticle,String ticketNo, String env)
			throws Exception {
		
		action.generateBoldInfo("Ticket Number : " + ticketNo + "<br> SF ID : " +SFID + "<br>  Tactic  : " +tacticID ); 
		action.login(SGVUserName,SGVPassword);
		action.generateBoldInfo("================= Drug Monograph SGV Article Verification Started =================");
		action.startNewHar();
		action.get(drugMonographArticle);
		action.validateSGVCallDisplayed(SFID, drugMonographArticle);
		action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
		action.validateImages(action.getproxyServer(), env,SFID);
		//action.clickAllradioButtons(action.getDriver(), By.xpath("//div[@id=\"nDlayer_plate\"]//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		action.verifynoCacheTS3(SFID);	
		//verify layer links
		//action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);	sgvtestLayerLinks	
		action.sgvtestLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.click(By.id("nDlayer_close"), "Close SGV Layer");
		action.verifyNoCount(SFID);
	}
	@Test(dataProvider = "getDMSGVData", groups = {"dmsgvandroid" },dataProviderClass=DataProviderClass.class)
	public void VerifyDMSGVMobileAdFunctionalTest(String SFID, String tacticID, String promoID, String SGVUserName,
			String SGVPassword,String Branded,String MessageCategory, String layerOpenCall, String callAfter3Seconds, String layerCloseCall,String drugMonographArticle,String ticketNo, String env)
			throws Exception {
		
		action.generateBoldInfo("Ticket Number : " + ticketNo + "<br> SF ID : " +SFID + "<br>  Tactic  : " +tacticID ); 
		action.login(SGVUserName,SGVPassword);
		action.generateBoldInfo("================= Drug Monograph SGV Article Verification Started =================");
		action.startNewHar();
		action.get(drugMonographArticle);
		action.validateSGVCallDisplayed(SFID, drugMonographArticle);
		action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
		action.validateImages(action.getproxyServer(), env,SFID);
		//action.clickAllradioButtons(action.getDriver(), By.xpath("//div[@id=\"nDlayer_plate\"]//table//tr[2]/td[2]/input"),By.xpath("//*[@id=\"polltable\"]/form/div/div/input"));
		action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
		action.sgvApiCallsValidation(tacticID, promoID,Branded,MessageCategory, env);
		action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		action.verifynoCacheTS3(SFID);	
		//verify layer links
		//action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);	sgvtestLayerLinks	
		action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
		action.startNewHar();
		action.click(By.id("agtCloseBtn"), "Close SGV Layer");
		action.verifyNoCount(SFID);
		
	}
	
	@AfterClass(alwaysRun=true)
	public void shutDownSGVBrowser() throws Throwable {
		action.driver.quit();
		action.getproxyServer().stop();

	}

}

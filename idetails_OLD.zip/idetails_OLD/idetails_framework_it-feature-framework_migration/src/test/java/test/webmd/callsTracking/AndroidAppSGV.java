package test.webmd.callsTracking;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;

import io.appium.java_client.android.AndroidDeviceActionShortcuts;


@Listeners(com.webmd.automation.utilities.Listener.class)
public class AndroidAppSGV {

	public ActionMethods action;

	@BeforeClass
	public void startUpLogin(ITestContext ctx) throws Throwable {
		
		action = new ActionMethods(ctx);
		action.launchBrowser();
		action.getDriver().manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS); 
		
		action.click(By.xpath("//android.widget.TextView[contains(@resource-id,'btnSignIn') and @text='I have an account']"), "navigating to login");
		
		action.getDriver().findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'edit_text_user_name')]")).sendKeys("mobileuser2");
		action.getDriver().findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'edit_text_password')]")).sendKeys("purple");
		boolean b =action.click(By.xpath("//android.widget.Button[contains(@resource-id,'button_login') and @text='Log In']"), "Login button clicked");
		Assert.assertEquals(b, true);
		
	}

			@Test(dataProvider = "getSGVData", groups = { "web", "sgv" },dataProviderClass=DataProviderClass.class)
	public void VerifySGVMobilAndroidappAdFunctionalTest(String SFID, String tacticID, String promoID, String SGVUserName,
			String SGVPassword, String layerOpenCall, String callAfter3Seconds, String layerCloseCall,
			String newsArticle, String emedicineArticle, String drugMonographArticle, String newsArticleName,
			String emedicineArticleName, String monographArticleName, String onsiteURL, String BrowserType, String env)
			throws Exception{
		
		action.generatePassReport("================= News Article Verification Started ===========");
		action.startNewHar();
		action.click(By.xpath("//*[@class='android.widget.ImageButton']"), "clicking on menu");
		//action.click(By.xpath("//*[@class='android.widget.ImageButton']"), "clicking on menu");
		action.click(By.xpath("//*[@text='News & Perspective']"), "clicking on NEWS and Perspective search box");
		action.click(By.xpath("//android.widget.TextView[contains(@resource-id,'action_search')]"), "clicking on search button");
		action.getDriver().findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'search_src_text')]")).sendKeys(newsArticleName);
		submit();
		//((AndroidDeviceActionShortcuts) action.getDriver()).pressKeyCode(66);
		//action.click(By.xpath("//*[@text='Search']"), "Clicking on Search button");
		
		//WebDriverWait wait = new WebDriverWait(action.getDriver(),30);
		
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='"+newsArticleName+"']")));
		action.click(By.xpath("//android.widget.TextView[contains(@resource-id,'list_title') and @text='"+newsArticleName+"']"), "Clicking on  News article");
		Thread.sleep(5000);
		//action.validateAPICalls(tacticID, promoID, env);
		
		action.validateAPICalls(tacticID, promoID,env);
		action.testLayerLinksAndroidApp(action.getDriver(), action.getproxyServer(), SFID, env);		
		
		action.click(By.xpath("//*[@text='Close']"), "Clicking on close button");
		
		action.generatePassReport("=================  Emedicine Article Verification Started ===========");
		
		action.startNewHar();
		//action.click(By.xpath("//*[@text='nav back']"), "navigating back");
		action.getDriver().navigate().back();
		action.getDriver().navigate().back();
		action.click(By.xpath("//*[@text='Drugs &\nDiseases']"), "clicking on Drugs & Diseases");
		//action.click(By.xpath("//*[@text='Clear text']"), "Clearing the text in Testbox");
		action.getDriver().findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'search_src_text')]")).sendKeys(emedicineArticleName);
		action.click(By.xpath("//android.widget.TextView[contains(@resource-id,'external_driver_text')]"), "Clicking on Search button");
	    //wait = new WebDriverWait(action.getDriver(),30);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[contains(@resource-id,'list_item') and @text='"+emedicineArticleName+"']")));
		action.click(By.xpath("//android.widget.TextView[contains(@resource-id,'list_item') and @text='"+emedicineArticleName+"']"), "Clicking on  emedicine article");
		
		Thread.sleep(3000);
		action.validateAPICalls(tacticID, promoID, env);
		action.testLayerLinksAndroidApp(action.getDriver(), action.getproxyServer(), SFID, env);
		//action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, emedicineArticle, env);
		
		//action.click(By.xpath("//*[@text='Close']"), "Clicking on close button");
		
		action.generatePassReport("=================  MonographArticle Article Verification Started ===========");
		action.startNewHar();
		action.getDriver().navigate().back();
		action.getDriver().navigate().back();
		
		//action.click(By.xpath("//*[@text='Clear text']"), "Clearing the text in Testbox");
		//action.getDriver().findElement(By.xpath("//*[@placeholder='Search Drugs & Diseases']")).sendKeys(monographArticleName);
		action.getDriver().findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'search_src_text')]")).sendKeys(monographArticleName);
	    //wait = new WebDriverWait(action.getDriver(),30);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@text='"+monographArticleName+"']")));
		action.click(By.xpath("//*[@text='"+monographArticleName+"']"), "Clicking on monograph article");
		Thread.sleep(3000);
		//action.validateAPICalls(tacticID, promoID);
		//action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, drugMonographArticle, env);
		action.click(By.xpath("//*[@text='Close']"), "Clicking on close button");
		action.getDriver().navigate().back();
		
	}

			public void submit() {
				try {
					//action.getDriver().findElement(By.xpath("//android.widget.EditText[contains(@resource-id,'search_src_text')]")).submit();
					((AndroidDeviceActionShortcuts) action.getDriver()).pressKeyCode(66);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	
	
	@AfterClass
	public void shutDownLogin() throws Throwable {
		action.driver.quit();
	}
}
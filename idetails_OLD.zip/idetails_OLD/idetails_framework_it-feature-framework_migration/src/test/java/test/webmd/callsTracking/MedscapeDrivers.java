package test.webmd.callsTracking;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;

@Listeners(com.webmd.automation.utilities.Listener.class)
public class MedscapeDrivers {

	public ActionMethods action;

	@BeforeClass(alwaysRun = true)
	public void startUpDriverBrowser(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser();

	}

	@Test(dataProvider = "getDriverData", groups = { "Driverweb" }, dataProviderClass = DataProviderClass.class)
	public void VerifyDriverWebAdFunctionalTest(String SFID, String tacticID, String promoID, String DriverUserName,
			String DriverPassword, String newsArticle, String position, String Version, String ticketNo, String env, String size, String call)
			throws Exception {
		int counter=0;

		action.generateBoldInfo("Ticket Number : " + ticketNo + "<br> SF ID : " + SFID + "<br>  Tactic  : " + tacticID);
		action.login(DriverUserName, DriverPassword);
		//action.driver.manage().window().maximize();
		action.generateBoldInfo("================= Driver Article Verification Started ===========");

		/*
		 * int versionNumber = Integer.valueOf(Version); Hashtable<Integer, String> ver
		 * = new Hashtable<>();
		 * 
		 * for (int i = 1; i <=versionNumber; i++) { ver.put(i, "false"); }
		 */

		Hashtable<Integer, String> ver = new Hashtable<>();
		String versionNumber = Version;
		String[] val = versionNumber.split(",");

		for (String value : val) {
			ver.put(Integer.valueOf(value), "false");
		}

		boolean allVersionsTrackedNottacked = true;

		while (allVersionsTrackedNottacked) {
			action.startNewHar();
			action.get(newsArticle);
			
			counter++;
			String pos = position;
			if(pos.equalsIgnoreCase("141"))
			{
				action.startNewHar();
				action.get(newsArticle);
			}
		    if(pos.equalsIgnoreCase("420"))
			{ 	
				boolean adpos = action.driver.findElement(By.id("ads-pos-420")).isDisplayed();
     	   
     	      if(!adpos)
     	      {
     	       action.startNewHar();
			   action.driver.findElement(By.xpath("//div[@id='next-section']/a")).click();
     		   action.staticWait(10);
     		  }
			}
			String version = action.getVersion(tacticID, promoID, env, pos);
			

			try {
				if (ver.get(Integer.parseInt(version)).equals("false")) {

					action.generateReport(true, action.getBoldText("api." + env + "medscape.com") + ": adimpr values  "
							+ action.getBoldText("tactic id :" + tacticID), "version tracked is :" + version);
					
 					String b =action.driverLinkClick(action.getDriver(), action.getproxyServer(), SFID, env, pos, version, size, call);
					ver.put(Integer.parseInt(version), b);
					
				}
			} catch (Exception e) {

			}
			

			for (int i = 0; i < val.length; i++) {

				if (ver.get(Integer.parseInt(val[i])).equals("false")) {
					allVersionsTrackedNottacked = true;
					
					break;
				}
				if (i == (val.length - 1) && ver.get(Integer.parseInt(val[i])).equals("true")) {

					allVersionsTrackedNottacked = false;
				}
				
			}
			
			
			if(counter>=20) {
				action.generatePassReport("**********************Verisons Verified**********************");
            for (int i = 0; i < val.length; i++) {
					
					int j =1;
					j+=i;					
			        action.generateBoldInfo("Version " + j + ": " +ver.get(Integer.parseInt(val[i])));
            }
				action.generatePassReport("***********************************************************");
				break;
		
				}
	      }
	}
	

	@AfterClass(alwaysRun = true)
	public void shutDownDriverBrowser() throws Throwable {
		action.driver.quit();

	}

}

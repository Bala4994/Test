package test.webmd.callsTracking;

import org.openqa.selenium.By;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;
import com.webmd.automation.utilities.GetHeadLineUsersWithRowRange;

public class IOSWebHeadLine {

	public ActionMethods action;

	@BeforeClass(alwaysRun=true)
	public void startUpHeadLineIOSWebBrowser(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser();
		
	}	
	
	@Test(dataProvider = "getHeadlineData", groups = { "headLineios" }, dataProviderClass = DataProviderClass.class)
	public void VerifyHeadlineIOSMobileFunctionality(String sno, String SFID, String headLineTactic,
			String headLineActivity, String adtitle, String headLineUser, String headLineUserPassword,
			String cpActivityParticipation, String cpActivityHeadImpr, String CPActivityImpr, String cpCallFilter,
			String articleid, String env, String sslNetworkFilter, String trackerMarker, String desktopPosition,
			String BrowserType, String dataRange) throws Exception {
		action.env =env;
		action.login(headLineUser,headLineUserPassword);
		
		//===============N&P home page validation
		action.generateInfoReport(
				"================Headline surfing at News & Perspective home page is started=======================");
		action.startNewHar();
		String HeadlineNpURL = "https://www." + env + "medscape.com/hiv";
		
		action.startNewHar();
		action.get(HeadlineNpURL);
		GetHeadLineUsersWithRowRange data = new GetHeadLineUsersWithRowRange(dataRange);

		action.isTacticPresent(headLineTactic, headLineUser,data);
		
		//===================hp hp2 hp5 =======================
		action.is2AdsDisplayed(HeadlineNpURL, SFID, "hp_2", "hp_5", headLineTactic, headLineUser,headLineActivity,adtitle,env, data);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity);
		
		//=============================Reference URL ==============================
		action.generateInfoReport(
				"================Headline surfing at reference homepage is started=======================");
		
		action.startNewHar();
		action.get("https://reference."+env+"medscape.com/");
		
		action.isTacticPresent(headLineTactic, headLineUser,data);
	
		//=============================mobile_refhp_top ==============================	
		
		action.isSingleAdDisplayed("https://reference."+env+"medscape.com/", SFID, "mobile_refhp_top", headLineTactic, headLineUser,headLineActivity,adtitle,env, data);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity);
		
		
		try {
			//handle sgv layer if displays 
			action.getDriver().findElement(By.id("agtCloseBtn")).click();
		} catch (Exception e) {
			
		}
		 action.clickCloseConsultLayer();
		 action.startNewHar();
		 action.click(By.xpath("//a[contains(@href,'mobile_refhp_top') and contains(@href,'" + SFID + "')]"), "mobile_refhp_top");
		 action.generatePassReportWithScreenShot("Find below screenshot for headline onsite page");
		 action.generatePassReport(action.getBoldText("Sponsred Title:")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		 action.validateHeadLineParticipationCall(headLineTactic, headLineActivity,env);  
		 action.validateImages(action.getproxyServer(), env,SFID);
		 action.testLayerLinksIosWeb(action.getDriver(), action.getproxyServer(), SFID, env);
      
       
	}
	
	@AfterClass(alwaysRun=true)
	public void shutDownHeadLIneIOSBrowser() throws Throwable {
		action.getAppiumDriver().closeApp();

	}


}

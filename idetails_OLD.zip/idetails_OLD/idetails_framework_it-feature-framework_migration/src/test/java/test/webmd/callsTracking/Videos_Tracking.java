package test.webmd.callsTracking;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;
import com.webmd.automation.accel.VideoPlayerOminatureValues;
import com.webmd.automation.accel.VideosObjectRepo;

public class Videos_Tracking {

	public String hashValue;
	public String omnValue;
	public String curArticle;
	public String mPage;
	public VideoPlayerOminatureValues omnValues;
	public int i;
	int size = 0;
	boolean isTapForSoundDisplayed = false;
    public String domainName="https://ssl.o.webmd.com/b/ss";
    
    @Test
    public void performVideoTracking(WebDriver driver,ActionMethods action) {
    	//add paramter for video count
    	String infositeVideoNumber="vidsvp-video";
    	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		//action.generatePassReport("================= Video Player Omniture Tracking Started ===========");
		action.startNewHar();
		String omnValue = "";
		mPage = "/alert";
		domainName = "https://ssl.o.webmd.com/b/ss";
		action.waitForElement(VideosObjectRepo.tapForSoundBtn, "tap For Sound");
		driver.manage().window().maximize();
		action.staticWait(5);
		action.scrollToObject(driver.findElement(VideosObjectRepo.videoPlayer));
		//action.scrollToObject(action.driver.findElement(By.id("//*[@id='ck-editor-text-2'][1]/ul/li[2]")));
		//action.staticWait(2);
		
		
		//Validation of mute calls 
		//action.generatePassReport("*****************Verification of Video present in article*****************");
		if (action.isElementAvailable(driver, "//*[@class='tap-for-sound-button']")) {
			System.out.println("Tap for sound displayed: Video is present on the article");
			omnValue = VideoPlayerOminatureValues.videoMlinkMute + ","
					+ infositeVideoNumber;
			//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,equals,notnull,notnull");
			
			isTapForSoundDisplayed=true;
			action.generateReport(action.isElementAvailable(driver, "//*[@class='tap-for-sound-button']"),
					"************************Video is visible on page And video calls verification Started************************", "Video is not visible on page");
			action.generatePassReport("*****************Mutex Call*****************");
			//action.startNewHar();
			//action.click(VideosObjectRepo.tapForSoundBtn, "tap for sound");
			action.moveToElementandClick(VideosObjectRepo.tapForSoundBtn, VideosObjectRepo.tapForSoundBtn, "tap for sound");
			action.generateReport(!action.isElementAvailable(driver, "//div[contains(@class,'tap-for-sound is-muted')]"),
					"tap for sound is not visible on page after clicking on it",
					"tap for sound is visible on page after clicking on it");

			omnValue = VideoPlayerOminatureValues.videoMlinkUnmute + ","
					+ infositeVideoNumber;
			action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
			action.staticWait(5);
			String[] time=driver.findElement(VideosObjectRepo.currentTime).getText().split(":");
		int value= Integer.parseInt(time[1]);
		if(value<=0) {
			action.generateFailReport("Video Is not Playing after clicking on Tap for Sound button");
			action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Play");
		}
		
		
		}else {
			action.scrollToObject(driver.findElement(VideosObjectRepo.videoPlayer));
			action.generateFailReport("Tap for sound is Not displayed");
        	action.generatePassReport("*****************Play call*****************");
    		action.startNewHar();
    		action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Play");
    		action.staticWait(2);
    		omnValue = VideoPlayerOminatureValues.videoMlinkPlay + "," + infositeVideoNumber;
    		action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
			
		}
		//Validation of Start calls
				/*action.staticWait(5);
				action.generatePassReport("*****************Start Call*****************");
				omnValue = VideoPlayerOminatureValues.videoMlinkStart + "," + infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
		*/
		//Validation of mutex calls
	/*	action.generatePassReport("*****************Mutex Call*****************");
		//action.startNewHar();
		//action.click(VideosObjectRepo.tapForSoundBtn, "tap for sound");
		action.moveToElementandClick(VideosObjectRepo.tapForSoundBtn, VideosObjectRepo.tapForSoundBtn, "tap for sound");
		action.generateReport(!action.isElementAvailable(driver, "//div[contains(@class,'tap-for-sound is-muted')]"),
				"tap for sound is not visible on page after clicking on it",
				"tap for sound is visible on page after clicking on it");

		omnValue = VideoPlayerOminatureValues.videoMlinkUnmute + ","
				+ infositeVideoNumber;
		action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
		//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
		*/
		action.staticWait(5);
		action.generatePassReport("*****************Start Call*****************");
		omnValue = VideoPlayerOminatureValues.videoMlinkStart + "," + infositeVideoNumber;
		action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
		
		action.staticWait(2);
		action.generatePassReport("*****************Pause Call*****************");
		action.startNewHar();
		//action.click(VideosObjectRepo.playPauseBtn, "Pause");
		action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Pause");
		action.staticWait(2);
		omnValue = VideoPlayerOminatureValues.videoMlinkPause + "," + infositeVideoNumber;
		action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
			action.generatePassReport("*****************Mute Call*****************");
				action.startNewHar();
				//action.click(VideosObjectRepo.volumeControlBtn, "Volume Off");
				action.moveToElementandClick(VideosObjectRepo.volumeControlBtn, VideosObjectRepo.volumeControlBtn, "Volume Off");
				action.staticWait(2);
			    omnValue = VideoPlayerOminatureValues.videoMlinkMute + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
			
				
				//Validation of Maximize calls
				action.generatePassReport("*****************Maximize Call*****************");
				action.startNewHar();
				//action.click(VideosObjectRepo.fullScreenBtn, "Big Screen");
				action.moveToElementandClick(VideosObjectRepo.fullScreenBtn, VideosObjectRepo.fullScreenBtn, "Big Screen");
				action.staticWait(2);
				omnValue = VideoPlayerOminatureValues.videoMlinkBigscreen + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
				action.generatePassReport("*****************Large Screen Play Call*****************");
				action.staticWait(1);
				action.startNewHar();
			//	action.click(VideosObjectRepo.fullScreenBtn, "Full Screen");
				action.staticWait(1);
				//action.click(VideosObjectRepo.playPauseBtn, "Play");
				action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Play");
				omnValue = VideoPlayerOminatureValues.videoMlinkPlay + "," + infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				
				action.generatePassReport("*****************Large Screen Mutex Call*****************");
			  	action.startNewHar();
			  	
			    //action.click(VideosObjectRepo.volumeControlButtonInLargeScreen, "Volume On");
			    action.moveToElementandClick(VideosObjectRepo.volumeControlButtonInLargeScreen, VideosObjectRepo.volumeControlButtonInLargeScreen, "Volume On");
			    action.staticWait(1);
			    omnValue = VideoPlayerOminatureValues.videoMlinkUnmute + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				
				action.generatePassReport("*****************Large Screen pause Call*****************");
				action.startNewHar();
				//action.click(VideosObjectRepo.playPauseBtn, "Pause");
				action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Pause");
				action.staticWait(1);
				omnValue = VideoPlayerOminatureValues.videoMlinkPause + "," + infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				
				action.generatePassReport("*****************Large Screen Mute Call*****************");
				action.startNewHar();
				//action.click(VideosObjectRepo.volumeControlButtonInLargeScreen, "Volume Off");
				action.moveToElementandClick(VideosObjectRepo.volumeControlButtonInLargeScreen, VideosObjectRepo.volumeControlButtonInLargeScreen, "Volume Off");
			    omnValue = VideoPlayerOminatureValues.videoMlinkMute + ","
						+ infositeVideoNumber;
			    action.staticWait(1);
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
			 
				action.generatePassReport("*****************Minimize Call*****************");
				action.startNewHar();
				//action.click(VideosObjectRepo.fullScreenBtn, "Small Screen");
				action.moveToElementandClick(VideosObjectRepo.fullScreenBtn, VideosObjectRepo.fullScreenBtn, "Small Screen");
				action.staticWait(2);
				omnValue = VideoPlayerOminatureValues.videoMlinkSmallerscreen + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
		
				//Validation of Mutex calls
				action.generatePassReport("*****************Mutex Call*****************");
				action.startNewHar();
				//action.click(VideosObjectRepo.volumeControlBtn, "Volume On");
				action.moveToElementandClick(VideosObjectRepo.volumeControlBtn, VideosObjectRepo.volumeControlBtn, "Volume On");
				action.staticWait(2);
				omnValue = VideoPlayerOminatureValues.videoMlinkUnmute + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//Validation of Play calls
				action.generatePassReport("*****************Play Call*****************");
				action.startNewHar();
				//action.click(VideosObjectRepo.playPauseBtn, "Play");
				action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Play");
				
				omnValue = VideoPlayerOminatureValues.videoMlinkPlay + "," + infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//Validation of 25pct calls
				action.generatePassReport("*****************25pct Call*****************");
				action.startNewHar();
				action.ExecuteJavascript("$(\"video\")[0].currentTime=100000;");
				action.staticWait(10);
				action.click(VideosObjectRepo.playPauseBtn, "Play");
				action.staticWait(4);
				omnValue = VideoPlayerOminatureValues.videoMlink25pct + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");

				//validation of 50 pct calls
				action.generatePassReport("*****************50pct Call*****************");
				omnValue = VideoPlayerOminatureValues.videoMlink50pct + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
		   
				//validation of 75 pct calls
				action.generatePassReport("*****************75pct Call*****************");
				omnValue = VideoPlayerOminatureValues.videoMlink75pct + ","
						+ infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
		    
				//validation of 100 pct calls
				action.generatePassReport("*****************100pct Call*****************");
				omnValue = VideoPlayerOminatureValues.videoMlink100pct + ","
						+ infositeVideoNumber;
				action.staticWait(4);
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
		   
				//validation of scrb calls
				action.generatePassReport("*****************Scrub Call*****************");
				omnValue = VideoPlayerOminatureValues.videoMlinkScrb + "," + infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				//Validation of 3sec calls
				action.generatePassReport("*****************************************************************************************************************************************************************");
   
    
  }




    @Test
    public void trackHeartBeatCalls(WebDriver driver,ActionMethods action,String SFID) {
    	
    	String domain="webmd.hb.omtrdc.net";
    	action.startNewHar();
    	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		action.waitForElement(VideosObjectRepo.tapForSoundBtn, "tap For Sound");
		driver.manage().window().maximize();
		action.staticWait(4);
		action.scrollToObject(driver.findElement(VideosObjectRepo.videoPlayer));
		
		if (action.isElementAvailable(driver, "//*[@class='tap-for-sound-button']")) {
			System.out.println("Tap for sound displayed: Video is present on the article");
			
			isTapForSoundDisplayed=true;
			action.generateReport(action.isElementAvailable(driver, "//*[@class='tap-for-sound-button']"),
					"Video is visible on page And HeartBeat calls verification Started", "Video is not visible on page");
			action.moveToElementandClick(VideosObjectRepo.tapForSoundBtn, VideosObjectRepo.tapForSoundBtn, "tap for sound");
			action.staticWait(2);
		}else {
			action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Play");
			action.staticWait(3);
		}
		//action.click(VideosObjectRepo.tapForSoundBtn, "tap for sound");
		action.staticWait(3);
		action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Pause");
		action.staticWait(5);
		action.ExecuteJavascript("$(\"video\")[0].currentTime=100000;");
		action.staticWait(8);
		action.verifySslCalls("webmd.hb.omtrdc.net");
		//Hashtable<String, String> hearbeatmap=action.verifyOmnitureAttributes("webmd.hb.omtrdc.net", "s:sp:player_name,s:asset:video_id");
		Hashtable<String, String> hearbeatmap=action.verifyOmnitureValues(action.getproxyServer(), domain, "s:asset:video_id", "infosites/"+SFID, "contains");
	/*	Hashtable<String, String> hearbeatmap=action.getStdParmValues(action.getproxyServer(), domain);
		action.generateReport(hearbeatmap.size() > 0, domain+"  call  tracked <br>"+hearbeatmap.get("s:asset:video_id")+"<br>"+ hearbeatmap.toString(),
				domain+"  call not tracked <br>" + hearbeatmap.toString());
		*/
		//action.generateReport(hearbeatmap.get("s:asset:video_id").contains(SFID), "s:asset:video_id :  "+action.getBoldText(hearbeatmap.get("s:asset:video_id")), "SF Number Not matching in HeartBeat Calls");
		if(!hearbeatmap.get("s:asset:video_id").equals(null)) {
    		action.generateReport(hearbeatmap.get("s:asset:video_id").contains(SFID), "s:asset:video_id :  "+action.getBoldText(hearbeatmap.get("s:asset:video_id")), "SF Number Not matching in HeartBeat Calls");
    		}else {
    			action.generateFailReport("s:asset:video_id : is tarcked as null");
    		}
		action.generatePassReport("**************************************************************************************************************************************************************");
    }
    @Test
    public void trackHeartBeatCallsForMultipleVideos(WebDriver driver,ActionMethods action,String SFID) {
    	
    	try {
			String domain="webmd.hb.omtrdc.net";
			action.startNewHar();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			List<WebElement> videoscount=driver.findElements(VideosObjectRepo.videos);
			driver.manage().window().maximize();
			int videosSize=videoscount.size();
			int j;
			action.staticWait(4);
			for(int i=1;i<=videosSize;i++)
			{
				action.startNewHar();
				j=i-1;
				if(action.isElementAvailable(driver,"//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']" ))
					//if(isElementPresent(By.xpath("(//span[contains(text(),'Tap for Sound')])["+i+"]"),"tap for sound"))
					{
					action.generatePassReport("**************"+action.getBoldText("Heart Beat Calls Verification for Video-"+i+" Started")+"**************");
						action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']"), 
								By.xpath("//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']"),"Tap for sound");
			        	action.staticWait(5);
			        	action.generateReport(!action.isElementAvailable(driver, "//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']"),
			    				"tap for sound is not visible on page after clicking on it",
			    				"tap for sound is visible on page after clicking on it");
			        	action.staticWait(5);
			        	action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),
			             		By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),"pause");
			    		action.staticWait(2);
			    		
			        	
					}else {
						action.staticWait(2);
						action.generatePassReport("**************"+action.getBoldText("Heart Beat Calls Verification for Video-"+i+" Started")+"**************");
						action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),
			             		By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),"Play");
			    		action.staticWait(4);
					}
				action.Dragprogressbar(By.xpath("//*[contains(@id,'video_player_screen-"+j+"')]//*[@class='progress-drag']"), 1000);
				action.staticWait(3);
				action.verifySslCalls("webmd.hb.omtrdc.net");
				Hashtable<String, String> hearbeatmap=action.verifyOmnitureValues(action.getproxyServer(), domain, "s:asset:video_id", "infosites/"+SFID, "contains");
				if(hearbeatmap.get("s:asset:video_id")!=null) {
				action.generateReport(hearbeatmap.get("s:asset:video_id").contains(SFID), "s:asset:video_id :  "+action.getBoldText(hearbeatmap.get("s:asset:video_id")), "SF Number Not matching in HeartBeat Calls");
				}else {
					action.generateFailReport("s:asset:video_id : is  tarcked as null");
				}
				action.generatePassReport("**************************************************************************************************************************************************************");
				hearbeatmap.clear();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Test
    public void performMultipleVideoTracking(WebDriver driver,ActionMethods action) {
    	action.getDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
    	List<WebElement> videoscount=driver.findElements(VideosObjectRepo.videos);
    	action.staticWait(5);
    	String infositeVideoNumber="vidsvp-video";
    	String videoMmodule="";
    	int j;
		int videosSize=videoscount.size();
		driver.manage().window().maximize();
		action.startNewHar();
		String[] videoNumbers = {"Zero", "First", "Second","Third","Fourth","Fifth","Sixth","Seventh","Eight","Ninth","Tenth"};
		for(int i=1;i<=videosSize;i++)
		{
			if(i>1) {driver.navigate().refresh();}
			try {
				action.generatePassReport("**************"+action.getBoldText("Video Tracking Verification for  "+action.getBoldText(videoNumbers[i])+"  Video Started on current page")+"**************");
				j=i-1;
				if(action.isElementAvailable(driver,"//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']" ))
				//if(isElementPresent(By.xpath("(//span[contains(text(),'Tap for Sound')])["+i+"]"),"tap for sound"))
				{
					action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']"), 
							By.xpath("//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']"),"Tap for sound");
					action.staticWait(5);
					//videoMmodule=ParallelVideosOmnitureValues.videoMmoduleUnmute+(i+1);
					
					action.generateReport(!action.isElementAvailable(driver, "//*[@id='video_player_screen-"+j+"']//span[@class='video-player-volume-muted-button']"),
							"tap for sound is not visible on page after clicking on it",
							"tap for sound is visible on page after clicking on it");

					omnValue = VideoPlayerOminatureValues.videoMlinkUnmute + ","
							+ infositeVideoNumber;
				//	action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
					action.staticWait(5);
					String[] time=driver.findElement(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='curtimetext']")).getText().split(":");
				int value= Integer.parseInt(time[1]);
				if(value<=0) {
					action.generateFailReport("Video Is not Playing after clicking on Tap for Sound button");
					action.moveToElementandClick(VideosObjectRepo.playPauseBtn, VideosObjectRepo.playPauseBtn, "Play");
				}
				
         
				    }else {
				    	action.scrollToObject(driver.findElement(By.xpath("//*[@id='video_player_screen-"+j+"']")));
				    	action.generateFailReport("Tap for sound is Not displayed");
				    	action.generatePassReport("*****************Start call*****************");
						action.startNewHar();
						 action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),
				         		By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),"Play");
						action.staticWait(3);
						/*omnValue = VideoPlayerOminatureValues.videoMlinkPlay + "," + infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				    	*/
						omnValue = VideoPlayerOminatureValues.videoMlinkStart + "," + infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				    }
				
				action.staticWait(3);
				action.generatePassReport("*****************Pause Call*****************");
				action.startNewHar();
				 action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),
				 		By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),"pause");
				action.staticWait(2);
				omnValue = VideoPlayerOminatureValues.videoMlinkPause + "," + infositeVideoNumber;
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				action.generatePassReport("*****************Mute Call*****************");	
				action.startNewHar();
				 action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='button-mute']//button"),
				  		By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='button-mute']//button"),"Mute");
				omnValue = VideoPlayerOminatureValues.videoMlinkMute + ","
						+ infositeVideoNumber;
				action.staticWait(1);
				action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
				
				action.generatePassReport("*****************Maximize Call*****************");
						action.startNewHar();
						action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='fullscreen']"), By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='fullscreen']"), "Maximize");
						action.staticWait(2);
						omnValue = VideoPlayerOminatureValues.videoMlinkBigscreen + ","
								+ infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						
						action.generatePassReport("*****************Large Screen Mutex Call*****************");	
						action.startNewHar();
						 action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='button-mute']//button"),
				          		By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='button-mute']//button"),"Mutex");
					    omnValue = VideoPlayerOminatureValues.videoMlinkUnmute + ","
								+ infositeVideoNumber;
					    action.staticWait(1);
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						action.generatePassReport("*****************Large Screen Play Call*****************");
						action.staticWait(1);
						action.startNewHar();
				        action.staticWait(1);
					    action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),
				        By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),"Play");
						omnValue = VideoPlayerOminatureValues.videoMlinkPlay + "," + infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						action.generatePassReport("*****************Minimize Call*****************");
						action.startNewHar();
						action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='fullscreen']"), By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='fullscreen']"), "Minimize");
						action.staticWait(2);
						omnValue = VideoPlayerOminatureValues.videoMlinkSmallerscreen + ","
								+ infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						
						action.staticWait(2);
						action.generatePassReport("*****************Pause Call*****************");
						action.startNewHar();
						action.moveToElementandClick(By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),
				         		By.xpath("//*[@id='video_player_screen-"+j+"']//*[@class='playpause']//button"),"Pause");
						action.staticWait(2);
						omnValue = VideoPlayerOminatureValues.videoMlinkPause + "," + infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						
						videoscount=driver.findElements(VideosObjectRepo.videos);
						action.startNewHar();
						action.Dragprogressbar(By.xpath("//*[contains(@id,'video_player_screen-"+j+"')]//*[@class='progress-drag']"), 1000);
						action.generatePassReport("*****************25pct Call*****************");
						action.staticWait(8);
						omnValue = VideoPlayerOminatureValues.videoMlink25pct + ","
								+ infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");

						//validation of 50 pct calls
						action.generatePassReport("*****************50pct Call*****************");
						omnValue = VideoPlayerOminatureValues.videoMlink50pct + ","
								+ infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
				   
						//validation of 75 pct calls
						action.generatePassReport("*****************75pct Call*****************");
						omnValue = VideoPlayerOminatureValues.videoMlink75pct + ","
								+ infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
				    
						//validation of 100 pct calls
						action.generatePassReport("*****************100pct Call*****************");
						omnValue = VideoPlayerOminatureValues.videoMlink100pct + ","
								+ infositeVideoNumber;
						action.staticWait(2);
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,site,chn,dprofsn,dcntry,dspclty,regid,vapi", omnValue, "equals,notnull,notnull,notnull,notnull,optional,optional,notnull");
				   
						//validation of scrb calls
						action.generatePassReport("*****************Scrub Call*****************");
						omnValue = VideoPlayerOminatureValues.videoMlinkScrb + "," + infositeVideoNumber;
						action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,contains,notnull,notnull");
						//Validation of 3sec calls
						action.generatePassReport("***************************************************************************************************************************************************************");
						action.staticWait(2);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	         
			}

		
		
		
		
    }
    
}

package test.webmd.callsTracking;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;
import com.webmd.automation.utilities.Logs;

import io.appium.java_client.AppiumDriver;

@Listeners(com.webmd.automation.utilities.Listener.class)
public class AndroidHeadlineAppFunctional {

	public ActionMethods action;

	@BeforeClass(alwaysRun=true)
	public void startUpLogin(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser();
		//action.androidNativeAppLogin("mobileuser5","beige");

	}

	

	@Test(dataProvider = "getHeadlineData", groups = { "web", "headLine" }, dataProviderClass = DataProviderClass.class)
	public void VerifyHeadlineAndroidappAdFunctionalTest(String sno, String SFID, String headLineTactic,
			String headLineActivity, String adtitle, String headLineUser, String headLineUserPassword,
			String cpActivityParticipation, String cpActivityHeadImpr, String CPActivityImpr, String cpCallFilter,
			String articleid, String env, String sslNetworkFilter, String trackerMarker, String desktopPosition,
			String BrowserType) throws Exception {

		
		
		action.testLayerLinksAndroidApp(action.getDriver(), action.getproxyServer(), SFID, env);
		
		
		action.generatePassReport("================= Splash promro Ad Verification Started ===========");

		//Verify ad in splash view
		action.waitForSplashPromoAd(action.getAppiumDriver(),adtitle, headLineTactic, headLineActivity,env);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity ,env);
		WebDriverWait wait = new WebDriverWait(action.driver, 30);
		
		action.generatePassReport("================= News and perspective Ad Verification Started ===========");

		action.click(By.xpath("//*[@class='android.widget.ImageButton']"), "clicking on menu");
		action.click(By.xpath("//*[@text='News & Perspective']"), "clicking on NEWS and Perspective search box");
		Logs.logAndConsole("Looking for surfaced ads "+adtitle);
		int count1 = 0;
		while (count1 < 60) {

			if (action.isElementAvailable(action.getDriver(), "//*[contains(text(),'" + adtitle + "')]")) {
				action.generatePassReportWithScreenShot("Ad displayd "+adtitle);
				action.click(By.xpath("//*[contains(text(),'" + adtitle + "')]"), "Surfaced ad " + adtitle);
				Thread.sleep(1000);
				action.testLayerLinksAndroidApp(action.getDriver(), action.getproxyServer(), SFID, env);
				action.click(By.xpath("//*[@contentDescription='Navigate up']"), "Close layer ");

				break;
			}
			else {
				// action.swipe(665, 393, 734, 1293, 512);
				  //action.getIOSDriver().swipe(667, 582, 853, 1374, 519);
				action.getAppiumDriver().swipe(344, 337, 360, 1051, 966);
				Thread.sleep(3000);
				count1++;
			}
		}
	}

	
	@AfterClass(alwaysRun=true)
	public void shutDownLogin() throws Throwable {
		action.driver.quit();
	}

}

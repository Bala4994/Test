package test.webmd.tactic;


import org.openqa.selenium.By;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;

import test.webmd.callsTracking.DataProviderClass;

//@Listeners(com.webmd.automation.utilities.Listener.class)
public class Dismissal {

	public ActionMethods action, action1;

	@BeforeClass(alwaysRun = true)
	public void startUpDismissalBrowser(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser("chrome");
		action.loginCP();
		
		action1 = new ActionMethods(ctx);
		action1.launchBrowser("chrome");
	}
	
	
	@Test(dataProvider="getDismissalData",dataProviderClass=DataProviderClass.class)
	public void dismissalTactic(String GUID, String tacticID, String activityID, String medUserName, String medPassword, String ticket)   {

		action.generateBoldInfo("Ticket Number : " + ticket + "<br> GUID : " +GUID + "<br>  Tactic  : " +tacticID + "<br>  UserName  : " +medUserName); 
        action.driver.findElement(By.xpath("//input[@id='uid']")).clear();
		action.enter(By.xpath("//input[@id='uid']"), GUID, "GUID");
		action.enter(By.xpath("//input[@id='appname']"), "alert", "App name");

		
		action.enter(By.xpath("//input[@id='activityname']"), "headlineimpr", "headlineimpr");
		action.enter(By.xpath("//input[@id='tacticId']"), tacticID, "tacticId");
		
		action.enter(By.xpath("//input[@id='activityId']"), activityID, "activityId");
		
		action.enter(By.xpath("//input[@id='tcid1']"), tacticID, "tcid1");
		action.enter(By.xpath("//input[@id='tcid2']"), tacticID, "tcid2");
		
		action.enter(By.xpath("//input[@id='activityId1']"), activityID, "activityId1");
		action.enter(By.xpath("//input[@id='activityId2']"), activityID, "activityId2");
		action.getDriver().findElement(By.xpath(".//*[@id='eventButton_label']/span")).click();
        
        action1.login(medUserName,medPassword);
		action1.get("https://emedicine.staging.medscape.com/article/924411-overview");
		action1.viewSource(tacticID);
		
	
		int counter=1;
		for(int i=1; i<=7; i++) {
		
			action.getDriver().findElement(By.xpath(".//*[@id='eventButton_label']/span")).click();
			
			action.generateInfoReport("SendEvent clicked for "+ ++counter +" time");
			//System.out.println("SendEvent clicked for "+ counter++ +"time");
			
			action.staticWait(30);
			//driver1.switchTo().window(med_name);
			action1.viewSource(tacticID);
	
		}
		
	}
	

	@AfterClass(alwaysRun = true)
	public void shutDownSGVBrowser() throws Throwable {
		action.getDriver().quit();
		action1.getDriver().quit();

	}
}

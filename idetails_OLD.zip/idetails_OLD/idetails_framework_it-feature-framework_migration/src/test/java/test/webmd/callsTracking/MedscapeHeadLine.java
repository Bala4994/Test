package test.webmd.callsTracking;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;
import com.webmd.automation.utilities.GetHeadLineUsersWithRowRange;

//@Listeners(com.webmd.automation.utilities.Listener.class)
public class MedscapeHeadLine {

	public ActionMethods action;

	@BeforeClass(alwaysRun=true)
	public void startUpHeadLineTacTicAssignment(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.launchBrowser();
		action.assignTacticsToUsers(action.env);
		
	}

	@Test(dataProvider = "getHeadlineData", groups = {"headLineweb" }, dataProviderClass = DataProviderClass.class)
	public void VerifyHeadlineWebFunctionality(String sno, String SFID, String headLineTactic,
			String headLineActivity, String adtitle, String headLineUser, String headLineUserPassword,
			String cpActivityParticipation, String cpActivityHeadImpr, String CPActivityImpr, String cpCallFilter,
			String articleid, String env, String sslNetworkFilter, String trackerMarker, String desktopPosition,
			String BrowserType, String dataRange,String Onsite) throws Exception {
		
		action.generateBoldInfo("Ticket Number : " + sno + "<br> SF ID : " +SFID + "<br>  Tactic  : " +headLineTactic); 
		
		action.env =env;
		
		action.login(headLineUser,headLineUserPassword);
	
		//===============N&P home page validation
		action.generateBoldInfo(
				"================ Headline surfing at News &Perspective page is started =======================");
		action.startNewHar();
		String HeadlineNpURL = "https://www."+env+"medscape.com/"+action.prop.getProperty("homepageSpeciality");
		System.out.println("URL:"+HeadlineNpURL);
		//action.startNewHar();
		//action.get(HeadlineNpURL);
		
		GetHeadLineUsersWithRowRange data = new GetHeadLineUsersWithRowRange(dataRange);

		action.isTacticPresent(headLineTactic, headLineUser, data);
		
		//===================hp center ad =======================
		action.generateBoldInfo(
				"================ Headline surfing at News & Perspective hp_Left verification is started =======================");
		
		
		//action.is2AdsDisplayed(HeadlineNpURL, SFID, "hp_center", "hp_left", headLineTactic, headLineUser,headLineActivity,adtitle,env,data);
		action.isSingleAdDisplayed(HeadlineNpURL, SFID, "hp_left", headLineTactic, headLineUser, headLineActivity,adtitle, env,data);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity);
		
	
		
		//=============================Reference URL ==============================
		action.generateBoldInfo(
				"================Headline surfing at Reference home page is started=======================");
	
		action.startNewHar();
		//action.get("https://reference."+env+"medscape.com/");
		
		action.isTacticPresent(headLineTactic, headLineUser,data);
	
		//=============================refhp_left ==============================	
		
		action.isSingleAdDisplayed("https://reference."+env+"medscape.com/", SFID, "refhp_left", headLineTactic, headLineUser, headLineActivity,adtitle, env,data);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity);
		
		
		//=============View Article validation ==================
		action.generateBoldInfo(
				"================Headline surfing at view article page is started=======================");
		action.startNewHar();
		String viewarticle = "https://www."+env+"medscape.com/viewarticle/892737";
		action.get(viewarticle);
		 
		action.isTacticPresent(headLineTactic, headLineUser,data);
		 
         
       //=============================desktop_fb ==============================	
        String desktop_fb = "//a[contains(@href,'desktop_fb') and contains(@href,'" + SFID + "')]";
 		
        HashMap<String, Boolean> OnsiteFlagMap=action.isSingleAdDisplayed(viewarticle, SFID, "desktop_fb", headLineTactic, headLineUser, headLineActivity,adtitle,env,data);
       Boolean OnsiteFlag= OnsiteFlagMap.get("hp2Ad");
        if(!OnsiteFlag){
        	action.generateBoldInfo("=================Onsite page Verification Started=================");
        	action.startNewHar();
        	action.loadURL(Onsite);
        	//action.VerifypageNotFound();
        	action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
            action.validateImages(action.getproxyServer(), env,SFID);
           // action.validateHeadLineParticipationCall(headLineTactic, headLineActivity,env);
            action.headlineapicallparticipation(headLineTactic, headLineActivity, env);
            action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
            action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
    		action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
        	
    	   
       }else{
 		//action.validateHeadLineImprCall(headLineTactic, headLineActivity);
         
 		try {
			//handle sgv layer if displays 
			action.getDriver().findElement(By.id("nDlayer_close")).click();
		} catch (Exception e) {
			
		}
 		//handle consult layer
 		action.clickCloseConsultLayer();
 		action.startNewHar();
        action.click(By.xpath(desktop_fb), SFID +" desktop_fb" );
        
        
        action.generatePassReportWithScreenShot("Find below screenshot for headline onsite page");
        action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
        action.validateImages(action.getproxyServer(), env,SFID);
        //action.validateHeadLineParticipationCall(headLineTactic, headLineActivity,env);
        action.headlineapicallparticipation(headLineTactic, headLineActivity, env);
        action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
        action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
		action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
	}
	}
	
	@Test(dataProvider = "getHeadlineData", groups = {"headLineandroid" }, dataProviderClass = DataProviderClass.class)
	public void VerifyHeadlineAndroidMobileFunctionality(String ticketNo, String SFID, String headLineTactic,
			String headLineActivity, String adtitle, String headLineUser, String headLineUserPassword,
			String cpActivityParticipation, String cpActivityHeadImpr, String CPActivityImpr, String cpCallFilter,
			String articleid, String env, String sslNetworkFilter, String trackerMarker, String desktopPosition,
			String BrowserType, String dataRange,String Onsite) throws Exception {
		
		action.generateBoldInfo("Ticket Number : " + ticketNo + "<br> SF ID : " +SFID + "<br>  Tactic  : " +headLineTactic); 
		action.env =env;
		action.login(headLineUser,headLineUserPassword);
		//action.popupHandle();
		
		//===============N&P home page validation
		action.generateBoldInfo(
				"================Headline surfing at News & Perspective home page is started=======================");
		action.startNewHar();
		String HeadlineNpURL = "https://www." +env+ "medscape.com/"+action.prop.getProperty("homepageSpeciality");
		
		//action.startNewHar();
		//action.get(HeadlineNpURL);

		GetHeadLineUsersWithRowRange data = new GetHeadLineUsersWithRowRange(dataRange);
		action.isTacticPresent(headLineTactic, headLineUser, data);
		
		//===================hp hp2 hp5 =======================
		action.generateBoldInfo(
				"================Headline surfing at News & Perspective hp2  verification is started=======================");
		
		//action.is2AdsDisplayed(HeadlineNpURL, SFID, "hp_2", "hp_5", headLineTactic, headLineUser,headLineActivity,adtitle,env,data);
		action.isSingleAdDisplayed(HeadlineNpURL, SFID, "hp_2", headLineTactic, headLineUser, headLineActivity,adtitle, env,data);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity);
		
		//=============================Reference URL ==============================
		action.generateBoldInfo(
				"================Headline surfing at Reference home page is started=======================");
	
		action.startNewHar();
		action.get("https://reference."+env+"medscape.com/");
		
		action.isTacticPresent(headLineTactic, headLineUser,data);
	
		//=============================mobile_refhp_top ==============================	
		
		HashMap<String, Boolean> OnsiteFlagMap=action.isSingleAdDisplayed("https://reference."+env+"medscape.com/", SFID, "mobile_refhp_top", headLineTactic, headLineUser,headLineActivity,adtitle,env,data);
		//action.validateHeadLineImprCall(headLineTactic, headLineActivity);
		 Boolean OnsiteFlag= OnsiteFlagMap.get("hp2Ad");
	        if(!OnsiteFlag){
	        	action.generateBoldInfo("=================Onsite page Verification Started=================");
	        	action.startNewHar();
	        	action.loadURL(Onsite); 
	        	//action.VerifypageNotFound();
	        	action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")).replace("� Return to Medscape   Privacy Policy", ""));
	            action.validateImages(action.getproxyServer(), env,SFID);
	            //action.validateHeadLineParticipationCall(headLineTactic, headLineActivity,env);
	            action.headlineapicallparticipation(headLineTactic, headLineActivity, env);
	            action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
	            action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
	            action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
	        	
	    	   
	       }else{
		
		try {
			//handle sgv layer if displays 
			action.getDriver().findElement(By.id("agtCloseBtn")).click();
		} catch (Exception e) {
			
		}
		 action.clickCloseConsultLayer();
		 action.startNewHar();
		 action.click(By.xpath("//a[contains(@href,'mobile_refhp_top') and contains(@href,'" + SFID + "')]"), "mobile_refhp_top");
		 action.generatePassReportWithScreenShot("Find below screenshot for headline onsite page");
		 action.generatePassReport(action.getBoldText("Sponsred Title:")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		 //action.validateHeadLineParticipationCall(headLineTactic, headLineActivity,env);  
		 action.headlineapicallparticipation(headLineTactic, headLineActivity, env);
		 //action.generatePassReport(action.getBoldText("Sponsred Title: ")+action.getText(By.xpath("//*[@id='contentblock']//*[@id='sponsordiv']")));
		 action.validateImages(action.getproxyServer(), env,SFID);
		 action.validateDoubleclickTags(action.getproxyServer(), env,SFID);
		  action.pollSubmit(action.getDriver(), By.xpath("//*[@class='qatable']//tbody//tr[@class='question']"), By.xpath("//*[@id='polltable']//input[@name='submitbutton']"));
		 action.testLayerLinks(action.getDriver(), action.getproxyServer(), SFID, env);
      
	       }
	}
	
	@AfterClass(alwaysRun=true)
	public void shutDownHeadLineBrowser() throws Throwable {
		action.driver.quit();
		action.generatePassReport(action.browserName+" closed");
		action.getproxyServer().stop();

	}


}

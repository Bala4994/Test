package test.webmd.tactic;
	import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
	import org.testng.annotations.AfterClass;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Test;

import com.webmd.automation.utilities.ExtentTestManager;

	

	public class Reporting {
		public WebDriver driver1;
		

		@BeforeClass(alwaysRun=true)
		public void startUpEamilerBrowser(ITestContext ctx) throws Throwable {

			System.setProperty("webdriver.chrome.driver", "C:\\Users\\BaLU\\Downloads\\chromedriver_win32\\chromedriver.exe");
			driver1 = new ChromeDriver(); 
			
		}
		
		@Test
		public void VerifyEmailValidation() throws Exception{
			ExtentTestManager.startTest("Started");
			driver1.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//driver1.get("www.facebook.com");
			System.out.println("==============");
			ExtentTestManager.endTest();
			}
			
			
		
		@AfterClass(alwaysRun=true)
		public void shutDownEmailBrowser() throws Throwable {
			driver1.close();
			System.out.println("==============");

		}
	}



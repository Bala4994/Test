package test.webmd.callsTracking;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;

public class EmailerValidation {
	public ActionMethods action;
	

	@BeforeClass(alwaysRun=true)
	public void startUpEamilerBrowser(ITestContext ctx) throws Throwable {

		action = new ActionMethods(ctx);
		action.EmailerLaunching();
		
	}
	
	@Test(dataProvider = "getEmailerData", groups = {"emailer" }, dataProviderClass = DataProviderClass.class)
	public void VerifyEmailValidation(String Date,String UserName,String Password,String SFNumber,String Promo,String Status,String Client,String Brand,String Product,String Mailername,String EIStatus,String SLNumber,String Prooffileurl) throws Exception{
		
		action.generateBoldInfo("SF Number : " + SFNumber + "<br> Promo ID : " +Promo + "<br>  EMailer Date  : " +Date);
		WebDriver driver=action.EmailerLogin();
		Map records=action.PromoRecords(driver,Date, Promo);
		if(!records.isEmpty()||!records.equals(null)){
		action.generateBoldInfo("Emailer name: "+(String) records.get("New Mailer Name"));
		action.verifyEmailerSF(records, SFNumber);
		action.verifyEmailerBrand(records, Brand);
		action.verifyEmailerclient(records, Client);
		action.verifyEmailerEIStatus(records, EIStatus);
		action.verifyEmailerQAurl(records,UserName,Password);
		action.verifyProofLinks(Prooffileurl);
		//action.verifyProofLinks(url);
		}
		
		
	}
	@AfterClass(alwaysRun=true)
	public void shutDownEmailBrowser() throws Throwable {
		action.driver.quit();
		//action.getproxyServer().stop();

	}
}

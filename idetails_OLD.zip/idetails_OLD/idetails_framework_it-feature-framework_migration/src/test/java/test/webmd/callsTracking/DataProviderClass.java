package test.webmd.callsTracking;

import org.testng.annotations.DataProvider;

import com.webmd.automation.utilities.XlRead;

public class DataProviderClass {

	@DataProvider
	public static String[][] getSGVData() {

		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "SGV");

	}
	@DataProvider
	public static String[][] getDMSGVData() {

		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "DMSGV");

	}
	@DataProvider
	public static String[][] getHeadlineData() {
		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "Headline");
	}
	
	@DataProvider
	public static String[][] getDriverData() {
		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "Driver");
	}
	
	@DataProvider
	public static String[][] getDismissalData() {
		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "Dismissal");
	}
	
	@DataProvider
	public static String[][] getBAData() {
		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "BA");
	}
	@DataProvider
	public static String[][] getEmailerData() {
		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "Emailer");
	}
	@DataProvider
	public static String[][] infositeData() {
		return XlRead.fetchDataExcludingFirstRow("TestInputs/Sample_Idetails.xls", "Infosite");
	}
	
}

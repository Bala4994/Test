package test.webmd.callsTracking;

import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.webmd.automation.accel.ActionMethods;
import com.webmd.automation.accel.VideoPlayerOminatureValues;
import com.webmd.automation.accel.VideosObjectRepo;

public class Videos_Tracking_idetails {

	public String hashValue;
	public String omnValue;
	public String curArticle;
	public String mPage;
	public VideoPlayerOminatureValues omnValues;
	public int i;
	int size = 0;
	boolean isTapForSoundDisplayed = false;
    public String domainName="https://ssl.o.webmd.com/b/ss";
    
    @Test
    public void performVideoTracking(WebDriver driver,ActionMethods action,String environmnet,String SFID) {
    	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		action.generatePassReport("================= Video Player Omniture Tracking Started ===========");
		action.startNewHar();
		String omnValue = "";
		mPage = "/alert";
		domainName = "https://ssl.o.webmd.com/b/ss";
		action.waitForElement(VideosObjectRepo.tapForSoundBtn, "tap For Sound");
		driver.manage().window().maximize();
		action.staticWait(2);
		action.scrollToObject(driver.findElement(VideosObjectRepo.videoPlayer));
		//action.scrollToObject(action.driver.findElement(By.id("//*[@id='ck-editor-text-2'][1]/ul/li[2]")));
		//action.staticWait(2);

		
		//Validation of mute calls 
		action.generatePassReport("*****************Verification of Video present in article*****************");
		if (action.isElementAvailable(driver, "//*[@class='tap-for-sound-button']")) {
			System.out.println("Tap for sound displayed: Video is present on the article");
			omnValue = VideoPlayerOminatureValues.videoMlinkMute + ","
					+ VideoPlayerOminatureValues.alertVideoMmoduleMute;
			//action.verifyOmnitureValues(action.getproxyServer(),domainName, "mlink,mmodule,mpage,mpgtitle", omnValue, "equals,equals,notnull,notnull");
			
			isTapForSoundDisplayed=true;
			action.generateReport(action.isElementAvailable(driver, "//*[@class='tap-for-sound-button']"),
					"Video is visible on page", "Video is not visible on page");
		}
		
		//Validation of mutex calls
		action.generatePassReport("*****************Mutex Call*****************");
		action.click(VideosObjectRepo.tapForSoundBtn, "tap for sound");
		action.generateReport(!action.isElementAvailable(driver, "//div[contains(@class,'tap-for-sound is-muted')]"),
				"tap for sound is not visible on page after clicking on it",
				"tap for sound is visible on page after clicking on it");

		//omnValue = VideoPlayerOminatureValues.videoMlinkUnmute + ","
			//	+ VideoPlayerOminatureValues.alertVideoMmoduleUnmute;
		Hashtable<String, String> stdValues=action.getOminitureVideo(action.getproxyServer(), domainName, environmnet, VideoPlayerOminatureValues.videoMlinkUnmute, SFID, VideoPlayerOminatureValues.alertVideoMmoduleUnmute);
		action.generateReport(stdValues.size()>0,action.getBoldText("Attributes Tracked in 1st Ominiture  call:")+"<br>"+action.getBoldText("g:") + stdValues.get("g") + "<br>"+action.getBoldText("mmodule :") + stdValues.get("mmodule")+"<br>"+action.getBoldText("mpage:") + stdValues.get("mpage") + "<br>"+action.getBoldText("mlink:")
		+ stdValues.get("mlink") + "<br>"+action.getBoldText("mpgtitle:") + stdValues.get("mpgtitle"),"Unable to Track ssl call for"+VideoPlayerOminatureValues.videoMlinkUnmute);
    }
}

package com.webmd.automation.utilities;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.relevantcodes.extentreports.LogStatus;

public class Listener implements IInvokedMethodListener, ITestListener {

	private String methodName;

	// This belongs to IInvokedMethodListener and will execute before every
	// method including @Before @After @Test
	
	private synchronized String getCurrentMethodNames(ITestResult result) {
		return  PrivateMethods.getBrowserName(result).toUpperCase() + " => "
				+ result.getMethod().getMethodName()+PrivateMethods.getBrowserName(result).toUpperCase() + " > "
				+ result.getTestContext().getName();
	}
	public synchronized void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		Logs.logAndConsole("=========================================================");
		Logs.logAndConsole(" Execution Started for " + method.getTestMethod().getMethodName() + "");
		Logs.logAndConsole("=========================================================");
		methodName = methodName+getCurrentMethodNames(testResult);
		ExtentTestManager
				.startTest(PrivateMethods.getBrowserName(testResult).toUpperCase() + " => " + method.getTestMethod().getMethodName())
				.assignCategory(
						PrivateMethods.getBrowserName(testResult).toUpperCase() + " > " + testResult.getTestContext().getName());
		ExtentTestManager.getTest().log(LogStatus.INFO,
				"**********  Execution Started for " + method.getTestMethod().getMethodName() + " **********");
		//GalenTestManager.startTest(method.getTestMethod().getMethodName());
		
	}

	// This belongs to IInvokedMethodListener and will execute after every
	// method including @Before @After @Test
	public synchronized void  afterInvocation(IInvokedMethod method, ITestResult testResult) {
		if (testResult.getStatus() == ITestResult.FAILURE) {
			ExtentTestManager.getTest().log(LogStatus.FAIL, PrivateMethods.getException(testResult.getThrowable()));
			ExtentTestManager.getTest().log(LogStatus.INFO,
					"********** Execution ended for " + method.getTestMethod().getMethodName() + " **********");
		
		}else if(testResult.getStatus() == ITestResult.SUCCESS){
			ExtentTestManager.getTest().log(LogStatus.INFO,
					"********** Execution ended for " + method.getTestMethod().getMethodName() + " **********");
		}
		Logs.logAndConsole("=========================================================");
		Logs.logAndConsole("Execution ended for " + method.getTestMethod().getMethodName() + "");
		Logs.logAndConsole("=========================================================");
		ExtentManager.getReporter().endTest(ExtentTestManager.getTest());
		ExtentManager.getReporter().flush();
		ExtentTestManager.endTest();
		//GalenTestManager.endTest();
		//ExtentManager.getGalenReporter(GalenTestManager.tests);
	}

	@Override
	public synchronized void onTestSkipped(ITestResult result) {
		Logs.logAndConsole("< ========================================================= >");
		Logs.logAndConsole(" Execution SKIPPED for "+PrivateMethods.getBrowserName(result).toUpperCase() + " "
				+ result.getMethod().getMethodName());
		Logs.logAndConsole("< ========================================================= >");
	
		
		ExtentTestManager
							.startTest(PrivateMethods.getBrowserName(result).toUpperCase() + " => "
									+ result.getMethod().getMethodName())
							.assignCategory(PrivateMethods.getBrowserName(result).toUpperCase() + " > "
									+ result.getTestContext().getName());
					ExtentTestManager.getTest().log(LogStatus.INFO, "< < < < < Execution Started for "
							+ result.getMethod().getMethodName() + " > > > > >");

		ExtentTestManager.getTest().log(LogStatus.SKIP, "Test skipped : " + PrivateMethods.getException(result.getThrowable()));
		ExtentManager.getReporter().flush();
		ExtentTestManager.endTest();
		//GalenTestManager.endTest();
		//ExtentManager.getGalenReporter(GalenTestManager.tests);
	}
	@Override
	public synchronized void onTestStart(ITestResult result) {
	}
	@Override
	public synchronized void onTestSuccess(ITestResult result) {
	}

	@Override
	public synchronized void onTestFailure(ITestResult result) {
	}

	@Override
	public synchronized void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public synchronized void onStart(ITestContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public synchronized void onFinish(ITestContext context) {
		// TODO Auto-generated method stub

	}

}
package com.webmd.automation.accel;

/**
 * N&P Gasto Home page Omniture calls
 * @author Abhigna Bheemu
 *
 */
public class VideoPlayerOminatureValues {
	
	
	public VideoPlayerOminatureValues() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static String infositeVideoNumber ="vidsvp-video3";
	public static String videoMlinkStart ="start";
	public static String videoMmoduleStart ="vidvbp";
	public static String videoMlinkPlay ="play";
	public static String videoMmodulePlay ="vidvbp-ctl";
	
	public static String videoMlinkPause ="pause";
	public static String videoMmodulePause ="vidvbp-ctl";
	public static String videoMlinkMute ="mute";
	public static String videoMmoduleMute ="vidvbp-ctl";
	public static String videoMlinkUnmute ="mutex";
	public static String videoMmoduleUnmute ="vidvbp-ctl";
	public static String videoMlinkCcon ="ccy";
	public static String videoMmoduleCcon ="vidvbp-ctl";
	public static String videoMlinkCcoff ="ccn";
	public static String videoMmoduleCcoff ="vidvbp-ctl";
	public static String videoMlinkBigscreen ="bigr";
	public static String videoMmoduleBigscreen ="vidvbp-ctl";
	public static String videoMlinkSmallerscreen ="smalr";
	public static String videoMmoduleSmallerscreen ="vidvbp-ctl";
	public static String videoMmoduleDuratiom ="vidvbp";
	public static String videoMlink25pct ="25pct";
	public static String videoMlink50pct ="50pct";
	
	public static String videoMlink75pct ="75pct";
	public static String videoMlink100pct ="100pct";
	public static String videoMlinkAllvideo100pct ="100pct";
	public static String videoMmoduleAllvideo100pct ="allvideo";
	public static String videoMlinkScrb ="scrb";
	public static String videoMmoduleScrb ="vidvbp-ctl";
	
	public static String alertMlinkSubmit="submit";
	public static String alertMmoduleSubmit="vidvbp-ctl-1";
	
	public static String videoMlink3Sec ="3sec";

	public static String alertVideoMmoduleStart ="vidsvp-video1";

	public static String alertVideoMmodulePlay ="vidsvp-video1";

	public static String alertVideoMmodulePause ="vidsvp-video1";
	public static String alertVideoMmoduleMute ="vidsvp-video1";
	public static String alertVideoMmoduleUnmute ="vidsvp-video1";
	public static String alertVideoMmoduleCcon ="vidsvp-video1";
	public static String alertVideoMmoduleCcoff ="vidsvp-video1";
	public static String alertVideoMmoduleBigscreen ="vidsvp-video1";
	public static String alertVideoMmoduleSmallerscreen ="vidsvp-video1";
	public static String alertVideoMmoduleDuratiom ="vidsvp-video1";
	public static String alertVideoMmoduleAllvideo100pct ="allvideo";
	public static String alertVideoMmoduleScrb ="vidsvp-video1";
    public static String alertVideoMmoduleReplay ="vidsvp-video1";
	public static String alertVideoMmodule3sec ="pvtime";
	public static String alertMLinkReplay="rep";
	public static String alertMLinkExpand="expand";
	public static String alertMLinkCollapse="collapse";
	public static String alertMmoduleISI="isi-isi";
	
	
	//Tracking Pixel Calls
	
	public static String trackingActionUrl="https://img.staging.medscapestatic.com/pi/core/amp-premier/images/hd_meter_up.png";
	public static String trackingUrl="https://img.staging.medscapestatic.com/pi/core/amp-premier/images/hd_meter_down.png";
	public static String trackingEventMute ="?action=mute";
	public static String trackingEventStart ="?page=start";
	public static String trackingEventPlay ="?action=play";
	public static String trackingEventUnMute ="?action=unmute";
	public static String trackingEventPause ="?action=pause";
	public static String trackingEventBigscreen ="?action=fullscreen";
	public static String trackingEventSmallscreen ="?action=collapse";
	public static String trackingEvent0Pct="?progress=0pct";
	public static String trackingEvent25Pct="?progress=25pct";
	public static String trackingEvent50Pct="?progress=50pct";
	public static String trackingEvent75Pct="?progress=75pct";
	public static String trackingEvent100Pct="?progress=100pct";

	public static String qnaMmoduleSubmit="qna-qna-1";
	public static String mPageTitle="test ba";
	public static String videoMlink0pct ="0pct";
	
	public static String trackingUrlForBrandPlay="https://img.staging.medscapestatic.com/pi/core/amp-premier/images/";
	public static String trackingEvent0PctVideo1="video1_0.png";
	public static String trackingEvent25PctVideo1="video1_25.png";
	public static String trackingEvent50PctVideo1="video1_50.png";
	public static String trackingEvent75PctVideo1="video1_75.png";
	public static String trackingEvent100PctVideo1="video1_100.png";
	
	public static String trackingEvent0PctVideo2="Video2_0.png";
	public static String trackingEvent25PctVideo2="Video2_25.png";
	public static String trackingEvent50PctVideo2="Video2_50.png";
	public static String trackingEvent75PctVideo2="Video2_75.png";
	public static String trackingEvent100PctVideo2="Video2_100.png";
	
	public static String trackingEvent0PctVideo3="Video3_0.png";
	public static String trackingEvent25PctVideo3="Video3_25.png";
	public static String trackingEvent50PctVideo3="Video3_50.png";
	public static String trackingEvent75PctVideo3="Video3_75.png";
	public static String trackingEvent100PctVideo3="Video3_100.png";
	
	public static String trackingEvent0PctVideo4="Video4_0.png";
	public static String trackingEvent25PctVideo4="Video4_25.png";
	public static String trackingEvent50PctVideo4="Video4_50.png";
	public static String trackingEvent75PctVideo4="Video4_75.png";
	public static String trackingEvent100PctVideo4="Video4_100.png";
	
	public static String trackingEvent0PctVideo5="Video5_0.png";
	public static String trackingEvent25PctVideo5="Video5_25.png";
	public static String trackingEvent50PctVideo5="Video5_50.png";
	public static String trackingEvent75PctVideo5="Video5_75.png";
	public static String trackingEvent100PctVideo5="Video5_100.png";
	
	public static String trackingEvent0PctVideo6="Video6_0.png";
	public static String trackingEvent25PctVideo6="Video6_25.png";
	public static String trackingEvent50PctVideo6="Video6_50.png";
	public static String trackingEvent75PctVideo6="Video6_75.png";
	public static String trackingEvent100PctVideo6="Video6_100.png";
	
	public static String vcb3DMmoduleSubmit="gm-giftmanager";
	
	public static String mModuleShareEmail="share-email";
	public static String mModuleShareEmailClose="share-email-close";
	public static String mModuleSubmit="submit";

	public static String mModuleTrialVideo="vidsvp-video-trial";
	public static String mModuleCardioVideo="vidsvp-cardiac-troponin";
	public static String mModuleHorizontalVideo3="vidsvp-video-2";
	public static String mModuleHorizontalVideo4="vidsvp-video-1";
	
	public static String mLinkReplies="reply";
	public static String mModuleRepliesAndRespond="ct-wdgt";
	public static String mLinkRespond="rsp";
	
	
	public static String clientProgramMmodulePause ="vidsvp-video1";
	public static String clientProgramMmoduleMute ="vidsvp-video1";
	public static String clientProgramMmoduleUnmute ="vidsvp-video1";
	public static String clientProgramMmoduleCcon ="vidsvp-video1";
	public static String clientProgramMmoduleCcoff ="vidsvp-video1";
	public static String clientProgramMmoduleBigscreen ="vidsvp-video1";
	public static String clientProgramMmoduleSmallerscreen ="vidsvp-video1";
	public static String clientProgramMmoduleDuration ="vidsvp-video1";
	public static String clientProgramMmodulePlay ="vidsvp-video1";
	public static String clientProgramMmoduleStart ="vidsvp-video1";
	public static String clientProgramMmoduleAllvideo100pct ="allvideo";
	public static String clientProgramMmoduleScrb ="vidsvp-video1";
    public static String clientProgramMmoduleReplay ="vidsvp-video1";
	public static String clientProgramMmodule3sec ="pvtime";
	
}

package com.webmd.automation.utilities;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Logs {
	static Properties props = new Properties();
	static Logger log;

	static public synchronized void logAndConsole(String details) {
		init();
		log.info(details);
		System.out.println(details);
		System.out.println();
	}
	
	static public synchronized void console(String details) {
		System.out.println(details);
		System.out.println();
	}
	
	static public synchronized void log(String details) {
		init();
		log.info(details);
	}
	
	
	private static void init() {
		if (log == null) {
			try {
				PropertyConfigurator.configure("log4j.properties");
			log = Logger.getLogger("rootLogger");
			} catch (Exception e) {
			}

		}
	}
}

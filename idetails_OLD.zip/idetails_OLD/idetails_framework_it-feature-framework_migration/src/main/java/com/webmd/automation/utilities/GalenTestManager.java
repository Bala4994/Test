package com.webmd.automation.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.galenframework.reports.GalenTestInfo;
import com.galenframework.reports.model.LayoutReport;

public class GalenTestManager {
	
	static Map galenTestMap = new HashMap();

    public static  GalenTestInfo testInfo;
   	public static List<GalenTestInfo> tests =new  ArrayList<GalenTestInfo>();
   	public LayoutReport layoutReport;
    

    public static synchronized void endTest() {
        tests.add(testInfo);
    }

    @SuppressWarnings("unchecked")
	public static synchronized GalenTestInfo startTest(String desc) {
        GalenTestInfo test =GalenTestInfo.fromString(desc);
        testInfo=test;
        galenTestMap.put((int) (long) (Thread.currentThread().getId()), test);

        return test;
    }
    @SuppressWarnings("unchecked")
	public static synchronized void addLayout(LayoutReport layoutReport, String title) {
        //GalenTestInfo test =GalenTestInfo.fromString(desc);
        testInfo.getReport().layout(layoutReport, title);
        galenTestMap.put((int) (long) (Thread.currentThread().getId()), title);

        //return test;
    }
    
    @SuppressWarnings("unchecked")
	public static synchronized GalenTestInfo addInfo(String title) {
        //GalenTestInfo test =GalenTestInfo.fromString(desc);
        testInfo.getReport().error(title);
        galenTestMap.put((int) (long) (Thread.currentThread().getId()), title);

        return testInfo;
    }

}

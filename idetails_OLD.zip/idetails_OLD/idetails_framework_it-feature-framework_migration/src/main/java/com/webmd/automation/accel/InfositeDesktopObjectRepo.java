package com.webmd.automation.accel;

public class InfositeDesktopObjectRepo {

}

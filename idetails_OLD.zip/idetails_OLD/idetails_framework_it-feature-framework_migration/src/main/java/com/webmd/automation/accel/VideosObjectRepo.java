package com.webmd.automation.accel;

import org.openqa.selenium.By;

public class VideosObjectRepo {

	public static By slidePresentationTopOfThePage = By.xpath("(//*[@class='carousel-arrow next-button'])[1]");
	public static By totalSlidesTopOfThePage=By.xpath("(//*[@class='slide-total'])[1]");
	public static By salidePresentationBottomOfThePage = By.xpath("(//*[@class='carousel-arrow next-button'])[2]");
	public static By totalSlidesBottomOfThePage=By.xpath("(//*[@class='slide-total'])[2]");
	
	public static By videoPlayer=By.xpath("//*[@id='video_player_screen-0']");
	public static By tapForSoundBtn=By.xpath("//*[@class='tap-for-sound-button']");
	public static By videos = By.xpath("//div[contains(@id,'video_player_screen')]");
	public static By playPauseBtn=By.xpath("//*[@class='playpause']");
	public static By volumeControlBtn=By.xpath("//*[@class='volume-wrap volume-bar-background']");
	public static By volumeControlButtonInLargeScreen=By.xpath("//*[@class='button-mute']");
	public static By fullScreenBtn=By.xpath("//*[@class='fullscreen']");
	public static By progressBarBtn=By.xpath("//*[@class='video-progress on-progress-drag']");
	
	public static By expandCollapseButton=By.xpath("//*[@class='toggle-button']");
	public static By emailLink=By.xpath("//*[@class='groupEmail']");
	public static By recipientEmailTxtField=By.xpath("//*[@class='recipient-container']/input");
	public static By emailSendBtn=By.xpath("//*[@class='button send-button']");
	public static By closeBtn=By.xpath("//*[@class='modal-content-container']//a");
	public static By currentTime=By.xpath("//*[@class='curtimetext']");
	
	
}

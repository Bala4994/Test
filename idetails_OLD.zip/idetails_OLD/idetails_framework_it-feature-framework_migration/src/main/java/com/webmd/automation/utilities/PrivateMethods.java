package com.webmd.automation.utilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.proxy.CaptureType;

public class PrivateMethods {
	private  final String JS_GET_VIEWPORT_WIDTH = "var width = undefined; if (window.innerWidth) {width = window.innerWidth;} else if (document.documentElement && document.documentElement.clientWidth) {width = document.documentElement.clientWidth;} else { var b = document.getElementsByTagName('body')[0]; if (b.clientWidth) {width = b.clientWidth;}};return width;";
	private  final String JS_GET_VIEWPORT_HEIGHT = "var height = undefined;  if (window.innerHeight) {height = window.innerHeight;}  else if (document.documentElement && document.documentElement.clientHeight) {height = document.documentElement.clientHeight;}  else { var b = document.getElementsByTagName('body')[0]; if (b.clientHeight) {height = b.clientHeight;}};return height;";
	public  BrowserMobProxyServer proxy = null;
	public  AppiumDriver iosDriver =null;

	public  BrowserMobProxyServer getproxy(){
		return proxy;
	}
	public static String getParamValue(ITestContext ctx, String param) {
		try {
			return (ctx.getCurrentXmlTest().getParameter(param)).toString();

		} catch (Exception e) {
			return new ReadProperties().prop.getProperty(param);
		}
	}

	public static String getBrowserName(ITestResult testResult) {
		String browserName = PrivateMethods.getParamValue(testResult.getTestContext(), "browserName");
		String breakPoint = PrivateMethods.getParamValue(testResult.getTestContext(), "breakPoint");

		return browserName + "> BP >" + breakPoint;
	}

	// Browser resizing method to viewport
	public  Dimension getViewportSize(WebDriver driver) {
		int width = extractViewportWidth(driver);
		int height = extractViewportHeight(driver);
		return new Dimension(width, height);
	}

	private  int extractViewportWidth(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		int viewportWidth = Integer.parseInt(js.executeScript(JS_GET_VIEWPORT_WIDTH, new Object[0]).toString());
		return viewportWidth;
	}

	private  int extractViewportHeight(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		int result = Integer.parseInt(js.executeScript(JS_GET_VIEWPORT_HEIGHT, new Object[0]).toString());
		return result;
	}

	public WebDriver openBrowser(Properties prop, WebDriver driver, String browserName, String breakPoint,String proxyPort) {
		driver = launchWebBrowser(prop, driver, browserName, breakPoint , proxyPort);

		if (! (browserName.equalsIgnoreCase("android") || browserName.equalsIgnoreCase("androidApp") || browserName.equalsIgnoreCase("iosweb")|| browserName.equalsIgnoreCase("iosnativeapp"))) {

			setBrowserSize(driver, breakPoint);
			Dimension browserSize = driver.manage().window().getSize();
			Dimension actualViewportSize = getViewportSize(driver);
			driver.manage().window().setSize(new Dimension(2 * browserSize.width - actualViewportSize.getWidth(),
					2 * browserSize.height - actualViewportSize.getHeight()));
		}

		return driver;
	}

	
	@SuppressWarnings("deprecation")
	private WebDriver launchWebBrowser(Properties prop, WebDriver driver, String browserName, String breakPoint ,String proxyPort) {
		String driversLocation = prop.getProperty(Constantns.DRIVERS_LOCATION);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		//capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability("acceptInsecureCerts", true);
		
		if (prop.getProperty(Constantns.BROWSER_MOB_PROXY).equals("true")) {
			
			List<String> allowUrlPatterns = new ArrayList<String>();
		  //  allowUrlPatterns.add("https?://.*(medscape)+.*");
		  //  allowUrlPatterns.add(".*(ssl)+.*");
			proxy = new BrowserMobProxyServer();
			//proxy.stop();
			System.out.println("Port  :"+Integer.parseInt(proxyPort));
			
			
			try {
				proxy.start(Integer.parseInt(proxyPort));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// All the URLs that are not from our sites are blocked and a status code of 403 is returned
			//proxy.whitelistRequests(allowUrlPatterns, 404);
			proxy.blacklistRequests("s.tagsrvcs.com", 404);
			
			//int port = proxy.getPort();
			// get the Selenium proxy object
			Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
			// enable more detailed HAR capture, if desired (see CaptureType for the
			// complete list)
			proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);
			seleniumProxy.setHttpProxy("localhost:"+ proxy.getPort()); //The port generated by server.start();

			seleniumProxy.setSslProxy("localhost:"+ proxy.getPort());
			proxy.setHarCaptureTypes(CaptureType.getHeaderCaptureTypes());
			capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
		}
		
		

		switch (browserName) {
		case "ff":
		case "firefox":
			System.setProperty("webdriver.gecko.driver", driversLocation + Constantns.GECKO_DRIVER);
			driver = new FirefoxDriver(capabilities);
			break;
		case "chrome":
			System.setProperty("webdriver.chrome.driver", driversLocation + Constantns.CHROME_DRIVER);
			setUserAgent(capabilities, breakPoint);
			driver = new ChromeDriver(capabilities);
			break;
		case "ie":
			System.setProperty("webdriver.ie.driver", driversLocation + Constantns.IE_DRIVER);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			driver = new InternetExplorerDriver(capabilities);
			break;
		case "safari":
			// System.setProperty("webdriver.chrome.driver", driversLocation +
			// Constantns.CHROME_DRIVER);
			driver = new SafariDriver();
			break;
		case "android":
			capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 500);
			driver = androidLaunch(driver, capabilities, prop);
			break;
		case "androidApp":
			capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 600);
			driver = androidnativeAppLaunch(driver, capabilities, prop);
			break;	
		case "iosweb":
			driver = iosWeb(driver, capabilities, prop);
			break;
		case "iosnativeapp":
			driver = iosNativeApp(driver, capabilities, prop);
			break;
			
		default:
			throw new Error("Please select proper browser name "+browserName);
			
		}
		
		
		return driver;
	}

	private WebDriver androidLaunch(WebDriver driver, DesiredCapabilities capabilities, Properties prop) {
		capabilities.setCapability("--command-timeout", 10000);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		capabilities.setCapability("platformVersion", prop.getProperty("PLATFORM_VERSION"));
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.get("DEVICE_NAME"));
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, prop.getProperty("PLATFORM_VERSION"));
		capabilities.setCapability("automationName", "uiautomator2");
		capabilities.setCapability("noReset", "true");
		try {
			driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		return driver;
	}
	
	private WebDriver iosWeb(WebDriver driver, DesiredCapabilities capabilities, Properties prop) {
		
		capabilities.setCapability("platformName" ,"iOS"); 
	    capabilities.setCapability(CapabilityType.BROWSER_NAME, "Safari");
		capabilities.setCapability(MobileCapabilityType.UDID, prop.getProperty("UDID"));
		//capabilities.setCapability(MobileCapabilityType.UDID, "81a9af36847bcec289533772a3c89dfbd45cd572");
		//capabilities.setCapability(MobileCapabilityType.UDID, "cf421448e3bbc51e1ef65549e47d87e6296108f6");
		capabilities.setCapability("automationName", "XCUITest");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,prop.getProperty("IOS_device_name"));
		capabilities.setCapability("startIWDP", true);
		capabilities.setCapability("showXcodeLog", true);
		capabilities.setCapability("bundleId", "com.webmd.medscape");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
		capabilities.setCapability("xcodeOrgId", "Vishal NImmala(Personal Team)");
		capabilities.setCapability("safariIgnoreFraudWarning", true);
		capabilities.setCapability("safariAllowPopups", true);
		capabilities.setCapability("noReset", true);  // for iOS only

    	try {
		iosDriver =new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
			driver =iosDriver;
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return driver;
	}

	private WebDriver iosNativeApp(WebDriver driver, DesiredCapabilities capabilities, Properties prop) {
		
		
		capabilities.setCapability("platformName" ,"iOS"); 
		capabilities.setCapability(MobileCapabilityType.UDID, prop.getProperty("UDID"));
		//capabilities.setCapability(MobileCapabilityType.UDID, "81a9af36847bcec289533772a3c89dfbd45cd572");
		//capabilities.setCapability(MobileCapabilityType.UDID, "cf421448e3bbc51e1ef65549e47d87e6296108f6");
		capabilities.setCapability("automationName", "XCUITest");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,prop.getProperty("IOS_device_name"));
		capabilities.setCapability("startIWDP", true);
		capabilities.setCapability("showXcodeLog", true);
		capabilities.setCapability("bundleId", "com.webmd.medscape");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
		capabilities.setCapability("xcodeOrgId", "Vishal NImmala(Personal Team)");
		capabilities.setCapability("noReset", true);  // for iOS only
		
    	try {
		iosDriver =new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
			driver =iosDriver;
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return driver;
		
	}
	private WebDriver androidnativeAppLaunch(WebDriver driver, DesiredCapabilities capabilities, Properties prop) {
		//capabilities.setCapability("--command-timeout", 10000);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		
		capabilities.setCapability("platformVersion", prop.getProperty("PLATFORM_VERSION"));
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.get("DEVICE_NAME"));
		
		capabilities.setCapability("appPackage", prop.getProperty("appPackage"));

		capabilities.setCapability("appActivity",prop.getProperty("appActivity"));
		capabilities.setCapability("automationName", prop.getProperty("automationName"));
		//capabilities.setCapability("noReset", "true");
		try {
			 iosDriver = new AndroidDriver(new URL(prop.getProperty("AppiumHubUrl")), capabilities);
			driver=iosDriver;
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		return driver;
	}

	
	public void setUserAgent(DesiredCapabilities cap, String breakPoint) {
		switch (breakPoint) {
		case "1":
			ChromeOptions options = new ChromeOptions();
			String uAgent =new ReadProperties().prop.getProperty("userAgent");
			Logs.logAndConsole("User Agent Applied: "+uAgent);
			options.addArguments("--user-agent="+uAgent);
			cap.setCapability(ChromeOptions.CAPABILITY, options);
			break;
		case "2":
			
			break;
		case "3":
			
			break;
		case "4":
			
			break;
		default:
			
			break;
		}
	}
	
	public void setBrowserSize(WebDriver driver, String breakPoint) {
		switch (breakPoint) {
		case "1":
			driver.manage().window()
					.setSize(new Dimension(Constantns.BREAK_POINT_1_BROWSER_WIDTH, Constantns.BROWSER_HEIGHT));

			break;
		case "2":
			driver.manage().window()
					.setSize(new Dimension(Constantns.BREAK_POINT_2_BROWSER_WIDTH, Constantns.BROWSER_HEIGHT));

			break;
		case "3":
			driver.manage().window()
					.setSize(new Dimension(Constantns.BREAK_POINT_3_BROWSER_WIDTH, Constantns.BROWSER_HEIGHT));
			break;
		case "4":
			driver.manage().window()
					.setSize(new Dimension(Constantns.BREAK_POINT_4_BROWSER_WIDTH, Constantns.BROWSER_HEIGHT));
			break;
		default:
			driver.manage().window().maximize();
			break;
		}
	}

	public static int getBreakPoint(int breakPoint) {
		switch (breakPoint) {
		case 1:
			return Constantns.BREAK_POINT_1_BROWSER_WIDTH;
		case 2:
			return Constantns.BREAK_POINT_2_BROWSER_WIDTH;
		case 3:
			return Constantns.BREAK_POINT_3_BROWSER_WIDTH;
		case 4:
			return Constantns.BREAK_POINT_4_BROWSER_WIDTH;
		}
		return 4;

	}

	public static String getException(Exception e) {
		String traceException = "<br><br>" + e.getMessage() + "<br>";
		for (StackTraceElement i : e.getStackTrace()) {
			String ss = i.getClassName() + " " + i.getMethodName() + " " + i.getLineNumber();
			if (ss.contains("ActionMethods")) {
				ss = "<br><b style='color:red'>" + ss + "</b>";
			} else {
				ss = "<br>" + ss;
			}
			traceException = traceException + ss;
		}

		return traceException;
	}

	public static String getException(Throwable e) {
		String traceException = "<br><br>" + e.getMessage() + "<br>";
		for (StackTraceElement i : e.getStackTrace()) {
			String ss = i.getClassName() + " " + i.getMethodName() + " " + i.getLineNumber();
			if (ss.contains("ActionMethods")) {
				ss = "<br><b style='color:red'>" + ss + "</b>";
			} else {
				ss = "<br>" + ss;
			}
			traceException = traceException + ss;
		}

		return traceException;
	}
}

package com.webmd.automation.utilities;

import java.io.IOException;
import java.util.Date;
import java.util.List;

//import com.galenframework.reports.GalenTestInfo;
//import com.galenframework.reports.HtmlReportBuilder;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {
    static ExtentReports extent;
   
    public final static String reportLocation  = "Reports/Automation_Reports_" + (new Date()).toString().replace(":", "_").replace(" ", "_");
    final static String filePath  = reportLocation+"/SummaryReport.html";
    public synchronized static ExtentReports getReporter() {
        if (extent == null) {
            extent = new ExtentReports(filePath, true);
        }
        
        return extent;
    }
    
//    public synchronized static ExtentReports getGalenReporter(List<GalenTestInfo> tests ) {
//    	try {
//			new HtmlReportBuilder().build(tests, reportLocation+"/Galen_Reports");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        return extent;
//    }
    
    
}
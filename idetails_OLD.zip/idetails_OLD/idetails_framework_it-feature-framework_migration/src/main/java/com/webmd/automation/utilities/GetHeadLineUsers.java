package com.webmd.automation.utilities;

public class GetHeadLineUsers {

	static String[][] logheadLineUsers = null;

	static public synchronized String[][] info() {
		init();
		return logheadLineUsers;
	}

	

	private static void init() {
		if (logheadLineUsers == null) {
			try {

				logheadLineUsers = XlRead.fetchDataBasedOnColumnType("TestInputs/RuntimeUsers.xls", "Headline", "Is Tactic Available", "TRUE");
				
			} catch (Exception e) {
			}

		}
	}
	
	public static String[][] getHeadLineAvaialbeUser() {
		String user[][] = null;
		String data[][] = GetHeadLineUsers.info();
		for (int i = 0; i < data.length; i++) {
			
			if (data[i][3].equalsIgnoreCase("true")) {
				
				user = new String[1][2];
				user[0][0] = data[i][1];
				user[0][1] = data[i][2];
				GetHeadLineUsers.info()[i][3] = "false";
				return user;
			}
		}
		/*{
			//throw new Error("Tactic not avaialbe for users, please update users in excel and try again");
			return null;
		}*/
		return user;
		
	}
	
	private GetHeadLineUsers() {

	}
}

package com.webmd.automation.utilities;

import java.io.File;
import java.util.ArrayList;

//import com.webmd.general.common.ReadProperties;

import jxl.Sheet;
import jxl.Workbook;

public class XlRead {

	/**
	 * This Function returns the complete data from specified sheet by including
	 * columns record
	 * 
	 * @param fileLocation
	 * @param sheetname
	 * @return
	 */

	public static String[][] fetchData(String fileLocation, String sheetname) {

		Workbook wb = null;
		try {
			File f = new File(fileLocation);
			wb = Workbook.getWorkbook(f);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TO get the access to the sheet
		Sheet sh = wb.getSheet(sheetname);

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		String data[][] = new String[totalNoOfRows][totalNoOfCols];

		for (int j = 0; j < totalNoOfRows; j++) {

			for (int j2 = 0; j2 < totalNoOfCols; j2++) {
				data[j][j2] = sh.getCell(j2, j).getContents().trim();
			}

		}
		return data;
	}

	/**
	 * Function return data object excluding first row of the sheet
	 * 
	 * @param fileLocation
	 * @param sheetname
	 * @return
	 */
	public static String[][] fetchDataExcludingFirstRow(String fileLocation, String sheetname) {

		Workbook wb = null;
		try {
			File f = new File(fileLocation);
			// File f=new File(fileLocation);
			wb = Workbook.getWorkbook(f);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TO get the access to the sheet
		Sheet sh = wb.getSheet(sheetname);

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		// System.out.println("columns "+totalNoOfCols );
		Logs.logAndConsole("Total No of records avaialble in " + sheetname + " sheet is " + (totalNoOfRows - 1));
		String data[][] = new String[totalNoOfRows - 1][totalNoOfCols];

		for (int j = 1; j < totalNoOfRows; j++) {

			for (int j2 = 0; j2 < totalNoOfCols; j2++) {
				data[j - 1][j2] = sh.getCell(j2, j).getContents().trim();
			}

		}
		return data;
	}

	/**
	 * Function return data object excluding first row of the sheet
	 * 
	 * @param fileLocation
	 * @param sheetname
	 * @return
	 */
	public static String[][] fetchRunTimeUsersExcludingFirstRow(String fileLocation, String sheetname) {

		Workbook wb = null;
		try {
			File f = new File(fileLocation);
			// File f=new File(fileLocation);
			wb = Workbook.getWorkbook(f);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TO get the access to the sheet
		Sheet sh = wb.getSheet(sheetname);

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		System.out.println("columns " + totalNoOfCols);

		String data[][] = new String[totalNoOfRows - 1][totalNoOfCols + 1];

		for (int j = 1; j < totalNoOfRows; j++) {

			for (int j2 = 0; j2 < totalNoOfCols; j2++) {
				data[j - 1][j2] = sh.getCell(j2, j).getContents().trim();
			}

		}
		return data;
	}

	/**
	 * Function return data object excluding first row of the sheet
	 * 
	 * @param fileLocation
	 * @param sheetname
	 * @return
	 */
	public static String[][] fetchDataBasedOnColumnType(String fileLocation, String sheetname, String columName,
			String columnData) {

		Workbook wb = null;
		try {
			File f = new File(fileLocation);
			wb = Workbook.getWorkbook(f);
		} catch (Exception e) {

			e.printStackTrace();
		}

		// TO get the access to the sheet
		Sheet sh = wb.getSheet(sheetname);

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		// Finding column index of required column
		int requuiredColumnIndex = 0;

		for (int i = 0; i < totalNoOfCols; i++) {
			requuiredColumnIndex = i;
			boolean b = sh.getCell(i, 0).getContents().trim().equalsIgnoreCase(columName);
			if (b) {
				break;
			}
		}
		// Find no of row with given content type
		ArrayList<Integer> rowNo = new ArrayList<>();
		for (int i = 0; i < totalNoOfRows; i++) {

			boolean b = sh.getCell(requuiredColumnIndex, i).getContents().trim().equalsIgnoreCase(columnData.trim());
			if (b) {
				rowNo.add(i);
			}
		}

		String data[][] = new String[rowNo.size()][totalNoOfCols];

		for (int j = 0; j < rowNo.size(); j++) {

			for (int j2 = 0; j2 < totalNoOfCols; j2++) {
				data[j][j2] = sh.getCell(j2, rowNo.get(j)).getContents().trim();
			}

		}
		return data;
	}

	public static String[][] fetchDataBasedOnColumnTypeWithRowRange(String fileLocation, String sheetname,
			 String rowRange) {

		Workbook wb = null;
		try {
			File f = new File(fileLocation);
			wb = Workbook.getWorkbook(f);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// TO get the access to the sheet
		Sheet sh = wb.getSheet(sheetname);

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

	
		//Get no of rows
		String dataRows[] = rowRange.split(",");

		ArrayList<Integer> rangeRequired = new ArrayList<>();
		for (int i = 0; i < dataRows.length; i++) {

			String range[] = dataRows[i].split("-");

			if (range.length == 1) {
				int value = Integer.parseInt(range[0])-1;
				rangeRequired.add(value);
			} else {
				int uBound = Integer.parseInt(range[1])-1;
				int lBound = Integer.parseInt(range[0])-1;
				
				for (int j = lBound; j <= uBound; j++) {
					rangeRequired.add(j);
				}
			}

		}


		String data[][] = new String[rangeRequired.size()][totalNoOfCols];

		for (int j = 0; j < rangeRequired.size(); j++) {

			for (int j2 = 0; j2 < totalNoOfCols; j2++) {
				data[j][j2] = sh.getCell(j2, rangeRequired.get(j)).getContents().trim();
				//System.out.println(data[j][j2]);
			}

		}
		return data;
	}

	// sample usage code
	public static void main(String[] args) {
		fetchDataBasedOnColumnTypeWithRowRange("TestInputs/RuntimeUsers.xls", "Headline" ,
				"3-5,6-10,14");
	}
}
package com.webmd.automation.utilities;

public class GetHeadLineUsersWithRowRange {

	public String[][] logheadLineUsers = null;

	String range;
	public  String[][] info() {
		init();
		return logheadLineUsers;
	}

	public GetHeadLineUsersWithRowRange(String range){
		this.range =range;
	}
	

	private  void init() {
		if (logheadLineUsers == null) {
			try {
				logheadLineUsers = XlRead.fetchDataBasedOnColumnTypeWithRowRange("TestInputs/RuntimeUsers.xls","Headline", range);
				
			} catch (Exception e) {
			}

		}
	}
	
	public  String[][] getHeadLineAvaialbeUser() {
		String user[][] = null;
		String data[][] = info();
		for (int i = 0; i < data.length; i++) {
			
			if (data[i][3].equalsIgnoreCase("true")) {
				
				user = new String[1][2];
				user[0][0] = data[i][1];
				user[0][1] = data[i][2];
				info()[i][3] = "false";
				return user;
			}
		}
		/*{
			throw new Error("Tactic not avaialbe for users, please update users in excel and try again");
		}*/
		return user;
		
	}
	
	
}

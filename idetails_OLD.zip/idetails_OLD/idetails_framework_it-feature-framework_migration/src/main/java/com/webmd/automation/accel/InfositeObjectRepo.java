package com.webmd.automation.accel;

import org.openqa.selenium.By;

public class InfositeObjectRepo {
	public static By allNavLinks = By.xpath("(//*[@id='navigation-module'])[1]//a");
	public static By HomepageLinks=By.xpath("//section[@class!='nav-buttons-container']//div[contains(@class,'main-link')]//a[@data-module='RouterLink']");
	public static By registartionform=By.xpath("//div[@class='reg-nav']/a");
	public static By homepageAndNav=By.xpath("//*[@class='article-content']//a[@data-module='RouterLink']");
	public static By Iconsent=By.className("accept-button");
	public static By accept=By.className("accept");
	public static By extLinks=By.xpath("//*[contains(@target,'_blank') and contains(@target,'_blank')]");
	public static By additionalextLinks=By.xpath("//*[@class='container content']//span[@class='nowrap']//a");
	public static By videoScreen=By.xpath("//div[contains(@id,'video_player_screen')]");
	public static By pollquestions=By.xpath("//*[@class='question-item']");
	public static By pollsubmit=By.xpath("//*[@class='submit-button button']//span");
	public static By allNavLinks_1 = By.xpath("(//*[@class='navigation-menu'])[1]//a");
	public static By Next_Link_withinArticle = By.xpath("(//*[@id='more_links']//a | //*[contains(text(),'NEXT')]//following-sibling::a |//p//a[contains(text(),'Next')] |(//p//span[contains(text(),'UP NEXT:')]/../a)[1] | //p[contains(text(),'NEXT: ')]//a | //p//a[contains(text(),'HOME')]  | //p//a[contains(text(),'Home')])[1]");
	public static By Next_Link_withinArticle1 = By.xpath("(//*[@id='more_links']//a | //p//a[contains(text(),'Next')] |(//p//span[contains(text(),'UP NEXT:')]/../a)[1] | //p[contains(text(),'NEXT: ')]//a)[1]");
	public static By backbtn=By.xpath("//*[@id='next-link']/span[(text()='Back')]");
}

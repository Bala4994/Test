package com.webmd.automation.accel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.Reporter;

import com.galenframework.api.Galen;
import com.galenframework.reports.model.LayoutReport;
import com.galenframework.validation.ValidationResult;
import com.relevantcodes.extentreports.LogStatus;
import com.thoughtworks.selenium.webdriven.commands.IsElementPresent;
import com.webmd.automation.utilities.Constantns;
import com.webmd.automation.utilities.ExtentManager;
import com.webmd.automation.utilities.ExtentTestManager;
import com.webmd.automation.utilities.GalenTestManager;
import com.webmd.automation.utilities.GetHeadLineUsers;
import com.webmd.automation.utilities.GetHeadLineUsersWithRowRange;
import com.webmd.automation.utilities.Logs;
import com.webmd.automation.utilities.PrivateMethods;
import com.webmd.automation.utilities.XlRead;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDeviceActionShortcuts;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.core.har.HarNameValuePair;
import test.webmd.callsTracking.Videos_Tracking;

public class ActionMethods {
	public WebDriver driver;
	public Properties prop;
	public String browserName;
	public String env;
	public String breakPoint;
	public String browserMob;
	private String LEFTBOLDTAG = "<b style=\"color:  green;\"/>";
	private String RIGHTBOLDTAG = "</b>";
	public ITestContext ctx;
	public String grid;
	public BrowserMobProxyServer proxy;
	public String browserMobPort;
	public AppiumDriver appiumDriver;

	public ActionMethods(ITestContext ctx) {
		this.ctx = ctx;
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("config.properties")));
			setProjectExecutionVariables(this.ctx);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void IOSWeblogin(String userName, String pwd) {

		try {
			// ((AppiumDriver)driver).manage().deleteAllCookies();
			driver.get("https://login.medscape.com/login/sso/getlogin?ac=401");

			Reporter.log("Login started with valid inputs");
			enter(By.id("regularEmail"), userName, "username");
			enter(By.id("password"), pwd, "password");

			driver.findElement(By.id("loginBtn")).click();
			Thread.sleep(15000);
			// boolean b= click(By.id("loginBtn"), "Login");

			// Assert.assertTrue(b," Login failed with username "+userName+"
			// ,pwd: "+pwd);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void IOSapplogin(String userName, String pwd) {
		try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			/*
			 * wait.until(ExpectedConditions.visibilityOfElementLocated(By
			 * .xpath("//*[@class='UIAStaticText' and ./parent::*[@accessibilityLabel='WELCOME_CURRENT_USER']]"
			 * )));
			 */
			click(By.xpath("//*[@class='UIAStaticText' and ./parent::*[@accessibilityLabel='WELCOME_CURRENT_USER']]"),
					"navigating to login");

			driver.findElement(By.xpath("//*[@placeholder='Email or Username']")).sendKeys(userName);
			driver.findElement(By.xpath("//*[@placeholder='Password']")).sendKeys(pwd);
			boolean b = click(By.xpath("//*[@accessibilityLabel='LOGIN_BUTTON']"), "Login button clicked");
			Assert.assertEquals(b, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}

	public void androidNativeAppLogin(String user, String pwd) {
		getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		click(By.xpath("//android.widget.TextView[contains(@resource-id,'btnSignIn') and @text='I have an account']"),
				"navigating to login");

		enter(By.xpath("//android.widget.EditText[contains(@resource-id,'edit_text_user_name')]"), user, "User Name");
		enter(By.xpath("//android.widget.EditText[contains(@resource-id,'edit_text_password')]"), pwd, "Password");
		boolean b = click(By.xpath("//android.widget.Button[contains(@resource-id,'button_login') and @text='Log In']"),
				"Login button clicked");
		Assert.assertEquals(b, true);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public AppiumDriver getAppiumDriver() {
		return appiumDriver;
	}

	public BrowserMobProxyServer getproxyServer() {
		return proxy;
	}

	public void startNewHar() {
		proxy.newHar();
	}

	public void get(String url) {
		String exception = "";
		try {
			getDriver().get(url);
			staticWait(3);
			generatePassReportWithScreenShot("URl Opened :" + getBoldText(url));

		} catch (Exception e) {
			exception = PrivateMethods.getException(e);
			generateFailReport("URl not Opened :" + getBoldText(url) + exception);
		}

	}

	public void popupHandle() {
		String exception = "";
		try {
			if (driver.findElements(By.className("close-video-violator")).size() > 0) {

				driver.findElement(By.className("close-video-violator")).click();
				System.out.println("Bottom Ad handled");
			}

		} catch (Exception e) {
			exception = PrivateMethods.getException(e);
			generateFailReport("Unable to Handle Popup" + exception);
		}
	}

	public void pageRefresh() {
		String exceptionMsg = "";
		try {
			getDriver().navigate().refresh();
			staticWait(3);

			// generatePassReportWithScreenShot("Page Refreshed");
		} catch (Exception e) {
			exceptionMsg = PrivateMethods.getException(e);
			generateFailReport("URl not Opened :" + exceptionMsg);
		}
	}

	public boolean click(By locator, String locatorName) {
		boolean flag = false;
		String exception = "";
		try {
			scrollToObject(driver.findElement(locator));
			driver.findElement(locator).click();
			Thread.sleep(1000);
			flag = true;
		} catch (Exception e) {
			if (browserName.equals("android")) {
				try {
					try {
						((AndroidDeviceActionShortcuts) driver).pressKeyCode(66);
						flag = true;
					} catch (Exception e1) {
						flag = false;
					}

				} catch (Exception e1) {

				}
			}
			exception = PrivateMethods.getException(e);
		} finally {
			generateReport(flag, "Click performed on " + getBoldText(locatorName),
					"Click not performed on " + getBoldText(locatorName) + " " + exception);
		}
		return flag;
	}

	public boolean clickByWebElement(WebElement element, String locatorName) {
		boolean flag = false;
		String exception = "";
		try {

			element.click();
			Thread.sleep(1000);
			flag = true;
		} catch (Exception e) {
			exception = PrivateMethods.getException(e);
			e.printStackTrace();
		} finally {
			generateReport(flag, "Click performed on " + getBoldText(locatorName),
					"Click not performed on " + getBoldText(locatorName) + " " + exception);
		}
		return flag;
	}

	public void enter(By by, String data, String locator) {
		boolean flag = false;
		String exception = "";
		try {
			driver.findElement(by).clear();
			driver.findElement(by).sendKeys(data);
			flag = true;
		} catch (Exception e) {
			exception = PrivateMethods.getException(e);
			e.printStackTrace();
		} finally {
			generateReport(flag, getBoldText(data) + " entered into " + getBoldText(locator),
					getBoldText(data) + " not  entered into " + getBoldText(locator) + " " + exception);
		}

	}

	public void enterSecurePassword(By by, String encodedPwd, String locator) {
		boolean flag = false;
		String exception = "";
		byte[] encode = Base64.encodeBase64(encodedPwd.getBytes());
		byte[] decoded = Base64.decodeBase64(encode);
		try {

			driver.findElement(by).clear();
			driver.findElement(by).sendKeys(new String(encodedPwd));
			flag = true;

		} catch (Exception e) {
			exception = PrivateMethods.getException(e);
			e.printStackTrace();
		} finally {
			generateReport(flag, getBoldText(new String(encode)) + " entered into " + getBoldText(locator),
					getBoldText(new String(encode)) + " not  entered into " + getBoldText(locator) + " " + exception);
		}

	}

	public void loginCP() {
		get("http://tools.medscape.com/cpadmin/event");
		enter(By.name("j_username"), prop.getProperty("tacticUserName"), "User name");
		enterSecurePassword(By.name("j_password"), prop.getProperty("tacticUserPwd"), "Password");
		// enter(By.name("j_password"),prop.getProperty("tacticUserPwd"), "Password");
		click(By.xpath("//*[@id='submitbutton']/input[1]"), "Login");

	}

	public String getBoldText(String data) {
		return LEFTBOLDTAG + data + RIGHTBOLDTAG;
	}

	public void isElementVisible(By by, String locator) {
		boolean flag = false;
		String exception = "";
		try {
			driver.findElement(by).isDisplayed();
			flag = true;
		} catch (Exception e) {
			exception = PrivateMethods.getException(e);
		} finally {
			generateReport(flag, getBoldText(locator) + " is visible on page",
					getBoldText(locator) + " is not visible on page " + exception);
		}

	}

	/**
	 * Browser Will be launched based configuration in suite.xml or
	 * config.properties file
	 * 
	 * @return
	 * 
	 * @throws Throwable
	 */
	public WebDriver launchBrowser() {

		setProjectExecutionVariables(ctx);
		generateInfoReport("Browser Name: " + browserName + "<br>Environment: " + env + "<br>Break Point: " + breakPoint
				+ "<br>Browsermob Proxy: " + browserMob + "<br>Browsermob Proxy Port: " + browserMobPort
				+ "<br>TakeScreenShotOnPass: " + prop.getProperty("takeScreenShotOnPass"));
		PrivateMethods pm = new PrivateMethods();
		driver = pm.openBrowser(prop, driver, browserName, breakPoint, browserMobPort);
		generateInfoReport(browserName + " launched");
		proxy = pm.getproxy();
		appiumDriver = pm.iosDriver;
		return driver;
	}

	/**
	 * Browser Will be launched
	 * 
	 * @param browserName:
	 *            ie, ff, chrome
	 */
	public void launchBrowser(String browserName) {
		setProjectExecutionVariables(ctx);
		this.browserName = browserName;
		PrivateMethods pm = new PrivateMethods();
		driver = pm.openBrowser(prop, driver, browserName, breakPoint, browserMobPort);
		proxy = pm.getproxy();
	}

	public void generateReport(boolean status, String passText, String failText) {
		if (status) {

			generatePassReport(passText);
		} else {

			generateFailReport(failText);
		}
	}

	public void generatePassReport(String passText) {
		ExtentTestManager.getTest().log(LogStatus.PASS, passText);
		Logs.logAndConsole(passText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
		if (prop.getProperty(Constantns.TAKE_SCREENSHOT_ON_PASS).equalsIgnoreCase("true")) {
			try {
				ExtentTestManager.getTest().log(LogStatus.INFO,
						ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
			} catch (Exception e) {

			}
		}
	}

	public void generateInfoReport(String infoText) {
		ExtentTestManager.getTest().log(LogStatus.INFO, infoText);
		Logs.logAndConsole(infoText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

	}

	public void generateBoldInfo(String infoText) {
		ExtentTestManager.getTest().log(LogStatus.INFO, getBoldText(infoText));
		Logs.logAndConsole(
				getBoldText(infoText).replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

	}

	public void generatePassReportWithNoScreenShot(String passText) {
		ExtentTestManager.getTest().log(LogStatus.PASS, passText);
		Logs.logAndConsole(passText.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
	}

	public void generateFailReport(String text) {
		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));

		ExtentTestManager.getTest().log(LogStatus.FAIL, text);
		try {
			ExtentTestManager.getTest().log(LogStatus.FAIL,
					ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
		} catch (Exception e) {

		}
	}

	public void generatePassReportWithScreenShot(String text) {

		Logs.logAndConsole(text.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n\n"));
		ExtentTestManager.getTest().log(LogStatus.PASS, text);
		ExtentTestManager.getTest().log(LogStatus.PASS, ExtentTestManager.getTest().addScreenCapture(getScreenshot()));
	}

	private String getScreenshot() {
		String destination = null;
		try {
			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			destination = "Screenshots/" + String.valueOf(System.nanoTime()) + dateName + ".png";
			File finalDestination = new File(ExtentManager.reportLocation + "/" + destination);
			FileUtils.copyFile(source, finalDestination);

		} catch (Exception e) {
		}
		return destination;
	}

	public void galenScript(String specPath, String title) {

		try {
			LayoutReport layoutReport;
			List<String> s = new ArrayList<String>();
			s.add(String.valueOf(PrivateMethods.getBreakPoint(Integer.parseInt(breakPoint)) + "x"
					+ Constantns.GALEN_BROWSER_HEIGHT));
			layoutReport = Galen.checkLayout(driver, specPath, s);
			List<ValidationResult> list = layoutReport.getValidationErrorResults();

			String errors = "";

			for (ValidationResult validationResult : list) {
				// System.out.println(validationResult);
				List<String> v = validationResult.getError().getMessages();
				for (int i = 0; i < v.size(); i++) {
					System.out.println(v.get(i));
					errors = errors.concat(v.get(i) + ",</br>");
				}
			}

			// reports.getReport().layout(layoutReport, title);
			GalenTestManager.addLayout(layoutReport, title);
			System.out.println(errors);

		} catch (Exception e) {
			GalenTestManager.addInfo(e.getMessage()).setException(e);
			;
		}
		// testInfo.getReport().layout(layoutReport, title);

	}

	/**
	 * Assign values to the global variables from testng.xml suite file
	 * 
	 * @param ctx
	 */
	private void setProjectExecutionVariables(ITestContext ctx) {

		browserName = PrivateMethods.getParamValue(ctx, Constantns.BROWSER_NAME);
		env = PrivateMethods.getParamValue(ctx, Constantns.ENV);
		breakPoint = PrivateMethods.getParamValue(ctx, Constantns.BREAK_POINT);
		browserMob = PrivateMethods.getParamValue(ctx, Constantns.BROWSER_MOB_PROXY);
		grid = PrivateMethods.getParamValue(ctx, Constantns.SELENIUM_GRID);
		browserMobPort = PrivateMethods.getParamValue(ctx, Constantns.BROWSERMOB_PROXY_PORT);

	}

	public Hashtable<String, String> getStdParmValues(BrowserMobProxyServer server, String domaine, String attribute,
			String valuesContainsWithComma) {
		Logs.logAndConsole(
				"Verifying :" + domaine + " call with param " + attribute + " and values " + valuesContainsWithComma);
		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;
		int noOFTimes = 0;
		int noOfSSlCalls = 0;
		String compValues[] = valuesContainsWithComma.split(",");
		while (!valueTracked) {
			String trackedCalls = "";
			try {

				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(domaine)) {
						noOfSSlCalls++;
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();
						// Logs.logAndConsole(requestUrl);
						trackedCalls = trackedCalls + "<br>" + requestUrl;
						// Logs.logAndConsole(harNameValuePairs.toString());
						stdValues = new Hashtable<>();
						for (HarNameValuePair harNameValuePair : harNameValuePairs) {
							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
						}

						try {
							String sfid = "";
							try {
								sfid = compValues[1];
							} catch (Exception e) {

							}

							if (stdValues.get(attribute).toString().endsWith(compValues[0])
									&& stdValues.get(attribute).toString().contains(sfid)) {
								valueTracked = true;
								break;
							} else {
								stdValues = new Hashtable<>();

							}
						} catch (Exception e) {
							stdValues = new Hashtable<>();

						}
					}

				}

				Logs.log("NO Of SSL calls: " + noOfSSlCalls);
				noOfSSlCalls = 0;
				if (noOFTimes == 2) {
					generateInfoReport("Tracked " + getBoldText(domaine) + " Calls<br>" + trackedCalls);
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
			} catch (Exception e) {
				System.out.println(e);
				noOFTimes++;
				if (noOFTimes == 2) {
					generateInfoReport("Tracked " + getBoldText(domaine) + " Calls<br>" + trackedCalls);
					break;
				}

			}
		}
		return stdValues;
	}

	public Hashtable<String, String> getStdParmValues(BrowserMobProxyServer server, String domaine) {

		// ArrayList<Hashtable<String, String>> arrayList = new
		// ArrayList<Hashtable<String, String>>();
		Hashtable<String, String> stdValues = new Hashtable<>();

		boolean valueTracked = false;
		int noOFTimes = 0;
		while (!valueTracked) {

			try {
				if (noOFTimes == 3) {
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(domaine)) {
						// Logs.logAndConsole(requestUrl);
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

						// System.out.println(entries.get(i).getRequest().getQueryString());
						// generateInfoReport(requestUrl);
						stdValues = new Hashtable<>();
						for (HarNameValuePair harNameValuePair : harNameValuePairs) {
							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
						}
						return stdValues;
					}

				}
			} catch (Exception e) {
				Logs.log(e.getMessage());
			}
		}
		return stdValues;
	}

	public ArrayList<Hashtable<String, String>> getAllStdParmValues(BrowserMobProxyServer server, String domaine) {

		ArrayList<Hashtable<String, String>> arrayList = new ArrayList<>();
		Hashtable<String, String> stdValues = new Hashtable<>();

		boolean valueTracked = false;
		int noOFTimes = 0;
		while (!valueTracked) {
			arrayList = new ArrayList<Hashtable<String, String>>();
			try {
				if (noOFTimes == 3) {
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(domaine)) {
						// Logs.logAndConsole(requestUrl);

						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

						// System.out.println(entries.get(i).getRequest().getQueryString());
						stdValues = new Hashtable<>();
						for (HarNameValuePair harNameValuePair : harNameValuePairs) {
							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
						}
						arrayList.add(stdValues);
					}

				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return arrayList;
	}

	public Hashtable<String, String> validateExtLinks(String text) {

		Hashtable<String, String> KeyValues = new Hashtable<>();

		String links[] = text.split(",");

		for (String string : links) {
			String labels[] = string.split("&&");

			KeyValues.put(labels[0], labels[1]);
		}

		return KeyValues;
	}

	public void VerifypageNotFound(String linktxt) {
		String getURL = driver.getCurrentUrl();
		if (getURL.contains(".pdf") || getURL.contains(".PDF")) {
			// generatePassReportWithScreenShot("Below is the Redirection PDF Page
			// screenshot"+"URL:"+getURL);
			generatePassReport("Redirection Page PDF URL:" + getURL);
		} else if (driver.getTitle().contains("Page Not Found") || driver.getTitle().contains("404 - Page Not Found")
				|| driver.getTitle().contains("404")) {
			Boolean PageNotFound = true;
			// generateReport(PageNotFound,"Link Navigating to Page Not Found","Link Working
			// Fine");
			generateFailReport("Redirection is navigating to page Not Found" + "URL:   " + getURL);
		} else if (((linktxt.contains("Return to Medscape")) && getURL.contains("www.medscape.com"))
				|| ((linktxt.contains("Privacy Policy")) && getURL.contains("www.medscape.com"))) {
			// generatePassReportWithScreenShot("Redirection is navigating to Medscape
			// page<===============>"+"URL:"+getURL);
			generatePassReport("This is Interal Link-Redirection Page URL:   " + getURL);
		} else if (getURL.contains("www.medscape.com")) {
			generateFailReport("Redirection is navigating to Medscape Home page<===============>" + "URL:   " + getURL);
		}

		else {
			// generatePassReportWithScreenShot("Below is the Redirection Page
			// screenshot<===============>"+"URL:"+getURL);
			generatePassReport("Redirection Page URL:" + getURL);
		}

	}

	/*
	 * public void testOnsiteLinks(WebDriver driver, BrowserMobProxyServer server,
	 * String SFID, String env) throws InterruptedException {
	 * 
	 * generatePassReport("====== Clicking on All Links ========="); // layer links
	 * xpath List<WebElement> allLinks =
	 * driver.findElements(By.xpath("//div[@id='nDlayer_plate']//a"));
	 * 
	 * // Direct onsite links xpath if (allLinks.size() == 0) { allLinks =
	 * driver.findElements(By.xpath("//div[@id='contentblock']//a")); }
	 * 
	 * generatePassReport("No of links available in Page: " + allLinks.size());
	 * 
	 * String links = ""; links = getAllLinksAndTitles(allLinks, links);
	 * 
	 * generatePassReport("All Links and urls<br>" + links);
	 * 
	 * String winHandleBefore = driver.getWindowHandle(); try {
	 * driver.findElement(By.className("close-video-violator")).click(); } catch
	 * (Exception e) {
	 * 
	 * } for (int i = 0; i < allLinks.size(); i++) {
	 * 
	 * if (allLinks.get(i).isDisplayed() &&
	 * allLinks.get(i).getAttribute("target").contains("_blank")) { server.newHar();
	 * try {
	 * 
	 * generatePassReport(
	 * "*********************************************************");
	 * 
	 * clickByWebElement(allLinks.get(i), getTextForReport(allLinks, i) + " : " +
	 * allLinks.get(i).getAttribute("href"));
	 * 
	 * // validate tracker marker call
	 * 
	 * Hashtable<String, String> trackermarker = getStdParmValues(server,
	 * "www.medscape.com/px/trk.svr/promo-");
	 * 
	 * generateReport(trackermarker.size() > 0, getBoldText("trackermarker call") +
	 * " : www.medscape.com/px/trk.svr/promo- tracked <br>" +
	 * getBoldText(trackermarker.toString()), getBoldText("trackermarker call") +
	 * ": www.medscape.com/px/trk.svr/promo- not tracked <br>" +
	 * getBoldText(trackermarker.toString()));
	 * 
	 * Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
	 * "ssl.o.webmd.com/b/ss/webmd");
	 * 
	 * filePathsWebVadidation(hashtable);
	 * 
	 * Set<String> windows = driver.getWindowHandles(); Iterator<String> iterator =
	 * windows.iterator(); String lastWindow = "";
	 * 
	 * while (iterator.hasNext()) { lastWindow = iterator.next(); }
	 * driver.switchTo().window(lastWindow); VerifypageNotFound();
	 * 
	 * 
	 * Thread.sleep(1000);
	 * 
	 * generatePassReport("No of windows : " + driver.getWindowHandles().size());
	 * 
	 * if (driver.getWindowHandles().size() > 1) { if
	 * (!winHandleBefore.equalsIgnoreCase(lastWindow)) { driver.close(); }
	 * driver.switchTo().window(winHandleBefore); } else { Thread.sleep(1000);
	 * allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a")); }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); Logs.log(e.getMessage()); } }
	 * 
	 * } }
	 */
	public void testLayerLinks(WebDriver driver, BrowserMobProxyServer server, String SFID, String env)
			throws InterruptedException {

		/*
		 * if(driver.findElement(By.id("collapse-close-button"))!= null){
		 * driver.findElement(By.id("collapse-close-button")).click(); }
		 */

		generatePassReport("====== Clicking on All Links =========");
		// layer links xpath
		List<WebElement> allLinks = driver.findElements(By.xpath("//div[@id='nDlayer_plate']//a"));

		// Direct onsite links xpath
		if (allLinks.size() == 0) {
			allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));
		}

		generatePassReport("No of links available in Page: " + allLinks.size());

		String links = "";
		links = getAllLinksAndTitles(allLinks, links);

		generatePassReport("All Links and urls<br>" + links);

		String winHandleBefore = driver.getWindowHandle();
		try {
			driver.findElement(By.className("close-video-violator")).click();
		} catch (Exception e) {

		}
		for (int i = 0; i < allLinks.size(); i++) {
			try {

				if (allLinks.get(i).isDisplayed() && allLinks.get(i).getAttribute("target").contains("_blank")
						&& !allLinks.get(i).getAttribute("href").contains("tel:")
						&& !allLinks.get(i).getAttribute("href").contains("mailto:")) {
					server.newHar();

					generatePassReport(
							"*****************************************************************************************************************************************************");
					if (getDriver().findElements(By.xpath("//div[@id='nDlayer_plate' and @style='opacity: 0;']"))
							.size() > 0) {

						getDriver().navigate().refresh();
						allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));

						clickByWebElement(allLinks.get(i),
								getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));

					} else {
						clickByWebElement(allLinks.get(i),
								getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));
					}
					// clickByWebElement(allLinks.get(i),
					// getTextForReport(allLinks, i) + " : " +
					// allLinks.get(i).getAttribute("href"));
					// validate tracker marker call

					Hashtable<String, String> trackermarker = getStdParmValues(server,
							"www.medscape.com/px/trk.svr/promo-");

					generateReport(trackermarker.size() > 0,
							getBoldText("Tracker Marker Call") + " : www.medscape.com/px/trk.svr/promo- tracked <br>"
									+ getBoldText(trackermarker.toString()),
							getBoldText("Tracker Marker Call") + ": www.medscape.com/px/trk.svr/promo- not tracked <br>"
									+ getBoldText(trackermarker.toString()));

					Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
							"ssl.o.webmd.com/b/ss/webmd");

					filePathsWebVadidationSF(hashtable, SFID);

					Set<String> windows = driver.getWindowHandles();
					Iterator<String> iterator = windows.iterator();
					String lastWindow = "";

					while (iterator.hasNext()) {
						lastWindow = iterator.next();
					}
					String lnktxt = allLinks.get(i).getText();
					driver.switchTo().window(lastWindow);
					VerifypageNotFound(lnktxt);

					Thread.sleep(1000);

					// generatePassReport("No of windows : " + driver.getWindowHandles().size());

					if (driver.getWindowHandles().size() > 1) {
						if (!winHandleBefore.equalsIgnoreCase(lastWindow)) {
							driver.close();
						}
						driver.switchTo().window(winHandleBefore);
					} else {
						Thread.sleep(1000);
						allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));
					}

				} else if (allLinks.get(i).getAttribute("href") != null) {
					if (allLinks.get(i).getAttribute("href").contains("tel:")) {
						generatePassReport(
								"*****************************************************************************************************************************************************");
						generateBoldInfo("Phone number Link:  " + allLinks.get(i).getText());
					} else if (allLinks.get(i).getAttribute("href").contains("mailto:")) {
						generatePassReport(
								"*****************************************************************************************************************************************************");
						generateBoldInfo("Email Link:  " + allLinks.get(i).getText());
					}

					else if (allLinks.get(i).getAttribute("href").contains("#isi")) {
						generatePassReport(
								"*****************************************************************************************************************************************************");
						generateBoldInfo(allLinks.get(i).getText() + " :  Anchors with in the same Page");
						// generatePassReportWithScreenShot("Snippet of Anchoring part");

					}
				} else if (allLinks.get(i).getAttribute("target").contains("_self")) {
					generatePassReport(
							"*****************************************************************************************************************************************************");
					generateFailReport(allLinks.get(i).getText() + " :   Link is Opening in the same Page");
					generateInfoReport(allLinks.get(i).getAttribute("href"));
				}

			} catch (Exception e) {
				e.printStackTrace();
				Logs.log(e.getMessage());
			}

		}

	}

	public void sgvtestLayerLinks(WebDriver driver, BrowserMobProxyServer server, String SFID, String env)
			throws InterruptedException {

		/*
		 * if(driver.findElement(By.id("collapse-close-button"))!= null){
		 * driver.findElement(By.id("collapse-close-button")).click(); }
		 */

		generatePassReport("====== Clicking on All Links =========");
		// layer links xpath
		List<WebElement> allLinks = driver.findElements(By.xpath("//div[@id='nDlayer_plate']//a"));

		// Direct onsite links xpath
		if (allLinks.size() == 0) {
			allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));
		}

		generatePassReport("No of links available in Page: " + allLinks.size());

		String links = "";
		links = getAllLinksAndTitles(allLinks, links);

		generatePassReport("All Links and urls<br>" + links);

		String winHandleBefore = driver.getWindowHandle();
		try {
			driver.findElement(By.className("close-video-violator")).click();
		} catch (Exception e) {

		}
		for (int i = 0; i < allLinks.size(); i++) {
			try {

				if (allLinks.get(i).isDisplayed() && allLinks.get(i).getAttribute("target").contains("_blank")
						&& !allLinks.get(i).getAttribute("href").contains("tel:")
						&& !allLinks.get(i).getAttribute("href").contains("mailto:")) {
					server.newHar();

					generatePassReport(
							"*****************************************************************************************************************************************************");
					if (getDriver().findElements(By.xpath("//div[@id='nDlayer_plate' and @style='opacity: 0;']"))
							.size() > 0) {

						getDriver().navigate().refresh();
						validateSGVCallDisplayedforRefresh(SFID);
						allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));

						clickByWebElement(allLinks.get(i),
								getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));

					} else {
						clickByWebElement(allLinks.get(i),
								getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));
					}
					// clickByWebElement(allLinks.get(i),
					// getTextForReport(allLinks, i) + " : " +
					// allLinks.get(i).getAttribute("href"));
					// validate tracker marker call

					Hashtable<String, String> trackermarker = getStdParmValues(server,
							"www.medscape.com/px/trk.svr/promo-");

					generateReport(trackermarker.size() > 0,
							getBoldText("Tracker Marker Call") + " : www.medscape.com/px/trk.svr/promo- tracked <br>"
									+ getBoldText(trackermarker.toString()),
							getBoldText("Tracker Marker Call") + ": www.medscape.com/px/trk.svr/promo- not tracked <br>"
									+ getBoldText(trackermarker.toString()));

					Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
							"ssl.o.webmd.com/b/ss/webmd");

					filePathsWebVadidationSF(hashtable, SFID);

					Set<String> windows = driver.getWindowHandles();
					Iterator<String> iterator = windows.iterator();
					String lastWindow = "";

					while (iterator.hasNext()) {
						lastWindow = iterator.next();
					}
					String lnktxt = allLinks.get(i).getText();
					driver.switchTo().window(lastWindow);
					VerifypageNotFound(lnktxt);

					Thread.sleep(1000);

					// generatePassReport("No of windows : " + driver.getWindowHandles().size());

					if (driver.getWindowHandles().size() > 1) {
						if (!winHandleBefore.equalsIgnoreCase(lastWindow)) {
							driver.close();
						}
						driver.switchTo().window(winHandleBefore);
					} else {
						Thread.sleep(1000);
						allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));
					}

				} else if (allLinks.get(i).getAttribute("href") != null) {
					if (allLinks.get(i).getAttribute("href").contains("tel:")) {
						generatePassReport(
								"*****************************************************************************************************************************************************");
						generateBoldInfo("Phone number Link:  " + allLinks.get(i).getText());
					} else if (allLinks.get(i).getAttribute("href").contains("mailto:")) {
						generatePassReport(
								"*****************************************************************************************************************************************************");
						generateBoldInfo("Email Link:  " + allLinks.get(i).getText());
					}

					else if (allLinks.get(i).getAttribute("href").contains("#isi")) {
						generatePassReport(
								"*****************************************************************************************************************************************************");
						generateBoldInfo(allLinks.get(i).getText() + " :  Anchors with in the same Page");
						// generatePassReportWithScreenShot("Snippet of Anchoring part");

					}
				} else if (allLinks.get(i).getAttribute("target").contains("_self")) {
					generatePassReport(
							"*****************************************************************************************************************************************************");
					generateFailReport(allLinks.get(i).getText() + " :   Link is Opening in the same Page");
					generateInfoReport(allLinks.get(i).getAttribute("href"));
				}

			} catch (Exception e) {
				e.printStackTrace();
				Logs.log(e.getMessage());
			}

		}

	}

	private String getAllLinksAndTitles(List<WebElement> allLinks, String links) {
		for (int i = 0; i < allLinks.size(); i++) {
			try {
				links = links.concat(
						"<br>" + getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href") + "<br>");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return links;
	}

	public String getTextForReport(List<WebElement> allLinks, int i) {
		String text = "";
		try {
			text = allLinks.get(i).getText().trim();

			if (text.equals("")) {
				text = "Image Click ";
			}
			return text;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return text;
	}

	private void filePathsWebVadidation(Hashtable<String, String> hashtable) {
		generateReport(hashtable.size() > 0, "ssl.o.webmd.com/b/ss/webmd: call  tracked <br>" + hashtable.toString(),
				"ssl.o.webmd.com/b/ss/webmd call not tracked <br>" + hashtable.toString());

		generatePassReport("g : " + hashtable.get("g") + "<br>pageName : " + hashtable.get("pageName") + "<br>tm : "
				+ hashtable.get("tm") + "<br>clkurl : " + hashtable.get("clkurl"));

	}

	private void filePathsWebVadidationSF(Hashtable<String, String> hashtable, String SFID) {
		try {
			generateReport(hashtable.size() > 0,
					"ssl.o.webmd.com/b/ss/webmd: Ominiture call  tracked <br>" + hashtable.toString(),
					"ssl.o.webmd.com/b/ss/webmd Ominiture call not tracked <br>" + hashtable.toString());
			if (hashtable.size() > 0 && hashtable.get("tm") != null && hashtable.get("clkurl") != null) {
				if (hashtable.get("tm").contains(SFID)) {
					generatePassReport(getBoldText("Attributes Tracked in Ominiture ssl.o call:") + "<br>"
							+ getBoldText("g:") + hashtable.get("g") + "<br>" + getBoldText("pageName")
							+ hashtable.get("pageName") + "<br>" + getBoldText("tm:") + hashtable.get("tm") + "<br>"
							+ getBoldText("clkurl") + hashtable.get("clkurl"));
				} else {
					generateFailReport(getBoldText("SF Number") + getBoldText(SFID) + getBoldText("Mismatch")
							+ "<br>g : " + hashtable.get("g") + "<br>pageName : " + hashtable.get("pageName")
							+ "<br>tm : " + hashtable.get("tm") + "<br>clkurl : " + hashtable.get("clkurl"));
				}
			} else {
				generateFailReport("Unable to track tm/clkurl attributes");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Hashtable<String, String> verifyC20Values(String c20Value) {
		Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
				"https://ssl.o.webmd.com/b/ss/webmddev/1", "c20", c20Value);
		generateReport(hashtable.size() > 0,
				"ssl.o.webmd.com/b/ss/webmd: c20 value  " + getBoldText(c20Value) + " tracked <br>"
						+ hashtable.toString(),
				"ssl.o.webmd.com/b/ss/webmd: c20 value  " + getBoldText(c20Value) + " not tracked <br>"
						+ hashtable.toString());
		return hashtable;
	}

	public Hashtable<String, String> verifypev2Values(String pev2Value) {
		Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
				"https://ssl.o.webmd.com/b/ss/webmddev/1", "pev2", pev2Value);
		generateReport(hashtable.size() > 0,
				" In ssl.o.webmd.com/b/ss/webmd: pev2 value  " + getBoldText(pev2Value) + " tracked <br>"
						+ hashtable.toString(),
				"In ssl.o.webmd.com/b/ss/webmd: pev2 value  " + getBoldText(pev2Value) + " not tracked <br>"
						+ hashtable.toString());
		return hashtable;
	}

	public Hashtable<String, String> verifypev2Values(BrowserMobProxyServer server, String pev2Value) {
		Hashtable<String, String> hashtable = new Hashtable<>();
		try {
			Thread.sleep(2000);
			hashtable = getStdParmValues(server, "https://ssl.o.webmd.com/b/ss/webm", "pev2", pev2Value);
			generateReport(hashtable.size() > 0,
					"In ssl.o.webmd.com/b/ss/webmd: pev2 value  " + getBoldText(pev2Value) + " tracked <br>"
							+ hashtable.toString(),
					"In ssl.o.webmd.com/b/ss/webmd: pev2 value  " + getBoldText(pev2Value) + " not tracked <br>"
							+ hashtable.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hashtable;
	}

	public void validateAPICalls(String tacticID, String promoID, String env) {
		Hashtable<String, String> hashtable = getAPIParmValues(getproxyServer(), "api." + env + "medscape.com",
				"participation", "tacticId", tacticID, promoID);
		generateReport(hashtable.size() > 0,
				getBoldText("api." + env + "medscape.com") + ": participation values  "
						+ getBoldText("tactic id :" + tacticID) + " and " + getBoldText("PromoID id :" + promoID)
						+ " tracked <br>" + hashtable.toString(),
				getBoldText("api." + env + "medscape.com") + ": participation values  "
						+ getBoldText("tactic id :" + tacticID) + " and " + getBoldText("PromoID id :" + promoID)
						+ " not tracked <br>" + hashtable.toString());
		hashtable = getAPIParmValues(getproxyServer(), "api." + env + "medscape.com", "adimpr", "tcid", tacticID,
				promoID);
		generateReport(hashtable.size() > 0,
				getBoldText("api." + env + "medscape.com") + ": adimpr values  " + getBoldText("tactic id :" + tacticID)
						+ " and " + getBoldText("PromoID id :" + promoID) + " tracked <br>" + hashtable.toString(),
				getBoldText("api." + env + "medscape.com") + ": participation values  "
						+ getBoldText("tactic id :" + tacticID) + " and " + getBoldText("PromoID id :" + promoID)
						+ " not tracked <br>" + hashtable.toString());
	}

	public void sgvApiCallsValidation(String tacticID, String promoID, String Branded, String MessageCategory,
			String env) throws Exception {
		sgvImpressionValues(getproxyServer(), "api." + env + "medscape.com", "participation", "tacticId", tacticID,
				promoID, Branded, MessageCategory);

		sgvImpressionValues(getproxyServer(), "api." + env + "medscape.com", "adimpr", "tcid", tacticID, promoID,
				Branded, MessageCategory);

	}

	public void headlineapicall(String tacticID, String promoID, String env) throws Exception {
		headlineApiCalls(getproxyServer(), "api." + env + "medscape.com", "headlineimpr", "tcid", tacticID, promoID);

	}

	public void headlineapicallparticipation(String tacticID, String promoID, String env) throws Exception {
		headlineApiCalls(getproxyServer(), "api." + env + "medscape.com", "participation", "tacticId", tacticID,
				promoID);

	}

	public void validateHeadLineImprCall(String HeadLineTactic, String HeadLineActivity, String env) {
		Hashtable<String, String> hashtable;

		hashtable = getAPIParmValues(getproxyServer(), "api." + env + "medscape.com", "headlineimpr", "tcid",
				HeadLineTactic, HeadLineActivity);

		generateReport(hashtable.size() > 0,
				getBoldText("api." + env + "medscape.com") + ": headlineimpr values  "
						+ getBoldText("tactic id :" + HeadLineTactic) + " and "
						+ getBoldText("PromoID id :" + HeadLineActivity) + " tracked <br>" + hashtable.toString(),
				getBoldText("api." + env + "medscape.com") + ": headlineimpr values  "
						+ getBoldText("tactic id :" + HeadLineTactic) + " and "
						+ getBoldText("PromoID id :" + HeadLineActivity) + " not tracked <br>" + hashtable.toString());
	}

	public void validateHeadLineImprCallv2(String HeadLineTactic, String HeadLineActivity, String env) {
		Hashtable<String, String> hashtable;

		hashtable = getAPIParmValues(getproxyServer(), "api." + env + "medscape.com", "headlineimpr", "tcid",
				HeadLineTactic, HeadLineActivity);

		generateReport(hashtable.size() > 0,
				getBoldText("api." + env + "medscape.com") + ": headlineimpr values  "
						+ getBoldText("tactic id :" + HeadLineTactic) + " and "
						+ getBoldText("PromoID id :" + HeadLineActivity) + " tracked <br>" + hashtable.toString(),
				getBoldText("api." + env + "medscape.com") + ": headlineimpr values  "
						+ getBoldText("tactic id :" + HeadLineTactic) + " and "
						+ getBoldText("PromoID id :" + HeadLineActivity) + " not tracked <br>" + hashtable.toString());
	}

	public void validateHeadLineParticipationCall(String HeadLineTactic, String HeadLineActivity, String env) {

		Hashtable<String, String> hashtable = getAPIParmValues(getproxyServer(), "api." + env + "medscape.com",
				"participation", "tacticID", HeadLineTactic, HeadLineActivity);

		generateReport(hashtable.size() > 0,
				getBoldText("api." + env + "medscape.com") + ": participation values "
						+ getBoldText("tactic id :" + HeadLineTactic) + " and"
						+ getBoldText("Activity Id :" + HeadLineActivity) + " tracked <br>" + hashtable.toString(),
				getBoldText("api." + env + "medscape.com") + ": paticipation values "
						+ getBoldText("tactic id" + HeadLineTactic) + " and"
						+ getBoldText("Activity Id :" + HeadLineActivity) + " not tracked <br>" + hashtable.toString());
	}

	public void verifynoCacheTS3(String SFID) {
		Hashtable<String, String> hashtable = getMatchedParamURL(getproxyServer(), "nocache", SFID);
		generateReport(hashtable.size() > 0, getBoldText("nocache") + "  tracked <br>" + hashtable.toString(),
				getBoldText("nocache") + " not tracked <br>" + hashtable.toString());
		hashtable = new Hashtable<>();
		hashtable = getMatchedParamURL(getproxyServer(), "ts3", SFID);
		generateReport(hashtable.size() > 0, getBoldText("ts3") + "  tracked <br>" + hashtable.toString(),
				getBoldText("ts3") + " not tracked <br>" + hashtable.toString());
	}

	public void verifyNoCount(String SFID) {
		Hashtable<String, String> hashtable = getMatchedParamURL(getproxyServer(), "nocount", SFID);

		generateReport(hashtable.size() > 0, getBoldText("nocount") + "  tracked <br>" + hashtable.toString(),
				getBoldText("nocount") + " not tracked <br>" + hashtable.toString());

	}

	public Hashtable<String, String> verifyC20Values(BrowserMobProxyServer server, String c20Value) {
		Hashtable<String, String> hashtable = new Hashtable<>();
		try {
			Thread.sleep(2000);
			hashtable = getStdParmValues(server, "https://ssl.o.webmd.com/b/ss/webm", "c20", c20Value);
			generateReport(hashtable.size() > 0,
					"ssl.o.webmd.com/b/ss/webmd: c20 value  " + getBoldText(c20Value) + " tracked <br>"
							+ hashtable.toString(),
					"ssl.o.webmd.com/b/ss/webmd: c20 value  " + getBoldText(c20Value) + " not tracked <br>"
							+ hashtable.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hashtable;
	}

	public void mobileSGVValuesValidations(String SFID) {

		verifyC20Values("alm_pr," + SFID);
		verifyC20Values("alm_pc," + SFID);
		verifyC20Values("al_cp," + SFID);
		verifyC20Values("al_s");
	}

	public void webSGVValuesValidations(String SFID) {

		verifyC20Values("_pr," + SFID);
		verifyC20Values("ald_pc," + SFID);
		verifyC20Values("al_cp," + SFID);
		verifyC20Values("al_s");
	}

	public void webSGVValuesValidationsNew(String SFID) {

		verifypev2Values("ald_pr," + SFID);
		verifypev2Values("ald_pc," + SFID);
		verifypev2Values("al_cp," + SFID);
		verifypev2Values("al_s");
	}

	public void mobileSGVValuesValidationsNew(String SFID) {

		verifypev2Values("alm_pr," + SFID);
		verifypev2Values("alm_pc," + SFID);
		verifypev2Values("al_cp," + SFID);
		verifypev2Values("al_s");
	}

	public Hashtable<String, String> getMatchedParamURL(BrowserMobProxyServer server, String value, String sfid) {

		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;
		int noOFTimes = 0;

		while (!valueTracked) {

			try {
				if (noOFTimes == 3) {
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(value) && requestUrl.contains(sfid + "/")) {
						// Logs.info(requestUrl);
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

						// System.out.println(entries.get(i).getRequest().getQueryString());
						stdValues = new Hashtable<>();

						for (HarNameValuePair harNameValuePair : harNameValuePairs) {

							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());

						}
						return stdValues;

					}

				}
			} catch (Exception e) {
				Logs.logAndConsole(e.getMessage());
			}
		}
		return stdValues;

	}

	public void headlineApiCalls(BrowserMobProxyServer server, String domaine, String activityName, String tacticName,
			String tackticID, String activityID) throws Exception {
		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;

		int noOFTimes = 0;
		String trackedCallsWithGivenDomine = "";

		trackedCallsWithGivenDomine = "";
		Thread.sleep(2000);
		noOFTimes++;
		Har har = server.getHar();
		List<HarEntry> entries = har.getLog().getEntries();

		for (int i = 0; i < entries.size(); i++) {

			String requestUrl = entries.get(i).getRequest().getUrl();
			Logs.log(requestUrl);
			if (requestUrl.contains(domaine)) {
				try {

					List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();
					trackedCallsWithGivenDomine = trackedCallsWithGivenDomine
							+ entries.get(i).getRequest().getQueryString() + "<br>";

					// System.out.println(entries.get(i).getRequest().getQueryString());
					stdValues = new Hashtable<>();

					// if(!harNameValuePairs.isEmpty()){
					for (HarNameValuePair harNameValuePair : harNameValuePairs) {

						stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
					}
					if (stdValues.containsKey("event")) {

						if (stdValues.get("event").contains(activityName)) {

							String impressionCall = stdValues.get("event");
							valueTracked = true;
							apicallsparse(tackticID, activityID, activityName, impressionCall);

						}

					}
					// }else{

					// generateFailReport("Impression Value Not Tracked");
					// }

				} catch (Exception e) {
				}

			}

		}
		if (!valueTracked) {
			generateFailReport("Unable to Track  " + activityName + "  call");
		}

	}

	public void sgvImpressionValues(BrowserMobProxyServer server, String domaine, String activityName,
			String tacticName, String tackticID, String activityID, String Branded, String MessageCategory)
			throws Exception {
		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;

		int noOFTimes = 0;
		String trackedCallsWithGivenDomine = "";

		trackedCallsWithGivenDomine = "";
		Thread.sleep(2000);
		noOFTimes++;
		Har har = server.getHar();
		List<HarEntry> entries = har.getLog().getEntries();

		for (int i = 0; i < entries.size(); i++) {

			String requestUrl = entries.get(i).getRequest().getUrl();
			Logs.log(requestUrl);
			if (requestUrl.contains(domaine)) {
				try {

					List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();
					trackedCallsWithGivenDomine = trackedCallsWithGivenDomine
							+ entries.get(i).getRequest().getQueryString() + "<br>";

					// System.out.println(entries.get(i).getRequest().getQueryString());
					stdValues = new Hashtable<>();

					// if(!harNameValuePairs.isEmpty()){
					for (HarNameValuePair harNameValuePair : harNameValuePairs) {

						stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
					}
					if (stdValues.containsKey("event")) {

						if (stdValues.get("event").contains(activityName)) {

							String impressionCall = stdValues.get("event");
							valueTracked = true;
							sgvApicallsparse(tackticID, activityID, activityName, impressionCall, Branded,
									MessageCategory);

						}

					}
					// }else{

					// generateFailReport("Impression Value Not Tracked");
					// }

				} catch (Exception e) {
				}

			}

		}
		if (!valueTracked) {
			// generateInfoReport("Unable to Track "+activityName+" call");

			generateFailReport("Unable to Track  " + activityName + "  call");
		}

	}

	public void apicallsparse(String tackticID, String activityID, String ImpressionName, String apicall)
			throws Exception {

		boolean hlFlag = false;
		boolean partcipationFlag = false;

		JSONParser jsonParser = new JSONParser();

		JSONObject jsonObject = (JSONObject) jsonParser.parse(apicall);
		String activityName = (String) jsonObject.get("activityName");
		if (ImpressionName.equalsIgnoreCase("participation")) {
			String tacticId = (String) jsonObject.get("tacticId");
			String promo = (String) jsonObject.get("activityId");
			// generateInfoReport(getBoldText("Tactic ID: ")+tacticId+
			// getBoldText("<br>Promo ID: ")+promo);
			generateReport(tacticId.equals(tackticID) && promo.equals(activityID),
					getBoldText("Participation Tracked  <br>Tactic ID:   ") + tacticId + getBoldText("<br>Promo ID:   ")
							+ promo + "<br>" + apicall,
					getBoldText("Invalid Participation Tracked <br>Tactic ID:   ") + tacticId
							+ getBoldText("<br>Promo ID:   ") + promo + "<br>" + apicall);
			partcipationFlag = true;

		} else if (ImpressionName.equalsIgnoreCase("headlineimpr")) {

			JSONArray imprValue = (JSONArray) jsonObject.get("impr");
			Iterator<Object> i1 = imprValue.iterator();
			int hitrack = 0;
			String TacticID = null;
			String activityid = null;

			while (i1.hasNext()) {
				JSONObject innerObj = (JSONObject) i1.next();
				TacticID = String.valueOf(innerObj.get("tcid")).trim();
				activityid = String.valueOf(innerObj.get("activityId")).trim();

				if (TacticID.equals(tackticID) && activityid.equals(activityID)) {
					// generateReport(TacticID.equals(tackticID)&&activityid.equals(activityID),getBoldText("Adimpr
					// Tracked <br>Tactic ID: ")+TacticID+ getBoldText("<br>Promo ID:
					// ")+activityid,getBoldText("Adimpr Not Tracked <br>Tactic ID: ")+TacticID+
					// getBoldText("<br>Promo ID: ")+activityid);
					hitrack = hitrack + 1;
					hlFlag = true;
					break;
					// generateInfoReport("Tactic Id "+TacticID+ "<br> Promo ID "+
					// activityid+getBoldText("<br>branded ")+ brandedParameter+
					// getBoldText("<br>Message Category ")+messagecategery );

				}

			}
			if (hitrack > 0) {
				generatePassReport("Headline impr Tracked");
				generateInfoReport(
						getBoldText("Below Values are Tracked for Headline Impr:") + getBoldText("<br>Tactic ID:  ")
								+ TacticID + getBoldText("<br>Promo ID:  ") + activityid + "<br>" + imprValue);

			} else {
				generateFailReport(getBoldText("In valid Headline  impr Tracked") + imprValue);
			}

		}

	}

	public void sgvApicallsparse(String tackticID, String activityID, String ImpressionName, String apicall,
			String Branded, String MessageCategory) throws Exception {

		JSONParser jsonParser = new JSONParser();

		JSONObject jsonObject = (JSONObject) jsonParser.parse(apicall);
		String activityName = (String) jsonObject.get("activityName");
		if (ImpressionName.equalsIgnoreCase("participation")) {
			String tacticId = (String) jsonObject.get("tacticId");
			String promo = (String) jsonObject.get("activityId");
			// generateInfoReport(getBoldText("Tactic ID: ")+tacticId+
			// getBoldText("<br>Promo ID: ")+promo);
			generateReport(tacticId.equals(tackticID) && promo.equals(activityID),
					getBoldText("Participation call Tracked  <br>Tactic ID:   ") + tacticId
							+ getBoldText("<br>Promo ID:   ") + promo + "<br>" + apicall,
					getBoldText("InValid Participation Call Tracked-Wrong Values Tracked <br>Tactic ID:   ") + tacticId
							+ getBoldText("<br>Promo ID:   ") + promo + "<br>" + apicall);

		}

		else if (ImpressionName.equalsIgnoreCase("adimpr")) {
			JSONArray imprValue = (JSONArray) jsonObject.get("impr");
			Iterator<Object> i1 = imprValue.iterator();
			int track = 0;
			String TacticID = null;
			String activityid = null;
			String brandedParameter = null;
			String messagecategery = null;
			while (i1.hasNext()) {
				JSONObject innerObj = (JSONObject) i1.next();
				TacticID = String.valueOf(innerObj.get("tcid")).trim();
				activityid = String.valueOf(innerObj.get("activityId")).trim();
				brandedParameter = String.valueOf(innerObj.get("branded")).trim();
				messagecategery = String.valueOf(innerObj.get("msgCategory")).trim();
				if (TacticID.equals(tackticID) && activityid.equals(activityID) && brandedParameter.equals(Branded)
						&& messagecategery.equals(MessageCategory)) {
					// generateReport(TacticID.equals(tackticID)&&activityid.equals(activityID),getBoldText("Adimpr
					// Tracked <br>Tactic ID: ")+TacticID+ getBoldText("<br>Promo ID:
					// ")+activityid,getBoldText("Adimpr Not Tracked <br>Tactic ID: ")+TacticID+
					// getBoldText("<br>Promo ID: ")+activityid);
					track = track + 1;
					break;
					// generateInfoReport("Tactic Id "+TacticID+ "<br> Promo ID "+
					// activityid+getBoldText("<br>branded ")+ brandedParameter+
					// getBoldText("<br>Message Category ")+messagecategery );

				}

			}
			if (track > 0) {
				generatePassReport("Ad impr Tracked");
				generateInfoReport(getBoldText("Below Values are Tracked for Adimpr:") + getBoldText("<br>Tactic ID:  ")
						+ TacticID + getBoldText("<br>Promo ID:  ") + activityid + getBoldText("<br>branded:  ")
						+ brandedParameter + getBoldText("<br>Message Category:  ") + messagecategery + "<br>"
						+ imprValue);
			} else {
				generateFailReport(
						getBoldText("InValid Ad impr call Tracked-Wrong Values Tracked") + "<br>" + imprValue);
			}

		}

	}

	public Hashtable<String, String> getAPIParmValues(BrowserMobProxyServer server, String domaine, String activityName,
			String tacticName, String tackticID, String activityID) {
		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;
		int noOFTimes = 0;
		String trackedCallsWithGivenDomine = "";
		while (!valueTracked) {
			try {
				if (noOFTimes == 3) {
					generateInfoReport(
							"Tracked URls with " + getBoldText(domaine) + "<br>" + trackedCallsWithGivenDomine);
					return stdValues;
				}
				trackedCallsWithGivenDomine = "";
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(domaine)) {
						try {
							List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();
							trackedCallsWithGivenDomine = trackedCallsWithGivenDomine
									+ entries.get(i).getRequest().getQueryString() + "<br>";

							// System.out.println(entries.get(i).getRequest().getQueryString());
							stdValues = new Hashtable<>();

							for (HarNameValuePair harNameValuePair : harNameValuePairs) {

								stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());

							}
							String event = stdValues.get("event");
							if (event.contains("\"activityName\":\"" + activityName + "\"")
									&& event.contains("\"" + tacticName + "\":\"" + tackticID + "\"")
									&& event.contains("\"activityId\":\"" + activityID + "\"")) {
								valueTracked = true;
								return stdValues;
							}
						} catch (Exception e) {

						}
					}

				}

			} catch (Exception e) {
			}
			generateInfoReport("Tracked URls with " + getBoldText(domaine) + "<br>" + trackedCallsWithGivenDomine);
			return stdValues;

		}
		return stdValues;

	}

	/**
	 * If the tactic present it will return true or else it will try to log in with
	 * different users till tactic present in viewsource
	 * 
	 * @param tactic
	 * @param headLineUser
	 * @return
	 */
	public boolean isTacticPresent(String tactic, String headLineUser) {

		boolean b = driver.getPageSource().contains(tactic);

		int loopCount = 0;
		while (!b) {
			generateInfoReport("======= Tactic : " + tactic
					+ " is Not displayed, login perfoming with other users from excel sheet ======");

			String users[][] = GetHeadLineUsers.getHeadLineAvaialbeUser();
			try {
				login(users[0][0], users[0][1]);
				if (env.contains("staging")) {
					driver.get("https://www." + env + "medscape.com/" + prop.getProperty("homepageSpeciality"));
				}
			} catch (Exception e) {
				b = getDriver().getPageSource().contains(tactic);
				loopCount++;
				Logs.log("No of logins performed " + loopCount);
				{
					throw new Error("Tactic not avaialbe for users, please update users in excel and try again");
				}
			}
			b = getDriver().getPageSource().contains(tactic);
			loopCount++;
			Logs.log("No of logins performed " + loopCount);

		}

		if (loopCount > 0) {
			generateInfoReport("Number of times user logged in to get required tactic in page source :"
					+ getBoldText(String.valueOf(loopCount)));
		}
		return b;

	}

	public boolean isTacticPresent(String tactic, String headLineUser, GetHeadLineUsersWithRowRange data) {

		boolean b = driver.getPageSource().contains(tactic);
		if (!b) {
			generateInfoReport("======= Tactic : " + tactic
					+ " is Not displayed, login perfoming with other users from excel sheet ======");
		}

		int loopCount = 0;

		while (!b) {

			try {
				String users[][] = data.getHeadLineAvaialbeUser();
				login(users[0][0], users[0][1]);
			} catch (Exception e) {
				throw new Error("Tactic not avaialbe for users, please update users in excel and try again");
			}
			b = getDriver().getPageSource().contains(tactic);
			loopCount++;
			Logs.log("No of logins performed " + loopCount);
		}
		if (loopCount > 0) {
			generateInfoReport("Number of times user logged in to get required tactic in page source :"
					+ getBoldText(String.valueOf(loopCount)));
		}
		return b;

	}

	public void generateSkipReport(String string) {
		ExtentTestManager.getTest().log(LogStatus.SKIP, string);
		Logs.logAndConsole(string.replace(LEFTBOLDTAG, "").replace(RIGHTBOLDTAG, "").replace("<br>", "\n"));
		ExtentTestManager.getTest().log(LogStatus.INFO, ExtentTestManager.getTest().addScreenCapture(getScreenshot()));

	}

	/**
	 * Get Text from webelement
	 * 
	 * @param by
	 * @return
	 */
	public String getText(By by) {

		try {
			return driver.findElement(by).getText().trim();
		} catch (Exception e) {

			return "No Text Displayed:" + e.getMessage();
		}
	}

	/**
	 * Verifies hp2 and hp5 ads in mobile
	 * 
	 * @param URL
	 * @param SFID
	 * @param headLineTactic
	 * @param headLineUser
	 * @param headLineActivity
	 * @param expIFITitle
	 * @param data
	 * @return
	 */
	public HashMap<String, Boolean> is2AdsDisplayed(String URL, String SFID, String ad1, String ad2,
			String headLineTactic, String headLineUser, String headLineActivity, String expIFITitle, String env,
			GetHeadLineUsersWithRowRange data) {

		generateInfoReport("====== Started verification for " + getBoldText("Headline") + " =======<br>Ad positions:"
				+ getBoldText(ad1) + " and " + getBoldText(ad2));
		boolean hp2Ad = false;
		boolean hp5Ad = false;

		HashMap<String, Boolean> adstatus = new HashMap<>();
		adstatus.put("hp2Ad", false);
		adstatus.put("hp5Ad", false);

		int loopCount = 0;
		int ad1loopCount = 0;
		int ad2loopCount = 0;

		while (!(hp2Ad && hp5Ad)) {
			if (loopCount == Integer.parseInt(prop.getProperty("HeadLinePageRefreshCount"))) {
				break;
			}
			startNewHar();
			getDriver().get(URL);
			loopCount++;
			ad1loopCount++;
			ad2loopCount++;
			isTacticPresent(headLineTactic, headLineUser, data);
			Logs.log("Number of times URL refreshed :" + loopCount);

			try {

				if (!hp2Ad) {

					String ad1Xpath = "//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]//img";
					driver.findElement(By.xpath(ad1Xpath)).isDisplayed();
					boolean b = true;
					adstatus.put("hp2Ad", b);
					hp2Ad = b;
					if (b) {
						try {
							WebElement element = driver.findElement(By.xpath(ad1Xpath));
							scrollToObject(element);
							Thread.sleep(500);
						} catch (Exception e) {
							Logs.logAndConsole(e.getMessage());
						}
						generatePassReportWithScreenShot(
								getBoldText("" + ad1 + "") + " ad is displayed with SFID " + SFID + " used xpath <br>"
										+ "//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]");
						String actual = getText(
								By.xpath("//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]"))
										.replace("Information from Industry", "").trim();
						generateReport(actual.equals(expIFITitle),
								"IFI title  matched <br>Actual: " + actual + "<br>Expected:" + expIFITitle,
								"IFI title not matched <br>Actual: " + actual + "<br>Expected:" + expIFITitle);
						// validateHeadLineImprCall(headLineTactic, headLineActivity, env);
						headlineapicall(headLineTactic, headLineActivity, env);
						generateInfoReport(
								"No of refreshes done to surface " + getBoldText(ad1) + " ad is " + ad1loopCount);
					}
				}

			} catch (Exception e) {
				// printAllLinksText(By.className("ifi-title"));
			}
			try {

				if (!hp5Ad) {
					driver.findElement(
							By.xpath("//a[contains(@href,'" + ad2 + "') and contains(@href,'" + SFID + "')]"))
							.isDisplayed();
					boolean b = true;
					adstatus.put("hp5Ad", b);
					hp5Ad = b;
					if (b) {
						try {
							WebElement element = driver.findElement(By.xpath(
									"//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]//img"));
							scrollToObject(element);
							Thread.sleep(500);
						} catch (Exception e) {
							// TODO: handle exception
						}
						generatePassReportWithScreenShot(
								getBoldText("" + ad2 + "") + " ad is displayed with SFID " + SFID + " used xpath <br>"
										+ "//a[contains(@href,'" + ad2 + "') and contains(@href,'" + SFID + "')]");
						// validateHeadLineImprCall(headLineTactic, headLineActivity, env);
						headlineapicall(headLineTactic, headLineActivity, env);
						String actual = getText(
								By.xpath("//a[contains(@href,'" + ad2 + "') and contains(@href,'" + SFID + "')]"))
										.replace("Information from Industry", "").trim();
						generateReport(actual.equals(expIFITitle),
								"IFI title  matched <br>Actual: " + actual + "<br>Expected:" + expIFITitle,
								"IFI title not matched <br>Actual: " + actual + "<br>Expected:" + expIFITitle);
						generateInfoReport(
								"No of refreshes done to surface " + getBoldText(ad2) + " ad is " + ad2loopCount);
					}
				}

			} catch (Exception e) {
				// printAllLinksText(By.className("ifi-title"));
			}

		}

		if (!hp2Ad) {
			generateFailReport(getBoldText(ad1) + " ad is not  displayed with SFID " + SFID + " used xpath <br>"
					+ "//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID
					+ "')]<br>No of page refreshes done: " + ad1loopCount);
		}

		if (!hp5Ad) {
			generateFailReport(getBoldText(ad2) + " ad is not  displayed with SFID " + SFID + " used xpath <br>"
					+ "//a[contains(@href,'" + ad2 + "') and contains(@href,'" + SFID
					+ "')]<br>No of page refreshes done: " + ad2loopCount);
		}

		return adstatus;

	}

	public void scrollToObject(WebElement element) {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Logs.logAndConsole("Scrolled to Object: " + element);
		} catch (Exception e) {
			Logs.logAndConsole("Scrolled failed to Object: " + e.getMessage());
		}
	}

	/**
	 * 
	 */
	public void login(String userName, String pwd) {
		Logs.logAndConsole(" ============ Login started with " + userName + " and " + pwd + " ==============");
		try {
			deleteCookies();
			getDriver().get("https://login.medscape.com/login/sso/getlogin?ac=401");
			enter(By.id("regularEmail"), userName, "username");
			enter(By.id("password"), pwd, "password");
		} catch (Exception e) {

			e.printStackTrace();
		}
		boolean b = click(By.id("loginBtn"), "Login");
		Logs.logAndConsole(" ========    Login Completed with " + userName + " and " + pwd + "   =================");
		// Assert.assertTrue(b, " Login failed with username " + userName + " ,pwd: " +
		// pwd);
		Handlepopups();

		if (env.contains("staging")) {
			driver.get("https://www." + env + "medscape.com/" + prop.getProperty("homepageSpeciality"));
			Handlepopups();

		}
	}

	public void Handlepopups() {

		try {
			if (driver.findElements(By.id("nDlayer_close")).size() > 0) {
				driver.findElement(By.id("nDlayer_close")).click();

			}
			if (driver.findElements(By.id("agtCloseBtn")).size() > 0) {

				driver.findElement(By.id("agtCloseBtn")).click();
			}
			if (driver.findElements(By.xpath("//body[@class='is-www show-hcp-message']//*[@id='close']")).size() > 0) {

				driver.findElement(By.xpath("//body[@class='is-www show-hcp-message']//*[@id='close']")).click();

			}
			if (driver.findElements(By.className("close-video-violator")).size() > 0) {

				driver.findElement(By.className("close-video-violator")).click();

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void loadURL(String url) {
		driver.get(url);
	}

	public void deleteCookies() {
		try {
			getDriver().manage().deleteAllCookies();
			Logs.logAndConsole("All Cookies deleted");
		} catch (Exception e) {

		}
	}

	public void printAllLinksText(By by) {

		try {
			List<WebElement> elements = driver
					.findElements(By.xpath("//*[@class='ifititle' or @class='ifi-title']/parent::a"));
			Logs.logAndConsole("Displayed IFI ads");
			for (WebElement webElement : elements) {
				Logs.logAndConsole(webElement.getAttribute("href"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

	}

	/**
	 * Verifies single Ad
	 * 
	 * @param URL
	 * @param SFID
	 * @param headLineActivity
	 * @param expIFITitle
	 * @param data
	 * @return
	 */
	public HashMap<String, Boolean> isSingleAdDisplayed(String URL, String SFID, String ad1, String headLineTactic,
			String headLineUser, String headLineActivity, String expIFITitle, String env,
			GetHeadLineUsersWithRowRange data) {

		boolean hp2Ad = false;

		HashMap<String, Boolean> adstatus = new HashMap<>();
		adstatus.put("hp2Ad", false);

		int loopCount = 0;

		while ((!hp2Ad)) {
			startNewHar();
			if (loopCount == Integer.parseInt(prop.getProperty("HeadLinePageRefreshCount"))) {
				break;
			}
			if (loopCount > 0) {

				driver.get(URL);
				Handlepopups();

			}

			isTacticPresent(headLineTactic, headLineUser, data);
			loopCount++;
			Logs.log("Number of times URL refreshed :" + loopCount);

			try {

				if (!hp2Ad) {
					boolean b = false;
					try {
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]//img"))
								.isDisplayed();
						b = true;
						adstatus.put("hp2Ad", b);
						hp2Ad = b;
					} catch (Exception e1) {

					}
					if (hp2Ad) {
						try {
							WebElement element = driver.findElement(By.xpath(
									"//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]//img"));
							scrollToObject(element);
							// Thread.sleep(500);
						} catch (Exception e) {

						}
						generatePassReportWithScreenShot(
								getBoldText("" + ad1 + "") + " ad is displayed with SFID " + SFID + " used xpath <br>"
										+ "//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]");
						// validateHeadLineImprCall(headLineTactic, headLineActivity, env);
						headlineapicall(headLineTactic, headLineActivity, env);
						String actual = getText(
								By.xpath("//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID + "')]"))
										.replace("Information from Industry", "").trim();

						generateReport(actual.equals(expIFITitle),
								"IFI title  matched <br>Actual: " + actual + "<br>Expected:" + expIFITitle,
								"IFI title not matched <br>Actual: " + actual + "<br>Expected:" + expIFITitle);

						generateInfoReport(
								"No of refreshes done to surface " + getBoldText(ad1) + " ad is " + loopCount);
					}
				}

			} catch (Exception e) {

			}

		}

		if (!hp2Ad) {
			generateFailReport(getBoldText(ad1) + " ad is not  displayed with SFID " + SFID + " used xpath <br>"
					+ "//a[contains(@href,'" + ad1 + "') and contains(@href,'" + SFID
					+ "')]<br>No of page refreshes done: " + loopCount);

		}

		return adstatus;

	}

	public void validateSGVCallDisplayed(String SFID, String newsArticle) {
		staticWait(6);
		Hashtable<String, String> hashtable = getMatchedParamURL(getproxyServer(), "nocache", SFID);
		int loopcount = 0;
		while (loopcount < Integer.parseInt(prop.getProperty("SGVPageRefreshCount"))) {
			if (!(hashtable.size() > 0)) {
				startNewHar();
				get(newsArticle);
				staticWait(6);
				hashtable = getMatchedParamURL(getproxyServer(), "nocache", SFID);
				loopcount++;
			} else {
				try {
					if (driver.findElements(By.className("close-video-violator")).size() > 0) {

						driver.findElement(By.className("close-video-violator")).click();
						staticWait(2);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				generateInfoReport("No of times page refreshed to get required nocache call with SFID " + SFID + " is "
						+ loopcount);
				break;
			}
		}
	}

	public void validateSGVCallDisplayedforRefresh(String SFID) {
		staticWait(7);
		Hashtable<String, String> hashtable = getMatchedParamURL(getproxyServer(), "nocache", SFID);
		int loopcount = 0;
		while (loopcount < Integer.parseInt(prop.getProperty("SGVPageRefreshCount"))) {
			if (!(hashtable.size() > 0)) {
				startNewHar();
				getDriver().navigate().refresh();
				staticWait(7);
				hashtable = getMatchedParamURL(getproxyServer(), "nocache", SFID);
				loopcount++;
			} else {

				try {
					if (driver.findElements(By.className("close-video-violator")).size() > 0) {

						driver.findElement(By.className("close-video-violator")).click();
						staticWait(6);

					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				generateInfoReport("No of times page refreshed to get required nocache call with SFID " + SFID + " is "
						+ loopcount);
				break;
			}
		}
	}

	public void staticWait(long seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (Exception e) {

		}
	}

	public Hashtable<String, String> validateDoubleclickTags(BrowserMobProxyServer server, String env, String SFID) {

		Hashtable<String, String> stdValues = new Hashtable<>();
		// boolean failuresTracked = true;

		try {

			Har har = server.getHar();
			List<HarEntry> entries = har.getLog().getEntries();
			// int noOffailures = 0;
			String dubleClickURL = "";
			// String failedURls = "";
			for (int i = 0; i < entries.size(); i++) {

				String requestUrl = entries.get(i).getRequest().getUrl();

				Logs.log(requestUrl);

				if (requestUrl.contains("ad.doubleclick.net") || requestUrl.contains("tps30.doubleverify.com")
						|| requestUrl.contains("https://cdn.doubleverify.com")
						|| requestUrl.contains("tps.doubleverify.com")) {

					dubleClickURL = dubleClickURL + "<br>" + requestUrl;

				}

			}

			if (dubleClickURL.isEmpty()) {
				generateInfoReport("No Third party double  Tag URL's Tracked");
			} else {
				generateInfoReport("Loaded Third party Tag URls :<br>" + dubleClickURL);
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		return stdValues;
	}

	public Hashtable<String, String> validateImages(BrowserMobProxyServer server, String env, String SFID) {

		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean failuresTracked = true;

		try {

			Har har = server.getHar();
			List<HarEntry> entries = har.getLog().getEntries();
			int noOffailures = 0;
			String imageURL = "";
			String failedURls = "";
			for (int i = 0; i < entries.size(); i++) {

				String requestUrl = entries.get(i).getRequest().getUrl();

				Logs.log(requestUrl);

				if (requestUrl.contains("medscapestatic.com") && requestUrl.contains(SFID)) {

					imageURL = imageURL + "<br>" + requestUrl;

					if (env.contains("staging")) {
						if (requestUrl.contains("img.medscapestatic.com")) {
							noOffailures++;
							failedURls = failedURls + "<br>" + requestUrl;
							failuresTracked = false;
						}
					} else {
						if (requestUrl.contains("img.staging.medscapestatic.com")) {
							noOffailures++;
							failedURls = failedURls + "<br>" + requestUrl;
							failuresTracked = false;
						}
					}

				}

			}

			generateInfoReport("Loaded img URls :<br>" + imageURL);
			generateReport(failuresTracked, "No other env image urls tracked",
					getBoldText(String.valueOf(noOffailures)) + " failure urls tracked<br>" + failedURls);

		} catch (Exception e) {
			System.out.println(e);
		}

		return stdValues;
	}

	public void testLayerLinksIosWeb(WebDriver driver, BrowserMobProxyServer server, String SFID, String env)
			throws InterruptedException {

		// Saving the captured netowrk traffice to .Har file

		String url = driver.getCurrentUrl();

		generatePassReport("====== Clicking on All Links =========");
		// layer links xpath
		List<WebElement> allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));

		generatePassReport("No of links available in Page: " + allLinks.size());

		String links = "";
		links = getAllLinksAndTitles(allLinks, links);

		generatePassReport("All Links and Href<br>" + links);

		for (int i = 0; i < allLinks.size(); i++) {

			// String winHandleBefore = ((AppiumDriver)driver).getContext();
			System.out.println("==============");
			// System.out.println(winHandleBefore);

			try {
				driver.findElement(By.className("close-video-violator")).click();
			} catch (Exception e) {

			}
			try {
				// if (allLinks.get(i).isDisplayed()) {

				String linkTextComplete = allLinks.get(i).getText().trim();

				String linkText = linkTextComplete.substring(0, 10);

				String xpath = "//*[contains(text(),'" + linkText + "')]";

				server.newHar();
				generatePassReport("*********************************************************");

				if (linkTextComplete.length() > 0) {
					click(By.xpath(xpath), linkTextComplete);
				} else {
					clickByWebElement(allLinks.get(i),
							getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));
				}
				// validate tracker marker call

				Hashtable<String, String> trackermarker = getStdParmValues(server, "medscape.com/px/trk.svr/promo-");

				generateReport(trackermarker.size() > 0,
						getBoldText("trackermarker call") + " : medscape.com/px/trk.svr/promo tracked <br>"
								+ trackermarker.toString(),
						getBoldText("trackermarker call") + ": medscape.com/px/trk.svr/promo not tracked <br>"
								+ trackermarker.toString());

				Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(), "ssl.o.webmd.com/b/ss/webmd");

				filePathsWebVadidation(hashtable);

				driver.get(url);

				allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));

				if (allLinks.size() == 0) {

					Thread.sleep(5000);
					allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));
				}
				// }
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	public void testLayerLinksAndroidApp(WebDriver driver, BrowserMobProxyServer server, String SFID, String env)
			throws InterruptedException {
		// server.newHar("OnSiteLinks.har");

		// Saving the captured netowrk traffice to .Har file

		generatePassReport("====== Clicking on All Links =========");
		// layer links xpath
		Thread.sleep(6000);
		List<WebElement> allLinks = driver.findElements(By.xpath(
				"//*[@text='Information From Industry']//*[@clickable='true' and @enabled='true' and @focusable='true']"));

		// Direct ios app
		if (allLinks.size() == 0) {
			allLinks = driver.findElements(By.xpath("//*[@class='UIAImage']//*"));
		}

		generatePassReport("No of links available in Page: " + allLinks.size());

		String links = "";
		links = getAllLinksAndTitles(allLinks, links);

		generatePassReport("All Links and Href<br>" + links);

		for (int i = 1; i < allLinks.size(); i++) {
			server.newHar();
			try {

				generatePassReport("*********************************************************");

				clickByWebElement(allLinks.get(i),
						getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));

				// validate tracker marker call
				Hashtable<String, String> trackermarker = getStdParmValues(server,
						"www.medscape.com/px/trk.svr/promo-");

				generateReport(trackermarker.size() > 0,
						getBoldText("trackermarker call") + " : www.medscape.com/px/trk.svr/promo-<br>"
								+ getBoldText(trackermarker.toString()) + " tracked <br>" + trackermarker.toString(),
						getBoldText("trackermarker call") + ": www.medscape.com/px/trk.svr/promo-<br>"
								+ getBoldText(trackermarker.toString()) + " not tracked <br>"
								+ trackermarker.toString());

				Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(), "ssl.o.webmd.com/b/ss/webmd");

				filePathsWebVadidation(hashtable);

				// generatePassReport("No of windows : " +
				// driver.getWindowHandles().size());
				// driver.close();

				if (driver.findElements(By.xpath(
						"//*[@text='Information From Industry']//*[@clickable='true' and @enabled='true' and @focusable='true']"))
						.size() == 0) {
					driver.navigate().back();
				}
				Thread.sleep(15000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public boolean waitForSplashPromoAd(AppiumDriver<WebElement> driver, String element, String headLineTactic,
			String headLineActivity, String env) throws InterruptedException {
		boolean isElementPresent = false;
		int noOfIterations = 0;
		Logs.logAndConsole("Looking for IFI: " + element);
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		while (noOfIterations < 20) {
			ArrayList<WebElement> listOfEle = new ArrayList<>();

			int slideSize = driver
					.findElements(By.xpath("//*[@id='indicator']/*[@class='android.widget.ImageView' and @width>0]"))
					.size();
			Logs.logAndConsole("Swipe Perfoming for all slides " + slideSize);
			for (int j = 0; j < slideSize; j++) {

				List<WebElement> ifiLinks = driver.findElements(By.xpath(
						"//*[@text='Information from Industry']//parent::*[contains(@class,'LinearLayout')]/*[@id='title']"));
				Logs.logAndConsole("No of swipe done " + j);
				listOfEle.addAll(ifiLinks);
				Thread.sleep(3000);
			}

			if (listOfEle.size() > 0) {
				boolean adsDisplayed = false;
				System.out.println("no of ifi " + listOfEle.size());
				for (int i = 0; i < listOfEle.size(); i++) {

					try {
						System.out.println(listOfEle.get(i).getText().trim());

						if (listOfEle.get(i).getText().trim().contains(element)) {
							adsDisplayed = true;
							System.out.println("Ad loaded in current page");
							generatePassReportWithScreenShot("Ad displayed " + element);
							// validateHeadLineImprCall(headLineTactic,
							// headLineActivity, env);
							break;

						}
					} catch (Exception e) {

					}
				}

				if (adsDisplayed) {
					break;
				}

			}
			driver.swipe(667, 582, 853, 1374, 519);

			noOfIterations++;
		}
		return isElementPresent;

	}

	public boolean isElementAvailable(WebDriver driver, String element) {

		boolean isElementPresent = false;
		try {
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			if (driver.findElement(By.xpath(element)).isDisplayed()) {
				isElementPresent = true;
				return isElementPresent;
			}
		}

		catch (Exception e) {
			return isElementPresent;
		}
		return isElementPresent;
	}

	public void assignTacticsToUsers(String env) throws InterruptedException {

		generateBoldInfo("======== Tactic assignment Started  ============");
		if (prop.get("tacticExecution").toString().equalsIgnoreCase("true") && env.toLowerCase().contains("staging")) {

			String[][] tackticUsers = XlRead.fetchDataBasedOnColumnType("TestInputs/RuntimeUsers.xls", "Headline",
					"Is Tactic Available", "TRUE");
			get("http://tools.medscape.com/cpadmin/event");

			enter(By.name("j_username"), prop.getProperty("tacticUserName"), "User name");
			enterSecurePassword(By.name("j_password"), prop.getProperty("tacticUserPwd"), "Password");
			// enter(By.name("j_password"),prop.getProperty("tacticUserPwd"), "Password");
			click(By.xpath("//*[@id='submitbutton']/input[1]"), "Login");

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			for (int i = 0; i < tackticUsers.length; i++) {

				enter(By.xpath("//input[@id='uid']"), tackticUsers[i][0], "GUID");
				driver.findElement(By.xpath("//input[@id='activityname']")).sendKeys("offline");
				driver.findElement(By.xpath("//input[@id='appname']")).sendKeys("offline");
				// click(By.xpath(".//*[@id='loginButton_label']/span"), "Send Login");
				click(By.xpath(".//*[@id='eventButton_label']/span"), "Send Event!");

				Thread.sleep(5000);

				generateInfoReport("User assignment complete:" + tackticUsers[i][1]);
				driver.findElement(By.xpath("//input[@id='activityname']")).clear();
				driver.findElement(By.xpath("//input[@id='appname']")).clear();
			}
			generateBoldInfo("================= Assignment completed ===================");

		} else {
			generateInfoReport("========== Tactic assignment Skipped ================");
		}
	}

	public void verifyQuestionnaireID() {
		// Hashtable<String, String> hashtable =
		// getMatchedParamURL(getproxyServer(), "questionnaire_id","");

		Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(), ".medscape.com/qna");
		generateReport(hashtable.size() > 0, getBoldText("questionnaire_id") + "  tracked <br>" + hashtable.toString(),
				getBoldText("questionnaire_id") + " not tracked <br>" + hashtable.toString());

		generateInfoReport(getBoldText("Questionnaire_id") + ": " + hashtable.get("questionnaire_id"));

	}

	public void clickAllradioButtons(WebDriver driver, By by, By bySubMit) {

		try {
			List<WebElement> elements = driver.findElements(by);
			Logs.logAndConsole("No of questions identified " + elements.size());
			for (int i = 0; i < elements.size(); i++) {

				elements.get(i).click();
			}

		} catch (Exception e) {

		}

		try {
			driver.findElement(bySubMit).click();
			generateInfoReport("Click Perfomed on Submit button");
			verifyQuestionnaireID();

		} catch (Exception e) {

		}

	}

	public void pollSubmit(WebDriver driver, By by, By bySubMit) {

		try {
			List<WebElement> elements = driver.findElements(by);
			Logs.logAndConsole("No of questions identified " + elements.size());
			for (int i = 0; i < elements.size(); i++) {

				// driver.findElement(By.xpath("//*[@class='qatable']//tbody//tr[2]//td//input[@type='radio']")).click();
				driver.findElement(By.xpath("(//*[@class='qatable'][" + (i + 1)
						+ "]//tbody//tr[@class='question']/following-sibling::tr//td/input)[1]")).click();

				elements.get(i).click();
			}

		} catch (Exception e) {
			e.getMessage();
		}

		try {
			driver.findElement(bySubMit).click();
			generateInfoReport("Click Perfomed on Submit button");
			verifyQuestionnaireID();

		} catch (Exception e) {
			e.getMessage();
		}

	}

	public void clickCloseConsultLayer() {
		try {
			getDriver().findElement(By.className("close-video-violator")).click();
			Logs.logAndConsole("Closed Video /Consults layer");
		} catch (Exception e) {
			// e.printStackTrace();// TODO: handle exception
		}
	}

	public void viewSource(String tacticID) {
		driver.get("https://emedicine.staging.medscape.com/article/924411-overview");
		boolean tactic1 = driver.getPageSource().contains(tacticID);
		if (tactic1) {
			generateInfoReport("Tactic " + getBoldText(tacticID) + " is displayed in pagesource");
		} else {
			generateInfoReport(
					"Tactic " + getBoldText(tacticID) + " is not displayed in pagesource and the tactic is dismissed");
			// break;
		}

	}

	public String getVersion(String tacticID, String promoID, String env, String pos) throws ParseException {

		String adimpr = null;

		Hashtable<String, String> hashtable = getDriverAdImpr(getproxyServer(), "api." + env + "medscape.com", "adimpr",
				"tcid", tacticID, promoID);
		String adimpr_test = hashtable.toString();
		try {
			adimpr = "{" + adimpr_test.substring(adimpr_test.indexOf("\"impr\":[{"), adimpr_test.indexOf("}]") + 2)
					+ "}";
		} catch (Exception e) {
		}
		String version = driverKeyValue(adimpr, pos);
		return version;
	}

	public String driverLinkClick(WebDriver driver, BrowserMobProxyServer server, String SFID, String env, String pos,
			String Version, String size, String call) throws InterruptedException {

		String clickPerformed = "false";
		try {
			driver.findElement(By.className("close-video-violator")).click();
		} catch (Exception e) {
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		/*
		 * WebElement ad101=driver.findElement(By.id("ads-pos-101")); WebElement
		 * ad122=driver.findElement(By.id("ads-pos-122"));
		 * //js.executeScript("window.scrollBy(0,800)"); WebElement
		 * ad910=driver.findElement(By.id("ads-pos-910"));
		 * js.executeScript("window.scrollBy(0,300)"); WebElement
		 * ad141=driver.findElement(By.id("ads-pos-141"));
		 */

		generatePassReport("====== Verifying the AD=========");

		String winHandleBefore = driver.getWindowHandle();

		server.newHar();
		try {

			generatePassReport("*********************************************************");
			switch (pos) {
			case "101":
				WebElement ad101 = driver.findElement(By.id("ads-pos-101"));
				// clickByDriverWebElement(ad101,"Leader Board 101",Version);
				clickPerformed = clickBasedOnSFID(driver, SFID, "101", "LeaderBoard 101", Version);
				break;

			case "122":
				// staticWait(10);
				// js.executeScript("window.scrollBy(0,0)");
				WebElement ad122 = driver.findElement(By.id("ads-pos-122"));
				// scrollToObject(ad122);
				// clickByDriverWebElement(ad122,"Square Boy 122",Version);
				clickPerformed = clickBasedOnSFID(driver, SFID, "122", "Square Boy 122", Version);
				break;
			case "910":
				/*
				 * staticWait(10); WebElement ad910=driver.findElement(By.id("ads-pos-910"));
				 * scrollToObject(ad910); generatePassReportWithScreenShot("910 AD sreenshot");
				 * //clickByDriverWebElement(ad910,"Square Boy 910", Version);
				 */
				clickPerformed = clickBasedOnSFID(driver, SFID, "910", "Square Boy 910", Version);

				break;
			case "141":
				/*
				 * WebElement ad141=driver.findElement(By.id("ads-pos-141"));
				 * scrollToObject(ad141); staticWait(10);
				 * generatePassReportWithScreenShot("141 AD sreenshot");
				 * //clickByDriverWebElement(ad141,"Leader Board 141", Version);
				 */
				clickPerformed = clickBasedOnSFID(driver, SFID, "141", "Square Boy 141", Version);
				break;
			case "520":
				WebElement ad520 = driver.findElement(By.id("ads-pos-520"));
				scrollToObject(ad520);
				staticWait(10);
				generatePassReportWithScreenShot("520 AD sreenshot");
				clickPerformed = clickByDriverWebElement(ad520, "Text AD 520", Version);
				// clickPerformed = clickBasedOnSFID(driver, SFID, "520","Text AD 520",
				// Version);
				break;
			case "1004":
				WebElement ad1004 = driver.findElement(By.id("ads-pos-1004"));
				// clickByDriverWebElement(ad101,"Leader Board 101",Version);

				clickPerformed = clickBasedOnSFID(driver, SFID, "1004", "LeaderBoard 1004", Version);
				break;
			case "1122":
				WebElement ad1122 = driver.findElement(By.id("ads-pos-1122"));
				// clickByDriverWebElement(ad101,"Leader Board 101",Version);
				clickPerformed = clickBasedOnSFIDSize(driver, SFID, "1122", "LeaderBoard 1122", Version, size);
				break;
			case "1420":
				WebElement ad1420 = driver.findElement(By.id("ads-pos-1420"));
				// clickByDriverWebElement(ad101,"Leader Board 101",Version);
				clickPerformed = clickByDriverWebElement(ad1420, "Text AD 1420", Version);
				// clickPerformed = clickBasedOnSFID(driver, SFID, "1420" ,"Text AD 1420",
				// Version);
				break;
			case "1520":
				WebElement ad1520 = driver.findElement(By.id("ads-pos-1520"));
				// clickByDriverWebElement(ad101,"Leader Board 101",Version);
				clickPerformed = clickByDriverWebElement(ad1520, "Text AD 1520", Version);
				// clickPerformed = clickBasedOnSFID(driver, SFID, "1520" ,"Text AD 1520",
				// Version);
				break;
			case "420":
				boolean adpos = true;

				try

				{
					/*
					 * driver.findElement(By.xpath("//div[@id='next-section']/a")).click();
					 * staticWait(10);
					 */
					adpos = driver.findElement(By.id("ads-pos-420")).isDisplayed();
					WebElement ad420 = driver.findElement(By.id("ads-pos-420"));
					scrollToObject(ad420);
					staticWait(10);
					generatePassReportWithScreenShot("420 AD sreenshot");
					clickPerformed = clickByDriverWebElement(ad420, "Text AD 420", Version);
					// clickPerformed = clickBasedOnSFID(driver, SFID, "420","Text AD 420",
					// Version);

				} catch (NoSuchElementException e) {
					WebElement ad420 = driver.findElement(By.id("ads-pos-420_2_1"));
					scrollToObject(ad420);
					staticWait(10);
					generatePassReportWithScreenShot("420 AD sreenshot");
					clickPerformed = clickByDriverWebElement(ad420, "Text AD 420", Version);
					// clickPerformed = clickBasedOnSFID(driver, SFID, "420","Text AD 420",
					// Version);
				}
			}
			if (clickPerformed == "true") {
				// Hashtable<String, String> positionTrack =
				// getStdParmValues(server,"www.medscape.com");
				Hashtable<String, String> positionTrack = getStdParmValues(server, call);

				generateReport(positionTrack.size() > 0,
						getBoldText("Position Tracking call") + " : " + call + " - tracked <br>"
								+ getBoldText(positionTrack.toString()),
						getBoldText("Position Trcaking call") + ": " + call + "- not tracked <br>"
								+ getBoldText(positionTrack.toString()));

				Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(), "ssl.o.webmd.com/b/ss/webmd");

				filePathsWebVadidation(hashtable);

				Set<String> windows = driver.getWindowHandles();
				Iterator<String> iterator = windows.iterator();
				String lastWindow = "";

				while (iterator.hasNext()) {
					lastWindow = iterator.next();
				}
				driver.switchTo().window(lastWindow);

				Thread.sleep(1000);

				generatePassReport("No of windows : " + driver.getWindowHandles().size());

				if (driver.getWindowHandles().size() > 1) {
					if (!winHandleBefore.equalsIgnoreCase(lastWindow)) {
						generatePassReportWithScreenShot("URl Opened on AD click through");
						Thread.sleep(1000);
						driver.close();
					}
					driver.switchTo().window(winHandleBefore);
				} else {
					Thread.sleep(1000);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Logs.log(e.getMessage());
		}
		return clickPerformed;
	}

	public Hashtable<String, String> getDriverAdImpr(BrowserMobProxyServer server, String domaine, String activityName,
			String tacticName, String tackticID, String activityID) {
		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;
		int noOFTimes = 0;
		String trackedCallsWithGivenDomine = "";
		while (!valueTracked) {
			try {
				if (noOFTimes == 3) {
					generateInfoReport(
							"Tracked URls with " + getBoldText(domaine) + "<br>" + trackedCallsWithGivenDomine);
					return stdValues;
				}
				trackedCallsWithGivenDomine = "";
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();
				// System.out.println(entries.size());

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(domaine)) {
						try {
							List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();
							trackedCallsWithGivenDomine = trackedCallsWithGivenDomine
									+ entries.get(i).getRequest().getQueryString() + "<br>";

							stdValues = new Hashtable<>();

							for (HarNameValuePair harNameValuePair : harNameValuePairs) {

								stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());

							}
							String event = stdValues.get("event");
							if (event.contains("\"activityName\":\"" + activityName + "\"")
									&& event.contains("\"" + tacticName + "\":\"" + tackticID + "\"")
									&& event.contains("\"activityId\":\"" + activityID + "\"")) {
								valueTracked = true;
								return stdValues;
							}
						} catch (Exception e) {

						}
					}

				}

			} catch (Exception e) {
			}
			/*
			 * generateInfoReport( "Tracked URls with " + getBoldText(domaine) + "<br>" +
			 * trackedCallsWithGivenDomine);
			 */
			return stdValues;

		}
		return stdValues;

	}

	private String driverKeyValue(String adimpr, String position) throws ParseException {
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(adimpr);
		String Version = null;

		JSONArray lang = (JSONArray) jsonObject.get("impr");
		// take the elements of the json array
		for (int i = 0; i < 1; i++) {

			// System.out.println("The " + i + " element of the array: "+lang.get(i));
			Iterator<Object> i1 = lang.iterator();
			// take each value from the json array separately
			while (i1.hasNext()) {
				JSONObject innerObj = (JSONObject) i1.next();
				// generateInfoReport("SendEvent clicked for "+ ++counter +" time");
				Version = (String) innerObj.get("ver");
				// Branded= (String) innerObj.get("branded");
				String pos = String.valueOf(innerObj.get("pos")).trim();
				// System.out.println(pos);
				if (position.equals(pos)) {
					generateInfoReport(
							"Tactic Id   " + innerObj.get("tcid") + "<br> Promo ID   " + innerObj.get("activityId")
									+ getBoldText("<br>Version  ") + innerObj.get("ver") + "<br>Positon  "
									+ innerObj.get("pos") + getBoldText("<br>Branded  ") + innerObj.get("branded")
									+ getBoldText("<br>Message Category  ") + innerObj.get("msgCategory"));
					break;
				}
				/*
				 * if (position==pos) { break; }
				 */
			}
		}
		return Version;
	}

	public String clickBasedOnSFID(WebDriver driver, String sfid, String pos, String locatorName, String version) {
		driver.switchTo().defaultContent();
		String flag = "false";
		WebElement xpathpos;
		String exception = "";
		try {
			WebElement adpos1 = driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']"));
			scrollToObject(adpos1);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']//iframe")));
			// System.out.println(driver.findElement(By.tagName("a")).getAttribute("href"));
			if (pos == "101" || pos == "122" || pos == "910" || pos == "141" || pos == "1004") {
				xpathpos = driver.findElement(
						By.xpath("//a[contains(@href,'" + pos + "')]//img[contains(@src,'" + sfid + "')]"));
			} else if (pos == "101" || pos == "122" || pos == "910" || pos == "141" || pos == "1004") {
				xpathpos = driver.findElement(By.xpath("//a[contains(@href,'" + sfid + "')]"));
			} else {
				xpathpos = driver.findElement(By.xpath("//a[contains(@href,'" + pos + "')]"));
			}

			if (xpathpos.isDisplayed()) {
				generateBoldInfo("Driver AD with SFID " + sfid + " found");

				generatePassReport("====== Clicking on the AD=========");
				List<WebElement> allLinks = driver.findElements(By.xpath("//a"));
				try {
					for (int i = 0; i < allLinks.size(); i++) {

						driver.switchTo().defaultContent();
						driver.switchTo()
								.frame(driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']//iframe")));

						if (allLinks.get(i).isEnabled()) {

							// WebElement element = driver.findElement(By.tagName("a"));
							// allLinks.get(i).click();
							JavascriptExecutor executor = (JavascriptExecutor) driver;
							executor.executeScript("arguments[0].click();", allLinks.get(i));

							String Link_Label = allLinks.get(i).getText();
							if ((Link_Label != null) && (!Link_Label.equals(""))) {
								generatePassReport(Link_Label);
							} else {
								System.out.println("Link on the AD is Image.");
							}
							waitForLoad(driver);
							linkClick(allLinks.get(i));
						}
					}
				} catch (Exception e) {
					generateBoldInfo("Links in the AD are not cliked");
				}
				// System.out.println(allLinks);
				driver.switchTo().defaultContent();
				WebElement adpos = driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']"));
				scrollToObject(adpos);
				generatePassReportWithScreenShot(pos + " AD sreenshot");
				clickByDriverWebElement(adpos, "LeaderBoard " + pos, version);
				waitForLoad(driver);

			}

			// driver.findElement(By.xpath("//a[contains(@href,'"+sfid+"') and
			// contains(@href,'ad') and contains(@href,'"+pos+"') ]//img")).click();
			flag = "true";
		} catch (Exception e) {
			// e.printStackTrace();
		} finally {
			// generateBoldInfo("Driver AD with SFID "+sfid+" not found");
			generateReport(flag.equals("true"),
					"Click performed on " + getBoldText(locatorName) + " with Version " + getBoldText(version),
					"Click not performed on " + getBoldText(locatorName) + " with Version  " + getBoldText(version)
							+ exception);
		}
		return flag;
	}

	public String clickByDriverWebElement(WebElement element, String locatorName, String Version) {
		String flag = "false";
		String exception = "";
		try {

			element.click();
			Thread.sleep(1000);
			flag = "true";
		} catch (Exception e) {
			exception = PrivateMethods.getException(e);
			e.printStackTrace();
		} /*
			 * finally { generateReport(flag, "Click performed on " +
			 * getBoldText(locatorName) + " with Version " +getBoldText(Version),
			 * "Click not performed on " + getBoldText(locatorName) + " with Version  "
			 * +getBoldText(Version) + exception); }
			 */
		return flag;
	}

	public String clickBasedOnSFIDSize(WebDriver driver, String sfid, String pos, String locatorName, String version,
			String size) {
		driver.switchTo().defaultContent();
		String flag = "false";
		String exception = "";
		try {
			WebElement adpos1 = driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']"));
			scrollToObject(adpos1);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']//iframe")));
			// System.out.println(driver.findElement(By.tagName("a")).getAttribute("href"));
			WebElement xpathpos = driver
					.findElement(By.xpath("//a[contains(@href,'" + pos + "')]//img[contains(@src,'" + sfid + "')]"));
			if (xpathpos.isDisplayed()) {
				WebElement xpathsize = driver.findElement(
						By.xpath("//a[contains(@href,'" + pos + "')]//img[contains(@src,'" + size + "')]"));
				if (xpathsize.isDisplayed()) {
					generateBoldInfo("Driver AD with SFID " + sfid + " and size " + size + " found");
					List<WebElement> allLinks = driver.findElements(By.xpath("//a"));
					try {
						for (int i = 0; i < allLinks.size(); i++) {

							System.out.println(allLinks.get(i).getText());
							driver.switchTo().defaultContent();
							driver.switchTo()
									.frame(driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']//iframe")));

							if (allLinks.get(i).isEnabled()) {

								// WebElement element = driver.findElement(By.tagName("a"));
								// allLinks.get(i).click();
								JavascriptExecutor executor = (JavascriptExecutor) driver;
								executor.executeScript("arguments[0].click();", allLinks.get(i));
								generatePassReport(allLinks.get(i).getText());
								linkClick(allLinks.get(i));
							}
						}
					} catch (Exception e) {
						generateBoldInfo("Links in the AD are not cliked");
					}
					// System.out.println(allLinks);
					driver.switchTo().defaultContent();
					WebElement adpos = driver.findElement(By.xpath("//div[@id='ads-pos-" + pos + "']"));
					scrollToObject(adpos);
					generatePassReportWithScreenShot(pos + " AD sreenshot");
					clickByDriverWebElement(adpos, "LeaderBoard " + pos, version);

				}
			}

			// driver.findElement(By.xpath("//a[contains(@href,'"+sfid+"') and
			// contains(@href,'ad') and contains(@href,'"+pos+"') ]//img")).click();
			flag = "true";
		} catch (Exception e) {
			// e.printStackTrace();
		} finally {
			// generateBoldInfo("Driver AD with SFID "+sfid+" not found");
			generateReport(flag.equals("true"),
					"Click performed on " + getBoldText(locatorName) + " with Version " + getBoldText(version),
					"Click not performed on " + getBoldText(locatorName) + " with Version  " + getBoldText(version)
							+ exception);
		}
		return flag;
	}

	public void waitForLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(pageLoadCondition);
	}

	public void linkClick(WebElement webElement) throws InterruptedException {
		String winHandleBefore = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> iterator = windows.iterator();
		String lastWindow = "";

		while (iterator.hasNext()) {
			lastWindow = iterator.next();
		}
		driver.switchTo().window(lastWindow);

		Thread.sleep(1000);

		generatePassReport("No of windows : " + driver.getWindowHandles().size());
		Thread.sleep(10000);
		generatePassReportWithScreenShot("URL opened on Link Click through");

		if (driver.getWindowHandles().size() > 1) {
			if (!winHandleBefore.equalsIgnoreCase(lastWindow)) {
				Thread.sleep(10000);
				driver.close();
			}
			driver.switchTo().window(winHandleBefore);
		}
	}

	public WebDriver EmailerLogin() {

		try {
			// System.setProperty("webdriver.chrome.driver",
			// "D:\\Eclipse_work\\chromedriver.exe");
			// driver = new ChromeDriver();
			// driver.manage().window().maximize();
			// WebDriver driver = new ChromeDriver();
			// driver.get("https://login.medscape.com/login/sso/getlogin?ac=401");
			// driver.get("https://"+prop.getProperty("tacticUserName")+":"+prop.getProperty("tacticUserPwd")+"@sharepoint.webmd.net/Professional%20Portals/PromotionalMarketing/Lists/Special%20Mailers/DailyMailers.aspx");
			driver.get(
					"https://rsarapu:Newpassword@12@sharepoint.webmd.net/Professional%20Portals/PromotionalMarketing/Lists/Special%20Mailers/DailyMailers.aspx");
			// driver.navigate().to("https://rsarapu:Newpassword@12@sharepoint.webmd.net/Professional%20Portals/PromotionalMarketing/Lists/Special%20Mailers/DailyMailers.aspx");
			// Reporter.log("Login started with valid inputs");

			// return driver;

		} catch (Exception e) {

			e.printStackTrace();
		}
		return driver;

	}

	public void EmailerLaunching() {
		System.setProperty("webdriver.chrome.driver", "D:\\Eclipse_work\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		// System.setProperty("webdriver.chrome.driver",
		// "D:\\Eclipse_work\\chromedriver.exe");

		// driver.get("https://www.google.com/");
	}

	public Map PromoRecords(WebDriver driver, String Date, String Promo) throws InterruptedException {
		// driver.findElement(By.xpath("(//*[@id='group0']/td/a)[1]")).click();
		Map<String, String> tableRecords = null;
		try {
			System.out.println(driver.getTitle());
			Thread.sleep(15000);
			getScreenshot();
			tableRecords = new HashMap<String, String>();
			driver.findElement(By.xpath("(//*//td[contains(text(),'" + Date + "')]//a)[1]")).click();
			ArrayList<String> Records = new ArrayList<String>();
			ArrayList<String> Recordsheader = new ArrayList<String>();
			ArrayList<WebElement> elements1 = (ArrayList<WebElement>) driver
					.findElements(By.xpath("//tr/td[2]/nobr[text()='" + Date + "']/../../td[11]"));
			ArrayList<WebElement> headers = (ArrayList<WebElement>) driver
					.findElements(By.xpath("//*[@class='ms-listviewtable']//tbody//tr//th//div//table"));
			for (int n = 0; n < headers.size(); n++) {

				Recordsheader.add(headers.get(n).getText());

			}

			for (int i = 1; i <= elements1.size(); i++) {
				ArrayList<WebElement> elements = (ArrayList<WebElement>) driver
						.findElements(By.xpath("//tr[" + i + "]/td[2]/nobr[text()='" + Date + "']/../../td"));

				for (int j = 1; j < elements.size(); j++) {

					if (Promo.equalsIgnoreCase(driver
							.findElement(By.xpath("//tr[" + i + "]/td[2]/nobr[text()='" + Date + "']/../../td[11]"))
							.getText())) {

						Records.add(elements.get(j).getText());
					}

				}

			}

			for (int k = 0; k < Records.size(); k++) {
				// System.out.println(Records.get(k));

				// generateBoldInfo(Records.get(k));
			}
			if (!Records.isEmpty()) {
				for (int m = 0; m < headers.size(); m++) {

					tableRecords.put(Recordsheader.get(m), Records.get(m));
				}
			} else {
				generateFailReport(getBoldText("Promo Not Found"));

			}
			Records.clear();
			Recordsheader.clear();
			return tableRecords;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// generateBoldInfo("********************************************************************************");
		return tableRecords;

	}

	public void verifyEmailerSF(Map tableRecords, String SFNumber) {
		try {
			if (!tableRecords.get("SF").equals(null)) {
				if (tableRecords.get("SF").equals(SFNumber)) {

					generatePassReport(getBoldText("SF Number matched:") + tableRecords.get("SF"));
				} else {
					generateFailReport(getBoldText("SF Number is not matched:") + "<br> Expcted Value:" + SFNumber
							+ "<br> Actual Value:" + tableRecords.get("SF"));
				}
			} else {
				generateFailReport(getBoldText("Null value is displayed for SF"));

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void verifyEmailerclient(Map tableRecords, String Client) {
		try {
			if (!tableRecords.get("Client").equals(null)) {
				if (tableRecords.get("Client").equals(Client)) {

					generatePassReport(getBoldText("Client matched:") + tableRecords.get("Client"));
				} else {
					generateFailReport(getBoldText("Client is not matched:") + tableRecords.get("Client"));
				}
			} else {
				generateFailReport(getBoldText("Null value is displayed for Client") + "<br> Expcted Value:" + Client
						+ "<br> Actual Value:" + tableRecords.get("Client"));

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void verifyEmailerBrand(Map tableRecords, String Brand) {
		try {
			if (!tableRecords.get("Brand").equals(null)) {
				if (tableRecords.get("Brand").equals(Brand)) {

					generatePassReport(getBoldText("Brand matched:") + tableRecords.get("Brand"));
				} else {
					generateFailReport(getBoldText("Brand is not matched:") + "<br> Expcted Value:" + Brand
							+ "<br> Actual Value:" + tableRecords.get("Brand"));
				}
			} else {
				generateFailReport(getBoldText("Null value is displayed for Brand"));

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void verifyEmailerEIStatus(Map tableRecords, String EIStatus) {
		try {
			if (!tableRecords.get("EI Status").equals(null)) {
				if (tableRecords.get("EI Status").equals(EIStatus)) {

					generatePassReport(getBoldText("EI Status matched:") + tableRecords.get("EI Status"));
				} else {
					generateFailReport(getBoldText("EI Status is not matched:") + "<br> Expcted Value:" + EIStatus
							+ "<br> Actual Value:" + tableRecords.get("EI Status"));
				}
			} else {
				generateFailReport(getBoldText("Null value is displayed for EI Status:"));

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void verifyEmailerQAurl(Map tableRecords, String uname, String pwd) {
		try {
			if (!tableRecords.get("URL for QA").equals(null)) {
				String url = (String) tableRecords.get("URL for QA");
				generateInfoReport("******************QA URL Verification Started**************************");
				login(uname, pwd);
				driver.get(url);
				Thread.sleep(2000);

				generateInfoReport("Title of the Program :   " + getBoldText(driver.getTitle()));

				generateInfoReport("Current URL of the Emailer program :<br>" + getBoldText(driver.getCurrentUrl()));
				generatePassReportWithScreenShot("Refer Program screenshot");

			} else {
				generateFailReport(getBoldText("Null value is displayed for URL.We are unable to Open"));

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void verifyProofLinks(String url) {
		try {
			generateInfoReport("******************Emailer Proof Verification Started**************************");
			driver.get(url);
			generatePassReportWithScreenShot("Please refer Email Proof");
			generateBoldInfo("below are the EMAIL ATTRIBUTES:");
			for (int k = 1; k <= 5; k++) {

				generateInfoReport(driver.findElement(By.xpath("/html/body/div/p[" + k + "]")).getText());
				// System.out.println(driver.findElement(By.xpath("/html/body/div/p["+k+"]")).getText());

			}
			generateInfoReport("******************clicking on Header and CTA**************************");
			// ArrayList<WebElement> Links=(ArrayList<WebElement>)
			// driver.findElements(By.xpath("//a"));
			for (int i = 1; i <= 2; i++) {
				WebElement element = driver.findElement(By.xpath("(//table/tbody/tr/td/a)[" + i + "]"));
				clickByWebElement(element, element.getText().toString());
				generateInfoReport(driver.getTitle());
				generateInfoReport(driver.getCurrentUrl());
				generatePassReportWithScreenShot("Refer screenshot");
				driver.navigate().back();

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Infosite Releated calls

	public void infositeapicalls(String tacticID, String promoID, String env) throws Exception {
		String s = "\"activityName\":\"Infosite\"";

		// String act="\"activityName\":\"infosite\"";
		// infositeApiCalls(getproxyServer(), "api." + env + "medscape.com","infosite",
		// tacticID, promoID);
		infositeApiCalls(getproxyServer(), "api." + env + "medscape.com", "participation", tacticID, promoID);
		startNewHar();
		getDriver().navigate().refresh();
		staticWait(5);
		infositeApiCalls(getproxyServer(), "api." + env + "medscape.com", "requestCSD", tacticID, promoID);
		// for (int i = 0; i < 3; i++) {
		// getDriver().navigate().refresh();
		// getDriver().navigate().refresh();
		// }
		// getDriver().navigate().refresh();
		// infositeApiCalls(getproxyServer(), "api." + env + "medscape.com",s, tacticID,
		// promoID);

	}

	public void infositedropoff(String tacticID, String promoID, String env) throws Exception {
		getDriver().navigate().refresh();
		infositeApiCalls(getproxyServer(), "api." + env + "medscape.com", "drop-off", tacticID, promoID);
	}

	public boolean infositeApiCalls(BrowserMobProxyServer server, String domaine, String activityName, String tackticID,
			String activityID) throws Exception {
		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;

		int noOFTimes = 0;
		String trackedCallsWithGivenDomine = "";

		trackedCallsWithGivenDomine = "";
		Thread.sleep(2000);
		noOFTimes++;
		// Har har = server.getHar();
		Har har = server.newHar();
		// server.newHar();

		List<HarEntry> entries = har.getLog().getEntries();

		for (int i = 0; i < entries.size(); i++) {

			String requestUrl = entries.get(i).getRequest().getUrl();
			Logs.log(requestUrl);
			if (requestUrl.contains(domaine)) {
				try {

					List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();
					trackedCallsWithGivenDomine = trackedCallsWithGivenDomine
							+ entries.get(i).getRequest().getQueryString() + "<br>";

					// System.out.println(entries.get(i).getRequest().getQueryString());
					stdValues = new Hashtable<>();

					// if(!harNameValuePairs.isEmpty()){
					for (HarNameValuePair harNameValuePair : harNameValuePairs) {

						stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
					}
					if (stdValues.containsKey("event")) {

						if (stdValues.get("event").contains(activityName)) {

							String impressionCall = stdValues.get("event");
							valueTracked = true;
							infositeapicallsparse(tackticID, activityID, activityName, impressionCall);

						}

					}
					// }else{

					// generateFailReport("Impression Value Not Tracked");
					// }

				} catch (Exception e) {
				}

			}

		}
		if (!valueTracked) {
			generateFailReport("Unable to Track  " + activityName + "  call");
			return valueTracked;
		}
		return valueTracked;

	}

	public boolean infositeapicallsparse(String tackticID, String activityID, String ImpressionName, String apicall)
			throws Exception {

		boolean requestcsdFlag = false;
		boolean partcipationFlag = false;
		boolean infositeFlag = false;

		JSONParser jsonParser = new JSONParser();

		JSONObject jsonObject = (JSONObject) jsonParser.parse(apicall);
		// String appName=(String) jsonObject.get("appname");

		String activityName = (String) jsonObject.get("activityName");
		if (ImpressionName.equalsIgnoreCase("participation")) {
			String tacticId = (String) jsonObject.get("tacticId");
			String promo = (String) jsonObject.get("activityId");
			String appName = (String) jsonObject.get("appname");
			// generateInfoReport(getBoldText("Tactic ID: ")+tacticId+
			// getBoldText("<br>Promo ID: ")+promo);
			generateReport(
					tacticId.equals(tackticID) && promo.equals(activityID) && appName.equalsIgnoreCase("infosite"),
					getBoldText("Participation Tracked  <br>Tactic ID:   ") + tacticId + getBoldText("<br>Promo ID:   ")
							+ promo + "<br>" + apicall,
					getBoldText("Invalid Participation Tracked <br>Tactic ID:   ") + tacticId
							+ getBoldText("<br>Promo ID:   ") + promo + "<br>" + apicall);
			partcipationFlag = true;
			return partcipationFlag;

		} else if (ImpressionName.equalsIgnoreCase("requestCSD")) {
			String tacticId = (String) jsonObject.get("tacticId");
			String promo = (String) jsonObject.get("activityId");
			String appName = (String) jsonObject.get("appname");
			// generateInfoReport(getBoldText("Tactic ID: ")+tacticId+
			// getBoldText("<br>Promo ID: ")+promo);
			generateReport(
					tacticId.equals(tackticID) && promo.equals(activityID) && appName.equalsIgnoreCase("infosite"),
					getBoldText("requestCSD Tracked  <br>Tactic ID:   ") + tacticId + getBoldText("<br>Promo ID:   ")
							+ promo + "<br>" + apicall,
					getBoldText("Invalid requestCSD Tracked <br>Tactic ID:   ") + tacticId
							+ getBoldText("<br>Promo ID:   ") + promo + "<br>" + apicall);
			requestcsdFlag = true;
			return requestcsdFlag;
		} else if (ImpressionName.contains("infosite")) {
			getDriver().navigate().refresh();
			String tacticId = (String) jsonObject.get("tacticId");
			String promo = (String) jsonObject.get("activityId");
			String appName = (String) jsonObject.get("appname");
			// generateInfoReport(getBoldText("Tactic ID: ")+tacticId+
			// getBoldText("<br>Promo ID: ")+promo);
			generateReport(
					tacticId.equals(tackticID) && promo.equals(activityID) && appName.equalsIgnoreCase("infosite"),
					getBoldText("infosite api Tracked  <br>Tactic ID:   ") + tacticId + getBoldText("<br>Promo ID:   ")
							+ promo + "<br>" + apicall,
					getBoldText("Invalid infosite api Tracked <br>Tactic ID:   ") + tacticId
							+ getBoldText("<br>Promo ID:   ") + promo + "<br>" + apicall);
			infositeFlag = true;
			return infositeFlag;
		} else if (ImpressionName.contains("drop-off")) {
			String tacticId = (String) jsonObject.get("tacticId");
			String promo = (String) jsonObject.get("activityId");
			String appName = (String) jsonObject.get("appname");
			generateReport(
					tacticId.equals(tackticID) && promo.equals(activityID) && appName.equalsIgnoreCase("infosite"),
					getBoldText("drop-off api Tracked  <br>Tactic ID:   ") + tacticId + getBoldText("<br>Promo ID:   ")
							+ promo + "<br>" + apicall,
					getBoldText("Invalid drop-off api Tracked <br>Tactic ID:   ") + tacticId
							+ getBoldText("<br>Promo ID:   ") + promo + "<br>" + apicall);
		}
		return false;

	}

	public void VerifyInfositeLoadcall(String SFID, String environment) {
		staticWait(5);
		/*
		 * Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
		 * "www."+environment+"medscape.com/public/vptrack.wxml");
		 * generateReport(hashtable.size() > 0&&hashtable.toString().contains(SFID),
		 * getBoldText("ON LOAD Call:www."
		 * +environment+"medscape.com/public/vptrack.wxml call  tracked")+" <br>" +
		 * hashtable.toString(), getBoldText("ON LOAD Call:www."
		 * +environment+"medscape.com/public/vptrack.wxml weblog call not tracked"
		 * )+" <br>" + hashtable.toString());
		 */
		// startNewHar();
		// getDriver().navigate().refresh();
		generateInfoReport("*******OnLoad Calls*******");
		verifySslCalls("www." + environment + "medscape.com/public/vptrack");
	}

	public void verifyInfositearticleRedirectionLanding(String SFID, String env) {
		Hashtable<String, String> hashtable = getMatchedParamURL(getproxyServer(),
				"www." + env + "medscape.com/infosites/" + SFID + "/articles", SFID);

		generateReport(hashtable.size() > 0, getBoldText("Destination") + "  tracked <br>" + hashtable.toString(),
				getBoldText("Destination") + " not tracked <br>" + hashtable.toString());

	}

	public void VerifyinfositeArticlenavigation(WebDriver driver, BrowserMobProxyServer server, String SFID, String env,
			String ProgramURL) throws InterruptedException {
		generatePassReport(
				"================================================ Clicking on Articles ================================================");
		String winHandleBefore = driver.getWindowHandle();
		staticWait(3);
		try {
			if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
				driver.findElement(InfositeObjectRepo.Iconsent).click();
			}
			if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
				driver.findElement(InfositeObjectRepo.accept).click();

			}

		} catch (Exception e) {

		}
		List<WebElement> allLinks = new ArrayList<>();

		List<WebElement> intialallLinks = driver.findElements(InfositeObjectRepo.allNavLinks);
		for (int l = 0; l < intialallLinks.size(); l++) {
			if (intialallLinks.get(l).getAttribute("href").contains("mailto")
					|| intialallLinks.get(l).getAttribute("href").contains("tel:")) {

			} else if (intialallLinks.get(l).isDisplayed()) {
				allLinks.add(intialallLinks.get(l));
			}
		}
		List<WebElement> allLinks_1 = new ArrayList<>();
		List<WebElement> intialallLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
		for (int k = 0; k < intialallLinks_1.size(); k++) {
			if (intialallLinks_1.get(k).getAttribute("href").contains("mailto")
					|| intialallLinks_1.get(k).getAttribute("href").contains("tel:")) {

			} else if (intialallLinks_1.get(k).isDisplayed()) {
				allLinks_1.add(intialallLinks_1.get(k));
			}
		}
		// *[@id='navigation-module']//a
		// List<WebElement> homepageArticles =
		// driver.findElements(By.xpath("//section[@class!='nav-buttons-container']//*[@data-module='RouterLink']"));

		List<WebElement> homepageArticles = driver.findElements(InfositeObjectRepo.HomepageLinks);
		if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
			if (homepageArticles.contains(driver.findElement(InfositeObjectRepo.registartionform))) {
				homepageArticles.remove(driver.findElement(InfositeObjectRepo.registartionform));// removing
																									// registartion form
																									// if it is present
																									// in home Page
			}
		}
		List<WebElement> homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);
		List<WebElement> navAndhomeLinks = new ArrayList<>();
		if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
			homepageArticlesnav.remove(driver.findElement(InfositeObjectRepo.registartionform));
		}
		for (int p = 0; p < homepageArticlesnav.size(); p++) {
			if (homepageArticlesnav.get(p).isDisplayed()) {
				navAndhomeLinks.add(homepageArticlesnav.get(p));
			}
		}

		if (homepageArticles.size() == 0 && allLinks.size() == 0 && homepageArticlesnav.size() == 0
				&& allLinks_1.size() == 0) {
			generateInfoReport("No Articles present in Infosite");
		}
		if (allLinks.size() > 0) {
			generatePassReport("No of Navigation link Articles available in Infosite are:  " + allLinks.size());
			String links = "";
			links = getAllLinksAndTitles(allLinks, links);
			if (allLinks.size() > 0) {
				generatePassReport("All Article Links and URL's: <br>" + links);
			}
		} else if (allLinks_1.size() > 0) {
			generatePassReport("No of Navigation link Articles available in Infosite are:  " + allLinks.size());
			String links_1 = "";
			links_1 = getAllLinksAndTitles(allLinks_1, links_1);
			if (allLinks_1.size() > 0) {
				generatePassReport("All Article Links and URL's: <br>" + links_1);
			}
		} else if (homepageArticlesnav.size() > 0) {

			generatePassReport("No of Navigation link Articles available in Infosite:  " + homepageArticlesnav.size());
			String hnlinks = "";
			hnlinks = getAllLinksAndTitles(homepageArticlesnav, hnlinks);
			if (homepageArticlesnav.size() > 0) {
				generatePassReport("All Article Links and URL's : <br>  " + hnlinks);
			}
		} else if (homepageArticles.size() > 0) {
			generatePassReport("No of Navigation link Articles available in Infosite:  " + homepageArticles.size());
			String hlinks = "";
			hlinks = getAllLinksAndTitles(homepageArticles, hlinks);
			if (homepageArticles.size() > 0) {
				generatePassReport("All Article Links and URL's :<br>" + hlinks);
			}
		}
		if (allLinks.size() > 0) {
			for (int i = 0; i < allLinks.size(); i++) {
				try {

					if (allLinks.get(i).isDisplayed() && !allLinks.get(i).getAttribute("href").contains("mailto")
							&& allLinks.get(i).getAttribute("href").contains("article")) {
						server.newHar();

						generatePassReport(
								"************************************************************************************************");
						clickByWebElement(allLinks.get(i),
								getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));
						generatePassReportWithScreenShot("Below is the Article Screenshot");
						staticWait(6);

						// getDriver()
						generateReport(getDriver().getTitle().equalsIgnoreCase("Information from Industry"),
								"Window Title Matched:" + getBoldText(getDriver().getTitle()),
								"Window Title Not Matched:" + getBoldText(getDriver().getTitle()));
						validateImages(getproxyServer(), env, SFID);
						// allLinks=driver.findElements(By.xpath("//*[@id='navigation-module']//a"));
						allLinks = driver.findElements(InfositeObjectRepo.allNavLinks);

						// clickByWebElement(allLinks.get(i),
						// getTextForReport(allLinks, i) + " : " +
						// allLinks.get(i).getAttribute("href"));
						// validate tracker marker call
						String DestinationURL = getStdParmValuesForQueryString(server,
								"www." + env + "medscape.com/infosites/" + SFID + "/articles");

						Hashtable<String, String> trackermarker = getStdParmValues(server,
								"www." + env + "medscape.com/infosites/" + SFID + "/articles");

						generateReport(trackermarker.size() > 0 && DestinationURL != null,
								"Destination URL: " + getBoldText(DestinationURL),
								getBoldText(trackermarker.toString()));

						/*
						 * verifyInfositearticleRedirectionLanding(SFID, env); Hashtable<String, String>
						 * hashtable = getStdParmValues(getproxyServer(), "ssl.o.webmd.com/b/ss/webmd");
						 * 
						 * generatePassReport(getBoldText("Attributes Tracked in Ominiture ssl.o call:")
						 * +"<br>"+getBoldText("g:") + hashtable.get("g") +
						 * "<br>"+getBoldText("mmodule :") +
						 * hashtable.get("mmodule")+"<br>"+getBoldText("mpage:") +
						 * hashtable.get("mpage") + "<br>"+getBoldText("lnktxt :") +
						 * hashtable.get("lnktxt") + "<br>"+getBoldText("cstm :") +
						 * hashtable.get("cstm"));
						 */
						Hashtable<String, String> hashtablefordestinationurlweblog = getMatchedParamURLInfositeNot(
								getproxyServer(), env, "www." + env + "medscape.com/public/vptrack.wxml", SFID,
								"nav-link");
						//
						generateReport(hashtablefordestinationurlweblog.size() > 0,
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call  tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString(),
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString());
						Hashtable<String, String> hashtable = getMatchedParamURLInfosite(getproxyServer(), env,
								"ssl.o.webmd.com/b/ss/webmd", SFID, "mmodule");
						generateReport(hashtable.size() > 0, getBoldText("Attributes Tracked in 1st Ominiture  call:")
								+ "<br>" + getBoldText("g:") + hashtable.get("g") + "<br>" + getBoldText("mmodule :")
								+ hashtable.get("mmodule") + "<br>" + getBoldText("mpage:") + hashtable.get("mpage")
								+ "<br>" + getBoldText("lnktxt :") + hashtable.get("lnktxt") + "<br>"
								+ getBoldText("cstm :") + hashtable.get("cstm"),
								"Unable to Track ssl call with mmodule,mlink,mpage etc");
						verifyInfositenavLinkredirection(SFID, env);
						Hashtable<String, String> hashtablefordestinationurl = getMatchedParamURLInfosite(
								getproxyServer(), env, "ssl.o.webmd.com/b/ss/webmd", SFID, "c7");
						generateReport(hashtablefordestinationurl.size() > 0,
								getBoldText("Attributes Tracked in 2nd  Ominiture call:") + "<br>" + getBoldText("g:")
										+ hashtablefordestinationurl.get("g") + "<br>" + getBoldText("pageName :")
										+ hashtablefordestinationurl.get("pageName"),
								"Unable to Track 2nd  ssl call");

						// VerifyInfositeLoadcall(SFID, env);

					}

				} catch (Exception e) {
					e.printStackTrace();
					Logs.log(e.getMessage());
				}
			}
		} else if (allLinks_1.size() > 0) {
			for (int i = 0; i < allLinks_1.size(); i++) {
				try {

					if (allLinks_1.get(i).isDisplayed() && !allLinks_1.get(i).getAttribute("href").contains("mailto")
							&& allLinks_1.get(i).getAttribute("href").contains("article")) {
						server.newHar();

						generatePassReport(
								"************************************************************************************************");
						clickByWebElement(allLinks_1.get(i),
								getTextForReport(allLinks_1, i) + " : " + allLinks_1.get(i).getAttribute("href"));
						generatePassReportWithScreenShot("Below is the Article Screenshot");
						staticWait(6);

						// getDriver()
						generateReport(getDriver().getTitle().equalsIgnoreCase("Information from Industry"),
								"Window Title Matched:" + getBoldText(getDriver().getTitle()),
								"Window Title Not Matched:" + getBoldText(getDriver().getTitle()));
						validateImages(getproxyServer(), env, SFID);
						// allLinks=driver.findElements(By.xpath("//*[@id='navigation-module']//a"));
						allLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);

						// clickByWebElement(allLinks.get(i),
						// getTextForReport(allLinks, i) + " : " +
						// allLinks.get(i).getAttribute("href"));
						// validate tracker marker call
						String DestinationURL = getStdParmValuesForQueryString(server,
								"www." + env + "medscape.com/infosites/" + SFID + "/articles");

						Hashtable<String, String> trackermarker = getStdParmValues(server,
								"www." + env + "medscape.com/infosites/" + SFID + "/articles");

						generateReport(trackermarker.size() > 0 && DestinationURL != null,
								"Destination URL: " + getBoldText(DestinationURL),
								getBoldText(trackermarker.toString()));

						/*
						 * verifyInfositearticleRedirectionLanding(SFID, env); Hashtable<String, String>
						 * hashtable = getStdParmValues(getproxyServer(), "ssl.o.webmd.com/b/ss/webmd");
						 * 
						 * generatePassReport(getBoldText("Attributes Tracked in Ominiture ssl.o call:")
						 * +"<br>"+getBoldText("g:") + hashtable.get("g") +
						 * "<br>"+getBoldText("mmodule :") +
						 * hashtable.get("mmodule")+"<br>"+getBoldText("mpage:") +
						 * hashtable.get("mpage") + "<br>"+getBoldText("lnktxt :") +
						 * hashtable.get("lnktxt") + "<br>"+getBoldText("cstm :") +
						 * hashtable.get("cstm"));
						 */
						Hashtable<String, String> hashtablefordestinationurlweblog = getMatchedParamURLInfositeNot(
								getproxyServer(), env, "www." + env + "medscape.com/public/vptrack.wxml", SFID,
								"nav-link");
						//
						generateReport(hashtablefordestinationurlweblog.size() > 0,
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call  tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString(),
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString());
						Hashtable<String, String> hashtable = getMatchedParamURLInfosite(getproxyServer(), env,
								"ssl.o.webmd.com/b/ss/webmd", SFID, "mmodule");
						generateReport(hashtable.size() > 0, getBoldText("Attributes Tracked in 1st Ominiture  call:")
								+ "<br>" + getBoldText("g:") + hashtable.get("g") + "<br>" + getBoldText("mmodule :")
								+ hashtable.get("mmodule") + "<br>" + getBoldText("mpage:") + hashtable.get("mpage")
								+ "<br>" + getBoldText("lnktxt :") + hashtable.get("lnktxt") + "<br>"
								+ getBoldText("cstm :") + hashtable.get("cstm"),
								"Unable to Track ssl call with mmodule,mlink,mpage etc");
						verifyInfositenavLinkredirection(SFID, env);
						Hashtable<String, String> hashtablefordestinationurl = getMatchedParamURLInfosite(
								getproxyServer(), env, "ssl.o.webmd.com/b/ss/webmd", SFID, "c7");
						generateReport(hashtablefordestinationurl.size() > 0,
								getBoldText("Attributes Tracked in 2nd  Ominiture call:") + "<br>" + getBoldText("g:")
										+ hashtablefordestinationurl.get("g") + "<br>" + getBoldText("pageName :")
										+ hashtablefordestinationurl.get("pageName"),
								"Unable to Track 2nd  ssl call");

						// VerifyInfositeLoadcall(SFID, env);

					}

				} catch (Exception e) {
					e.printStackTrace();
					Logs.log(e.getMessage());
				}
			}
		} else if (homepageArticlesnav.size() > 0) {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			for (int o = 0; o < homepageArticlesnav.size(); o++) {

				server.newHar();
				generatePassReport(
						"*****************************************************************************************************************************************************");
				// clickByWebElement(homepageArticles.get(m),getTextForReport(homepageArticles,
				// m) + " : " + homepageArticles.get(m).getAttribute("href"));

				generateInfoReport("Click Performed on article:  " + getBoldText(homepageArticlesnav.get(o).getText())
						+ "  :" + homepageArticlesnav.get(o).getAttribute("href"));
				executor.executeScript("arguments[0].click();", homepageArticlesnav.get(o));
				staticWait(3);
				generateReport(getDriver().getTitle().equalsIgnoreCase("Information from Industry"),
						"Window Title Matched:" + getBoldText(getDriver().getTitle()),
						"Window Title Not Matched:" + getBoldText(getDriver().getTitle()));
				generatePassReportWithScreenShot("Below is the Article Screenshot");
				validateImages(getproxyServer(), env, SFID);
				Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
						"www." + env + "medscape.com/public/vptrack.wxml");
				generateReport(hashtable.size() > 0 && hashtable.toString().contains(SFID),
						getBoldText("Web log Call:www." + env + "medscape.com/public/vptrack.wxml call  tracked")
								+ " <br>" + hashtable.toString(),
						getBoldText(
								"Web log Call:www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
								+ " <br>" + hashtable.toString());
				staticWait(6);
				Hashtable<String, String> hashtablessl = getStdParmValues(getproxyServer(),
						"ssl.o.webmd.com/b/ss/webmd");
				generateReport(hashtablessl.size() > 0, getBoldText("Attributes Tracked in  Ominiture call:") + "<br>"
						+ getBoldText("g:") + hashtablessl.get("g") + "<br>" + getBoldText("pageName :")
						+ hashtablessl.get("pageName") + "<br>" + getBoldText("pid :") + hashtablessl.get("pid"),
						"Unable to Track ssl ominiture call");
				getDriver().navigate().back();
				try {
					if (driver.findElements(By.className("accept-button")).size() > 0) {
						driver.findElement(By.className("accept-button")).click();
					}
					if (driver.findElements(By.className("accept")).size() > 0) {
						driver.findElement(By.className("accept")).click();

					}

				} catch (Exception e) {

				}
				staticWait(2);
				navAndhomeLinks.clear();
				homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);

				if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
					homepageArticlesnav.remove(driver.findElement(InfositeObjectRepo.registartionform));
				}
				for (int p = 0; p < homepageArticlesnav.size(); p++) {
					if (homepageArticlesnav.get(p).isDisplayed()) {
						navAndhomeLinks.add(homepageArticlesnav.get(p));
					}
				}

			}
			homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);
			generateInfoReport("Click Performed on article:" + homepageArticlesnav.get(0).getText() + ":"
					+ homepageArticlesnav.get(0).getAttribute("href"));
			executor.executeScript("arguments[0].click();", homepageArticlesnav.get(0));
			staticWait(3);
			getDriver().navigate().refresh();
			try {
				if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
					driver.findElement(InfositeObjectRepo.Iconsent).click();
				}
				if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
					driver.findElement(InfositeObjectRepo.accept).click();

				}

			} catch (Exception e) {

			}

			staticWait(2);
			List<WebElement> navLinksMenufinal = new ArrayList<>();
			List<WebElement> navLinksMenu = driver.findElements(InfositeObjectRepo.allNavLinks);
			for (int u = 0; u < navLinksMenu.size(); u++) {

				if (!navLinksMenu.get(u).getAttribute("href").contains("isarticle")) {

				} else if (navLinksMenu.get(u).isDisplayed()) {
					navLinksMenufinal.add(navLinksMenu.get(u));
				}
			}
			staticWait(2);
			generatePassReport(
					"****************************************Started Verification for Navigation Menu Links****************************************");
			for (int y = 0; y < navLinksMenufinal.size(); y++) {
				startNewHar();
				generatePassReport(
						"*********************************************************************************************************************************************************");
				generateInfoReport("Click Performed on article:" + navLinksMenufinal.get(y).getText() + ":"
						+ navLinksMenufinal.get(y).getAttribute("href"));
				executor.executeScript("arguments[0].click();", navLinksMenufinal.get(y));
				// validate tracker marker call
				staticWait(3);
				if (y > 0) {
					String DestinationURL = getStdParmValuesForQueryString(server,
							"www." + env + "medscape.com/infosites/" + SFID + "/articles");

					Hashtable<String, String> trackermarker = getStdParmValues(server,
							"www." + env + "medscape.com/infosites/" + SFID + "/articles");

					generateReport(trackermarker.size() > 0 && DestinationURL != null,
							"Destination URL: " + getBoldText(DestinationURL), getBoldText(trackermarker.toString()));
					Hashtable<String, String> hashtablefordestinationurlweblog = getMatchedParamURLInfositeNot(
							getproxyServer(), env, "www." + env + "medscape.com/public/vptrack.wxml", SFID, "nav-link");
					generateReport(hashtablefordestinationurlweblog.size() > 0,
							getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call  tracked")
									+ " <br>" + hashtablefordestinationurlweblog.toString(),
							getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
									+ " <br>" + hashtablefordestinationurlweblog.toString());
					Hashtable<String, String> hashtable = getMatchedParamURLInfosite(getproxyServer(), env,
							"ssl.o.webmd.com/b/ss/webmd", SFID, "mmodule");
					generateReport(hashtable.size() > 0,
							getBoldText("Attributes Tracked in 1st Ominiture  call:") + "<br>" + getBoldText("g:")
									+ hashtable.get("g") + "<br>" + getBoldText("mmodule :") + hashtable.get("mmodule")
									+ "<br>" + getBoldText("mpage:") + hashtable.get("mpage") + "<br>"
									+ getBoldText("lnktxt :") + hashtable.get("lnktxt") + "<br>" + getBoldText("cstm :")
									+ hashtable.get("cstm"),
							"Unable to Track ssl call with mmodule,mlink,mpage etc");
					verifyInfositenavLinkredirection(SFID, env);
					Hashtable<String, String> hashtablefordestinationurl = getMatchedParamURLInfosite(getproxyServer(),
							env, "ssl.o.webmd.com/b/ss/webmd", SFID, "c7");
					generateReport(hashtablefordestinationurl.size() > 0,
							getBoldText("Attributes Tracked in 2nd  Ominiture call:") + "<br>" + getBoldText("g:")
									+ hashtablefordestinationurl.get("g") + "<br>" + getBoldText("pageName :")
									+ hashtablefordestinationurl.get("pageName"),
							"Unable to Track 2nd  ssl call");

				}
				navLinksMenufinal.clear();
				navLinksMenu = driver.findElements(InfositeObjectRepo.allNavLinks);
				for (int q = 0; q < navLinksMenu.size(); q++) {

					if (!navLinksMenu.get(q).getAttribute("href").contains("isarticle")) {

					} else if (navLinksMenu.get(q).isDisplayed()) {
						navLinksMenufinal.add(navLinksMenu.get(q));
					}
				}

			}
		} else if (homepageArticles.size() > 0) {
			for (int m = 1; m < homepageArticles.size(); m++) {
				try {

					if (homepageArticles.get(m).isDisplayed()) {
						server.newHar();
						generatePassReport(
								"*****************************************************************************************************************************************************");
						// clickByWebElement(homepageArticles.get(m),getTextForReport(homepageArticles,
						// m) + " : " + homepageArticles.get(m).getAttribute("href"));
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						generateInfoReport("Click Performed on article:" + homepageArticles.get(m).getText() + ":"
								+ homepageArticles.get(m).getAttribute("href"));
						executor.executeScript("arguments[0].click();", homepageArticles.get(m));
						generatePassReportWithScreenShot("Below is the Article Screenshot");
						staticWait(6);
						generateReport(getDriver().getTitle().equalsIgnoreCase("Information from Industry"),
								"Window Title Matched:" + getBoldText(getDriver().getTitle()),
								"Window Title Not Matched:" + getBoldText(getDriver().getTitle()));
						validateImages(getproxyServer(), env, SFID);
						// homepageArticles =
						// driver.findElements(By.xpath("//section[@class!='nav-buttons-container']//*[@data-module='RouterLink']"));
						homepageArticles = driver.findElements(InfositeObjectRepo.HomepageLinks);
						if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
							if (homepageArticles.contains(driver.findElement(InfositeObjectRepo.registartionform))) {
								homepageArticles.remove(driver.findElement(InfositeObjectRepo.registartionform));// removing
																													// registartion
																													// form
																													// if
																													// it
																													// is
																													// present
																													// in
																													// home
																													// Page

							}
						}
						Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
								"www." + env + "medscape.com/public/vptrack.wxml");
						generateReport(hashtable.size() > 0 && hashtable.toString().contains(SFID),
								getBoldText(
										"Web log Call:www." + env + "medscape.com/public/vptrack.wxml call  tracked")
										+ " <br>" + hashtable.toString(),
								getBoldText("Web log Call:www." + env
										+ "medscape.com/public/vptrack.wxml weblog call not tracked") + " <br>"
										+ hashtable.toString());
						staticWait(6);
						Hashtable<String, String> hashtablessl = getStdParmValues(getproxyServer(),
								"ssl.o.webmd.com/b/ss/webmd");
						generateReport(hashtablessl.size() > 0,
								getBoldText("Attributes Tracked in  Ominiture call:") + "<br>" + getBoldText("g:")
										+ hashtablessl.get("g") + "<br>" + getBoldText("pageName :")
										+ hashtablessl.get("pageName") + "<br>" + getBoldText("pid :")
										+ hashtablessl.get("pid"),
								"Unable to Track ssl ominiture call");
					}

				} catch (Exception e) {
					e.printStackTrace();
					Logs.log(e.getMessage());
				}

			}
		}
	}

	public String getStdParmValuesForQueryString(BrowserMobProxyServer server, String domaine) {

		// ArrayList<Hashtable<String, String>> arrayList = new
		// ArrayList<Hashtable<String, String>>();
		String requestUrl = "";
		Hashtable<String, String> stdValues = new Hashtable<>();
		Hashtable<Hashtable, String> stdValuesAndQuery = new Hashtable<>();

		boolean valueTracked = false;
		int noOFTimes = 0;
		while (!valueTracked) {

			try {
				if (noOFTimes == 3) {
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(domaine)) {
						// Logs.logAndConsole(requestUrl);
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

						// System.out.println(entries.get(i).getRequest().getQueryString());
						// generateInfoReport(requestUrl);
						stdValues = new Hashtable<>();
						for (HarNameValuePair harNameValuePair : harNameValuePairs) {
							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
						}
						// generatePassReport(requestUrl);
						return requestUrl;
					}

				}
			} catch (Exception e) {
				Logs.log(e.getMessage());
			}
		}
		return requestUrl;
	}

	public void verifyInfositenavLinkredirection(String SFID, String environment) {
		Hashtable<String, String> hashtable = getMatchedParamURLInfosite(getproxyServer(), environment,
				"www." + environment + "medscape.com/public/vptrack.wxml", SFID, "nav-link");
		generateReport(hashtable.size() > 0, getBoldText("Nav_Link ") + "  tracked <br>" + hashtable.toString(),
				getBoldText("Nav_Link") + " not tracked <br>" + hashtable.toString());

	}

	public Hashtable<String, String> getMatchedParamURLInfosite(BrowserMobProxyServer server, String environment,
			String value1, String sfid, String value2) {

		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;
		int noOFTimes = 0;

		while (!valueTracked) {

			try {
				if (noOFTimes == 3) {
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(value1) && requestUrl.contains(sfid) && requestUrl.contains(value2)) {
						// Logs.info(requestUrl);
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

						// System.out.println(entries.get(i).getRequest().getQueryString());
						stdValues = new Hashtable<>();

						for (HarNameValuePair harNameValuePair : harNameValuePairs) {

							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());

						}
						return stdValues;

					}

				}
			} catch (Exception e) {
				Logs.logAndConsole(e.getMessage());
			}
		}
		return stdValues;

	}

	public Hashtable<String, String> getMatchedParamURLInfositeNot(BrowserMobProxyServer server, String environment,
			String value1, String sfid, String value2) {

		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;
		int noOFTimes = 0;

		while (!valueTracked) {

			try {
				if (noOFTimes == 3) {
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(value1) && requestUrl.contains(sfid) && !requestUrl.contains(value2)) {
						// Logs.info(requestUrl);
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

						// System.out.println(entries.get(i).getRequest().getQueryString());
						stdValues = new Hashtable<>();

						for (HarNameValuePair harNameValuePair : harNameValuePairs) {

							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());

						}
						return stdValues;

					}

				}
			} catch (Exception e) {
				Logs.logAndConsole(e.getMessage());
			}
		}
		return stdValues;

	}

	public void clickOnInfositeinternalLinks(WebDriver driver, BrowserMobProxyServer server, String SFID, String env)
			throws Exception {
		driver.manage().window().maximize();
		driver.navigate().refresh();
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> internalLinks = new ArrayList<>();
		generatePassReport(
				"==================================== Internal Links Verification====================================");
		try {
			// Handle I consent
			if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
				driver.findElement(InfositeObjectRepo.Iconsent).click();
				generateInfoReport("Click Performed on Accept button");
				verifyOmnitureValues(getproxyServer(), "https://ssl.o.webmd.com/b/ss", "mlink,mmodule,mpage,mpgtitle",
						"accept", "equals,notnull,notnull,notnull");
			}
			// Handle ISI accept
			if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
				driver.findElement(InfositeObjectRepo.accept).click();
				generateInfoReport("Click Performed on 'I CONSENT' button");
				verifyOmnitureValues(getproxyServer(), "https://ssl.o.webmd.com/b/ss", "mlink,mmodule,mpage,mpgtitle",
						"accept", "equals,notnull,notnull,notnull");
			}

			if (driver.findElements(By.xpath("//*[@class='medscape-link']//a")).size() > 0) {
				internalLinks.add("//*[@class='medscape-link']//a");

			} else {
				generateFailReport("Unable to find Return to medscape");
			}
			if (driver.findElements(By.xpath("(//a[contains(text(),'Privacy Policy')])[last()]")).size() > 0) {
				internalLinks.add("(//a[contains(text(),'Privacy Policy')])[last()]");
			}

		} catch (Exception e) {

		}

		for (int i = 0; i < internalLinks.size(); i++) {

			JavascriptExecutor executor = (JavascriptExecutor) driver;

			executor.executeScript("arguments[0].click();", driver.findElement(By.xpath(internalLinks.get(i))));
			// click(By.xpath(internalLinks.get(i)),
			// internalLinks.get(i));

			Set<String> windows = driver.getWindowHandles();
			Iterator<String> iterator = windows.iterator();
			String lastWindow = "";

			while (iterator.hasNext()) {
				lastWindow = iterator.next();
			}

			driver.switchTo().window(lastWindow);
			generatePassReport("Click performed on" + internalLinks.get(i) + " And Redirection URL is  : "
					+ driver.getCurrentUrl());
			if (driver.getWindowHandles().size() > 1) {
				if (!winHandleBefore.equalsIgnoreCase(lastWindow)) {
					driver.close();
				}
				driver.switchTo().window(winHandleBefore);
			} else {
				Thread.sleep(1000);
				// allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));
				driver.navigate().back();
			}

		}

	}

	public void clickOnInfositeexternalLinkstemplte(WebDriver driver, BrowserMobProxyServer server, String SFID,
			String env, List<WebElement> listelements) throws Exception {
		try {
			String winHandleBefore = driver.getWindowHandle();
			int size = listelements.size();
			List<WebElement> displayedextlinks = new ArrayList<WebElement>();
			for (int i = 0; i < size; i++) {

				if (listelements.get(i).getAttribute("href").contains("?exturl=/infosites/" + SFID + "/")
						|| listelements.get(i).getText().contains("Privacy Policy")
						|| listelements.get(i).getAttribute("href").equalsIgnoreCase("https://www.medscape.com/")
						|| listelements.get(i).getAttribute("href")
								.equalsIgnoreCase("https://www.medscape.com/public/privacy")) {

				} else if (listelements.get(i).isDisplayed()) {
					displayedextlinks.add(listelements.get(i));
				}
			}
			if (!displayedextlinks.isEmpty()) {
				/*
				 * for (int l = 0; l < listelements.size(); l++) {
				 * if(listelements.get(l).isDisplayed()) {
				 * displayedextlinks.add(listelements.get(l)); } }
				 */
				generateInfoReport("No of links Available on Current Article:" + displayedextlinks.size());
				String elinks = "";
				elinks = getAllLinksAndTitles(displayedextlinks, elinks);
				if (displayedextlinks.size() > 0) {
					generatePassReport("All Displayed Links and urls in Article are: <br>" + elinks);
				}
				for (int j = 0; j < displayedextlinks.size(); j++) {
					if (displayedextlinks.get(j).isDisplayed()) {
						server.newHar();
						/*
						 * clickByWebElement(displayedextlinks.get(j),
						 * getTextForReport(displayedextlinks, j) + " : " +
						 * displayedextlinks.get(j).getAttribute("href"));
						 */
						String currenturl=driver.getCurrentUrl();
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						generateInfoReport("click performed on :" + displayedextlinks.get(j).getAttribute("href"));
						executor.executeScript("arguments[0].click();", displayedextlinks.get(j));
						Hashtable<String, String> trackermarker = getStdParmValues(server,
								"www." + env + "medscape.com/px/trk.svr/" + SFID);

						generateReport(trackermarker.size() > 0, getBoldText("Tracker Marker Call") + " : www." + env
								+ "medscape.com/px/trk.svr/- tracked <br>" + getBoldText(trackermarker.toString()),
								getBoldText("Tracker Marker Call") + ": www." + env
										+ "medscape.com/px/trk.svr/- not tracked <br>"
										+ getBoldText(trackermarker.toString()));

						Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
								"ssl.o.webmd.com/b/ss/webmd");
						String exturl=driver.getCurrentUrl();
								
						filePathsWebVadidationSF(hashtable, SFID);
						Set<String> windows = driver.getWindowHandles();
						Iterator<String> iterator = windows.iterator();
						String lastWindow = "";
			if(windows.size()<1) {
			generateFailReport("Link opening in Same Page");
			driver.navigate().back();
	
	try {
		listelements=driver.findElements(InfositeObjectRepo.extLinks);
		for (int i = 0; i < size; i++) {

			if (listelements.get(i).getAttribute("href").contains("?exturl=/infosites/" + SFID + "/")
					|| listelements.get(i).getText().contains("Privacy Policy")
					|| listelements.get(i).getAttribute("href").equalsIgnoreCase("https://www.medscape.com/")
					|| listelements.get(i).getAttribute("href")
							.equalsIgnoreCase("https://www.medscape.com/public/privacy")) {

			} else if (listelements.get(i).isDisplayed()) {
				displayedextlinks.add(listelements.get(i));
			}
		}
	} catch (Exception e) {
		// TODO: handle exception
	}
	
}else{
						while (iterator.hasNext()) {
							lastWindow = iterator.next();
						}

						driver.switchTo().window(lastWindow);
						generatePassReport("External Link redirection URL in Browser:  " + driver.getCurrentUrl());
						staticWait(4);
						if (driver.getWindowHandles().size() > 1) {
							if (!winHandleBefore.equalsIgnoreCase(lastWindow)) {
								driver.close();
							}
							driver.switchTo().window(winHandleBefore);

						} else {
							Thread.sleep(1000);
							// allLinks = driver.findElements(By.xpath("//div[@id='contentblock']//a"));
						}
						generatePassReport(
								"==================================================================================================");
					}
					
					}

				}

			} else {

				generateBoldInfo("No external Links available on current article");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Hashtable<String, String> verifyOmnitureValues(BrowserMobProxyServer server, String domain,
			String omnitureAttributes,

			String omnitureValues, String containsORequalsORendswith) {

		Hashtable<String, String> stdValues = new Hashtable<>();

		String[] attributes = omnitureAttributes.split(",");

		String[] values = omnitureValues.split(",");
		try {
			if (values.length <= 0) {
				values = new String[attributes.length];
				for (int i = 0; i < values.length; i++)
					values[i] = "";
			}
		} catch (Exception e) {
			values = new String[attributes.length];
			for (int i = 0; i < values.length; i++)
				values[i] = "";

		}

		String[] occurance = containsORequalsORendswith.split(",");

		String omnValuesTracked = null;

		boolean valueTracked = false;

		boolean valuenotTracked = false;

		String trackedCalls = "";

		try {

			Har har = server.getHar();

			List<HarEntry> entries = har.getLog().getEntries();

			for (int i = 0; i < entries.size(); i++) {

				String requestUrl = entries.get(i).getRequest().getUrl();

				Logs.log(requestUrl);

				if (requestUrl.contains(domain)) {

					valueTracked = false;

					valuenotTracked = false;

					List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

					// generateInfoReport(harNameValuePairs.toString());commented-teja
					// Logs.logAndConsole(requestUrl);

					trackedCalls = trackedCalls + "<br>" + requestUrl;

					// Logs.logAndConsole(harNameValuePairs.toString());

					stdValues = new Hashtable<>();

					for (HarNameValuePair harNameValuePair : harNameValuePairs) {

						stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());

					}

					for (int j = 0; j < attributes.length; j++) {

						try {

							switch (occurance[j]) {

							case "contains":

								if (stdValues.get(attributes[j]).trim().toString().contains(values[j]))

									valueTracked = true;

								else

									valuenotTracked = true;

								break;

							case "equals":

								if (stdValues.get(attributes[j]).trim().toString().equals(values[j]))

									valueTracked = true;

								else

									valuenotTracked = true;

								break;

							case "endswith":

								if (stdValues.get(attributes[j]).trim().toString().endsWith(values[j]))

									valueTracked = true;

								else

									valuenotTracked = true;

								break;

							case "startswith":

								if (stdValues.get(attributes[j]).trim().toString().startsWith(values[j]))

									valueTracked = true;

								else

									valuenotTracked = true;

								break;

							case "notnull":

								try {

									if (stdValues.get(attributes[j]).toString().length() > 0)

										valueTracked = true;

									else

										valuenotTracked = true;

								} catch (Exception e) {

									valuenotTracked = true;

								}

								break;

							case "optional":

								valueTracked = true;
								break;

							}

							try {

								if (stdValues.get(attributes[j]).toString().length() > 0) {

									if (omnValuesTracked == null)

										omnValuesTracked = "{  [ ";

									omnValuesTracked = omnValuesTracked + stdValues.get(attributes[j]).toString()
											+ "  ,  ";

								}

							} catch (Exception e) {

								if (omnValuesTracked == null)

									omnValuesTracked = "{  [ ";

								omnValuesTracked = omnValuesTracked + "  , ";

							}

						} catch (Exception e) {

							valuenotTracked = true;

							try {

								if (stdValues.get(attributes[j]).toString().length() > 0) {

									if (omnValuesTracked == null)

										omnValuesTracked = "{  [ ";

									omnValuesTracked = omnValuesTracked + stdValues.get(attributes[j]).toString()
											+ "  ,  ";

								}

							} catch (Exception e1) {

								if (omnValuesTracked == null)

									omnValuesTracked = "{  [ ";

								omnValuesTracked = omnValuesTracked + "  , ";

							}

							// if (loop == 2)// this break will stop setting
							// null values to variable at end of // execution

							// break;

							// stdValues = new Hashtable<>();

						}

					}

					if (omnValuesTracked != null)

						omnValuesTracked = omnValuesTracked + "] , [";

				} // end of if

				if (valueTracked == true && valuenotTracked == false) {

					break;

				}

				// else {

				// valueTracked = false;

				// if (loop == 2)

				// break;

				// stdValues = new Hashtable<>();

				// }

			}

			// loop++;

			//

			// if (loop > 2)

			// break;

			// else

			// omnValuesTracked = null;

		} catch (Exception e) {

			e.printStackTrace();

		}

		if (omnValuesTracked != null) {

			omnValuesTracked = omnValuesTracked.substring(0, omnValuesTracked.length() - 3);

			omnValuesTracked = omnValuesTracked + "  } ";

		}

		for (String attribute : attributes) {
			generateInfoReport(attribute + " :" + stdValues.get(attribute));
		}

		generateReport(valueTracked == true && valuenotTracked == false,

				domain + "    " + getBoldText(omnitureAttributes) + " attributes validated with values  "

						+ getBoldText(omnitureValues)
						+ " and all values are tracked <br> after comparing with actual values "
						+ getBoldText(omnValuesTracked) + "<br> ",

				domain + "    " + getBoldText(omnitureAttributes) + "    attributes validated with values  "

						+ getBoldText(omnitureValues)
						+ " and values are not tracked after comapring with actual values  "
						+ getBoldText(omnValuesTracked) + "<br> ");

		return stdValues;

	}

	public void ExecuteJavascript(String javascript) {

		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Thread.sleep(1000);

			js.executeScript(javascript);
			Thread.sleep(5000);

		} catch (Exception e) {
			// generateFailReport("Exception occured while tracking omniture: "
			// + e.getMessage());
			e.printStackTrace();
		}

	}

	public void waitForElement(By locator, String locatorName) {
		boolean flag = false;
		try {
			// this is old code
			// WebDriverWait wait = new WebDriverWait(driver, 30);
			// wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			int loop = 10;
			int i = 0;
			while (flag == false) {
				if (driver.findElements(locator).size() > 0) {
					System.out.println("element found :" + locatorName);
					flag = true;
				}

				i = i++;
				if (i > loop)
					break;
			}

		} catch (Exception e1) {
			e1.printStackTrace();
		}

	}

	public Hashtable<String, String> getOminitureVideo(BrowserMobProxyServer server, String domain, String environment,
			String value1, String sfid, String value2) {

		Hashtable<String, String> stdValues = new Hashtable<>();
		boolean valueTracked = false;
		int noOFTimes = 0;

		while (!valueTracked) {

			try {
				if (noOFTimes == 3) {
					break;
				}
				Thread.sleep(2000);
				noOFTimes++;
				Har har = server.getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();
					Logs.log(requestUrl);
					if (requestUrl.contains(domain) && requestUrl.contains(value1) && requestUrl.contains(sfid)
							&& requestUrl.contains(value2)) {
						// Logs.info(requestUrl);
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();

						// System.out.println(entries.get(i).getRequest().getQueryString());
						stdValues = new Hashtable<>();

						for (HarNameValuePair harNameValuePair : harNameValuePairs) {

							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());

						}
						return stdValues;

					}

				}
			} catch (Exception e) {
				Logs.logAndConsole(e.getMessage());
			}
		}
		return stdValues;
	}

	public void VerifyInfositeMultipleFunctionalities_ByArticles(WebDriver driver, ActionMethods action,
			BrowserMobProxyServer server, String SFID, String env, String functionality, String url) throws Exception {

		int videocount = 0;

		Videos_Tracking videos = new Videos_Tracking();
		if (functionality.equalsIgnoreCase("extlinks")) {
			generatePassReport(
					"=========================================External  Links Verification ==========================================");
		} else if (functionality.equalsIgnoreCase("videos")) {
			generatePassReport(
					"==============================================Infosite Articles Video Functionality Verification ===================================================");
		} else if (functionality.equalsIgnoreCase("hearbeatcalls")) {
			generatePassReport(
					"***************************************Heart Beat Calls Verification***************************************");
		} else if (functionality.equalsIgnoreCase("poll")) {
			generatePassReport(
					"***************************************Poll questions Verification***************************************");
		} else if (functionality.equalsIgnoreCase("withinarticle")) {
			generatePassReport(
					"***************************************Within Article 'Next' Link's verification***************************************");
		}
		driver.get(url);
		staticWait(6);
		// driver.manage().window().maximize();
		try {
			if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
				driver.findElement(InfositeObjectRepo.Iconsent).click();
			}
			if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
				driver.findElement(InfositeObjectRepo.accept).click();
			}
		} catch (Exception e) {

		}
		staticWait(2);
		ArrayList<WebElement> displayedextlinks = new ArrayList<WebElement>();
		List<WebElement> intialallLinks = driver.findElements(InfositeObjectRepo.allNavLinks);

		List<WebElement> articles = new ArrayList<>();

		for (int l = 0; l < intialallLinks.size(); l++) {
			if (intialallLinks.get(l).isDisplayed()) {
				articles.add(intialallLinks.get(l));
			}
		}
		List<WebElement> allLinks_1 = new ArrayList<>();
		List<WebElement> intialallLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
		for (int k = 0; k < intialallLinks_1.size(); k++) {
			if (intialallLinks_1.get(k).getAttribute("href").contains("mailto")
					|| intialallLinks_1.get(k).getAttribute("href").contains("tel:")) {

			} else if (intialallLinks_1.get(k).isDisplayed()) {
				allLinks_1.add(intialallLinks_1.get(k));
			}
		}
		// List<WebElement> homepageArticles =
		// driver.findElements(By.xpath("//section[@class!='nav-buttons-container']//*[@data-module='RouterLink']"));
		List<WebElement> homepageArticles = driver.findElements(InfositeObjectRepo.HomepageLinks);
		if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
			if (homepageArticles.contains(driver.findElement(InfositeObjectRepo.registartionform))) {
				homepageArticles.remove(driver.findElement(InfositeObjectRepo.registartionform));// removing
																									// registartion form
																									// if it is present
																									// in home Page

			}
		}
		List<WebElement> homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);
		List<WebElement> navAndhomeLinks = new ArrayList<>();
		if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
			homepageArticlesnav.remove(driver.findElement(InfositeObjectRepo.registartionform));
		}
		for (int p = 0; p < homepageArticlesnav.size(); p++) {
			if (homepageArticlesnav.get(p).isDisplayed()) {
				navAndhomeLinks.add(homepageArticlesnav.get(p));
			}
		}
		if (articles.size() > 0) {
			for (int k = 0; k < articles.size(); k++) {

				// clickByWebElement(articles.get(k),getTextForReport(articles, k) + " : " +
				// articles.get(k).getAttribute("href"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				generateInfoReport("click performed on  :" + getBoldText(articles.get(k).getAttribute("href")));
				executor.executeScript("arguments[0].click();", articles.get(k));
				staticWait(6);
				List<WebElement> allLinks = driver.findElements(InfositeObjectRepo.extLinks);
				// *[@class='js-tracking' and contains(@target,'_blank')]
				allLinks.addAll(driver.findElements(InfositeObjectRepo.additionalextLinks));
				if (functionality.equalsIgnoreCase("extlinks")) {
					clickOnInfositeexternalLinkstemplte(getDriver(), getproxyServer(), SFID, env, allLinks);
				} else if (functionality.equalsIgnoreCase("videos")) {
					if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

						generateInfoReport("Single Video is Present on the current article page:"
								+ getBoldText(articles.get(k).getText()));
						videos.performVideoTracking(getDriver(), action);

					} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
						generateInfoReport("Multiple Video's are  Present on the current article page:"
								+ getBoldText(articles.get(k).getText()));
						videos.performMultipleVideoTracking(getDriver(), action);
						action.generatePassReport(
								"===============================================================================================================================");
						action.generatePassReport(
								"===============================================================================================================================");
					} else {
						generateInfoReport(
								"No video's Present on the current Page:" + getBoldText(articles.get(k).getText()));
					}
				} else if (functionality.equalsIgnoreCase("hearbeatcalls")) {
					if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

						generateInfoReport("Single Video is Present on the current article page:"
								+ getBoldText(articles.get(k).getText()));
						videos.trackHeartBeatCalls(getDriver(), action, SFID);

					} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
						generateInfoReport("Multiple Video's are  Present on the current article page:"
								+ getBoldText(articles.get(k).getText()));
						videos.trackHeartBeatCallsForMultipleVideos(getDriver(), action, SFID);
						action.generatePassReport(
								"===============================================================================================================================");
						action.generatePassReport(
								"===============================================================================================================================");
					} else {
						generateInfoReport(
								"No video's Present on the current Page:" + getBoldText(articles.get(k).getText()));
					}
				} else if (functionality.equalsIgnoreCase("poll")) {
					generateInfoReport(
							"Poll Verification  on the current article page:" + getBoldText(articles.get(k).getText()));
					infositePollVerification(getDriver(), InfositeObjectRepo.pollquestions,
							InfositeObjectRepo.pollsubmit, env);
					action.generatePassReport(
							"===============================================================================================================================");
					// action.generatePassReport("===============================================================================================================================");
				}
			}
		} else if (allLinks_1.size() > 0) {
			allLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
			try {
				for (int i = 0; i < allLinks_1.size(); i++) {

					if (allLinks_1.get(i).isDisplayed() && !allLinks_1.get(i).getAttribute("href").contains("mailto")
							&& allLinks_1.get(i).getAttribute("href").contains("article")) {
						server.newHar();

						JavascriptExecutor executor = (JavascriptExecutor) driver;
						String articleurl = allLinks_1.get(i).getAttribute("href");
						// clickByWebElement(allLinks_1.get(i),getTextForReport(allLinks_1, i) + " : " +
						// allLinks_1.get(i).getAttribute("href"));
						executor.executeScript("arguments[0].click();", allLinks_1.get(i));
						generateInfoReport("click performed on  :" + articleurl);
						// String articleurl=allLinks_1.get(i).getAttribute("href");
						// executor.executeScript("arguments[0].click();",allLinks_1.get(i) );
						staticWait(6);
						allLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
						List<WebElement> allLinks = driver.findElements(InfositeObjectRepo.extLinks);
						allLinks.addAll(driver.findElements(InfositeObjectRepo.additionalextLinks));

						if (functionality.equalsIgnoreCase("extlinks")) {
							clickOnInfositeexternalLinkstemplte(getDriver(), getproxyServer(), SFID, env, allLinks);
						} else if (functionality.equalsIgnoreCase("videos")) {
							if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

								generateInfoReport("Single Video is Present on the current article page:" + articleurl);
								videos.performVideoTracking(getDriver(), action);

							} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
								generateInfoReport(
										"Multiple Video's are  Present on the current article page:" + articleurl);
								videos.performMultipleVideoTracking(getDriver(), action);
								action.generatePassReport(
										"===============================================================================================================================");
								action.generatePassReport(
										"===============================================================================================================================");
							} else {
								generateInfoReport("No video's Present on the current Page:" + articleurl);
							}
						} else if (functionality.equalsIgnoreCase("hearbeatcalls")) {
							if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

								generateInfoReport("Single Video is Present on the current article page:" + articleurl);
								videos.trackHeartBeatCalls(getDriver(), action, SFID);

							} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
								generateInfoReport(
										"Multiple Video's are  Present on the current article page:" + articleurl);
								videos.trackHeartBeatCallsForMultipleVideos(getDriver(), action, SFID);
								action.generatePassReport(
										"===============================================================================================================================");
								action.generatePassReport(
										"===============================================================================================================================");
							} else {
								generateInfoReport("No video's Present on the current Page:" + articleurl);
							}
						} else if (functionality.equalsIgnoreCase("poll")) {
							generateInfoReport("Poll Verification  on the current article page:" + articleurl);
							infositePollVerification(getDriver(), InfositeObjectRepo.pollquestions,
									InfositeObjectRepo.pollsubmit, env);
							action.generatePassReport(
									"===============================================================================================================================");
							// action.generatePassReport("===============================================================================================================================");
						}
					}

				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (navAndhomeLinks.size() > 0) {
			staticWait(3);

			List<WebElement> allextLinks = driver.findElements(InfositeObjectRepo.extLinks);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			if (functionality.equalsIgnoreCase("extlinks")) {
				staticWait(2);
				allextLinks = driver.findElements(InfositeObjectRepo.extLinks);
				clickOnInfositeexternalLinkstemplte(getDriver(), getproxyServer(), SFID, env, allextLinks);
			} else if (functionality.equalsIgnoreCase("videos")) {
				staticWait(2);
				if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

					generateInfoReport("Single Video is Present on the Home article page:");
					videos.performVideoTracking(getDriver(), action);

				} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
					staticWait(2);
					generateInfoReport("Multiple Video's are  Present on the current article page:");
					videos.performMultipleVideoTracking(getDriver(), action);
					action.generatePassReport(
							"===============================================================================================================================");
					action.generatePassReport(
							"===============================================================================================================================");
				} else {
					staticWait(1);
					generateInfoReport("No video's Present on the current Home Page:");
				}

			} else if (functionality.equalsIgnoreCase("hearbeatcalls")) {
				staticWait(2);
				if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

					generateInfoReport("Single Video is Present on the current Home article page:");
					videos.trackHeartBeatCalls(getDriver(), action, SFID);

				} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
					staticWait(2);
					generateInfoReport("Multiple Video's are  Present on the current Home article page:");
					videos.trackHeartBeatCallsForMultipleVideos(getDriver(), action, SFID);
					action.generatePassReport(
							"===============================================================================================================================");
					action.generatePassReport(
							"===============================================================================================================================");
				} else {
					generateInfoReport("No video's Present on the current Home Page:");
				}
			} else if (functionality.equalsIgnoreCase("poll")) {
				staticWait(2);
				generateInfoReport("Poll verification on the current article page:");
				infositePollVerification(getDriver(), InfositeObjectRepo.pollquestions, InfositeObjectRepo.pollsubmit,
						env);
				action.generatePassReport(
						"===============================================================================================================================");
				// action.generatePassReport("===============================================================================================================================");
			}

			for (int o = 0; o < navAndhomeLinks.size(); o++) {
				homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);
				navAndhomeLinks = new ArrayList<>();
				if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
					homepageArticlesnav.remove(InfositeObjectRepo.registartionform);
				}
				for (int p = 0; p < homepageArticlesnav.size(); p++) {
					if (homepageArticlesnav.get(p).isDisplayed()) {
						navAndhomeLinks.add(homepageArticlesnav.get(p));
					}
				}

				server.newHar();
				generatePassReport(
						"*****************************************************************************************************************************************************");
				// clickByWebElement(homepageArticles.get(m),getTextForReport(homepageArticles,
				// m) + " : " + homepageArticles.get(m).getAttribute("href"));

				generateInfoReport("Click Performed on article:  " + getBoldText(navAndhomeLinks.get(o).getText())
						+ "  :" + navAndhomeLinks.get(o).getAttribute("href"));
				String articleText = navAndhomeLinks.get(o).getText();
				executor.executeScript("arguments[0].click();", navAndhomeLinks.get(o));
				staticWait(3);

				if (functionality.equalsIgnoreCase("extlinks")) {
					// getDriver().navigate().refresh();
					List<WebElement> allextLinks1 = driver.findElements(InfositeObjectRepo.extLinks);
					clickOnInfositeexternalLinkstemplte(getDriver(), getproxyServer(), SFID, env, allextLinks1);
				} else if (functionality.equalsIgnoreCase("videos")) {
					staticWait(2);
					if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

						generateInfoReport(
								"Single Video is Present on the current article page:" + getBoldText(articleText));
						videos.performVideoTracking(getDriver(), action);

					} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
						staticWait(2);
						generateInfoReport("Multiple Video's are  Present on the current article page:"
								+ getBoldText(articleText));
						videos.performMultipleVideoTracking(getDriver(), action);
						action.generatePassReport(
								"===============================================================================================================================");
						action.generatePassReport(
								"===============================================================================================================================");
					} else {
						generateInfoReport("No video's Present on the current Page:" + getBoldText(articleText));
					}

				} else if (functionality.equalsIgnoreCase("hearbeatcalls")) {
					staticWait(2);
					if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

						generateInfoReport(
								"Single Video is Present on the current article page:" + getBoldText(articleText));
						videos.trackHeartBeatCalls(getDriver(), action, SFID);

					} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
						staticWait(2);
						generateInfoReport("Multiple Video's are  Present on the current article page:"
								+ getBoldText(articleText));
						videos.trackHeartBeatCallsForMultipleVideos(getDriver(), action, SFID);
						action.generatePassReport(
								"===============================================================================================================================");
						action.generatePassReport(
								"===============================================================================================================================");
					} else {
						generateInfoReport("No video's Present on the current Page:" + getBoldText(articleText));
					}
				} else if (functionality.equalsIgnoreCase("poll")) {

					generateInfoReport("Poll verification on the current article page:" + getBoldText(articleText));
					infositePollVerification(getDriver(), InfositeObjectRepo.pollquestions,
							InfositeObjectRepo.pollsubmit, env);
					action.generatePassReport(
							"===============================================================================================================================");
					// action.generatePassReport("===============================================================================================================================");
				}
				getDriver().navigate().back();
				staticWait(3);
				try {
					if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
						driver.findElement(InfositeObjectRepo.Iconsent).click();
					}
					if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
						driver.findElement(InfositeObjectRepo.accept).click();

					}

				} catch (Exception e) {

				}
				staticWait(2);
				navAndhomeLinks.clear();
				homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);

				if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
					homepageArticlesnav.remove(driver.findElement(InfositeObjectRepo.registartionform));
				}
				for (int p = 0; p < homepageArticlesnav.size(); p++) {
					if (homepageArticlesnav.get(p).isDisplayed()) {
						navAndhomeLinks.add(homepageArticlesnav.get(p));
					}
				}

			}
		} else if (homepageArticles.size() > 0) {

			List<WebElement> allLinks = driver.findElements(InfositeObjectRepo.extLinks);
			for (int m = 1; m < homepageArticles.size(); m++) {
				try {

					if (homepageArticles.get(m).isDisplayed()) {
						server.newHar();
						generatePassReport(
								"*****************************************************************************************************************************************************");
						// clickByWebElement(homepageArticles.get(m),getTextForReport(homepageArticles,
						// m) + " : " + homepageArticles.get(m).getAttribute("href"));
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						generateInfoReport(
								"click performed on  :" + getBoldText(homepageArticles.get(m).getAttribute("href")));
						executor.executeScript("arguments[0].click();", homepageArticles.get(m));

						staticWait(6);
						allLinks = driver.findElements(InfositeObjectRepo.extLinks);
						if (functionality.equalsIgnoreCase("extlinks")) {
							clickOnInfositeexternalLinkstemplte(getDriver(), getproxyServer(), SFID, env, allLinks);
						} else if (functionality.equalsIgnoreCase("videos")) {

							if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

								generateInfoReport("Single Video is Present on the current article page:"
										+ getBoldText(homepageArticles.get(m).getText()));
								videos.performVideoTracking(getDriver(), action);

							} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
								generateInfoReport("Multiple Video's are  Present on the current article page:"
										+ getBoldText(homepageArticles.get(m).getText()));
								videos.performMultipleVideoTracking(getDriver(), action);
								action.generatePassReport(
										"===============================================================================================================================");
								action.generatePassReport(
										"===============================================================================================================================");
							} else {
								generateInfoReport("No video's Present on the current Page:"
										+ getBoldText(homepageArticles.get(m).getText()));
							}

						} else if (functionality.equalsIgnoreCase("hearbeatcalls")) {
							if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

								generateInfoReport("Single Video is Present on the current article page:"
										+ getBoldText(homepageArticles.get(m).getText()));
								videos.trackHeartBeatCalls(getDriver(), action, SFID);

							} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
								generateInfoReport("Multiple Video's are  Present on the current article page:"
										+ getBoldText(homepageArticles.get(m).getText()));
								videos.trackHeartBeatCallsForMultipleVideos(getDriver(), action, SFID);
								action.generatePassReport(
										"===============================================================================================================================");
								action.generatePassReport(
										"===============================================================================================================================");
							} else {
								generateInfoReport("No video's Present on the current Page:"
										+ getBoldText(homepageArticles.get(m).getText()));
							}
						} else if (functionality.equalsIgnoreCase("poll")) {
							generateInfoReport("Poll verification on the current article page:"
									+ getBoldText(homepageArticles.get(m).getText()));
							infositePollVerification(getDriver(), InfositeObjectRepo.pollquestions,
									InfositeObjectRepo.pollsubmit, env);
							action.generatePassReport(
									"===============================================================================================================================");
							// action.generatePassReport("===============================================================================================================================");
						}

					}

				} catch (Exception e) {
					e.printStackTrace();
					Logs.log(e.getMessage());
				}

			}

		} else {

			List<WebElement> allLinks = driver.findElements(InfositeObjectRepo.extLinks);

			if (functionality.equalsIgnoreCase("extlinks")) {
				clickOnInfositeexternalLinkstemplte(getDriver(), getproxyServer(), SFID, env, allLinks);
			} else if (functionality.equalsIgnoreCase("videos")) {

				if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

					generateInfoReport("Single Video is Present on the current article page:");
					videos.performVideoTracking(getDriver(), action);

				} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
					generateInfoReport("Multiple Video's are  Present on the current article page:");
					videos.performMultipleVideoTracking(getDriver(), action);
					action.generatePassReport(
							"===============================================================================================================================");
					action.generatePassReport(
							"===============================================================================================================================");
				} else {
					generateInfoReport("No video's Present on the current Page:");
				}

			} else if (functionality.equalsIgnoreCase("hearbeatcalls")) {
				if (driver.findElements(InfositeObjectRepo.videoScreen).size() == 1) {

					generateInfoReport("Single Video is Present on the current article page:");
					videos.trackHeartBeatCalls(getDriver(), action, SFID);

				} else if (driver.findElements(InfositeObjectRepo.videoScreen).size() > 1) {
					generateInfoReport("Multiple Video's are  Present on the current article page:");
					videos.trackHeartBeatCallsForMultipleVideos(getDriver(), action, SFID);
					action.generatePassReport(
							"===============================================================================================================================");
					action.generatePassReport(
							"===============================================================================================================================");
				} else {
					generateInfoReport("No video's Present on the current Page:");
				}
			} else if (functionality.equalsIgnoreCase("poll")) {
				generateInfoReport("Poll verification on the current article page:");
				infositePollVerification(getDriver(), InfositeObjectRepo.pollquestions, InfositeObjectRepo.pollsubmit,
						env);
				action.generatePassReport(
						"===============================================================================================================================");
				action.generatePassReport(
						"===============================================================================================================================");
			}

		}
	}

	public int verifySslCalls(String domain) {
		System.out.println("domain name :" + domain);
		int sslcalls = getStdParmValues(domain);
		generateReport(sslcalls > 0, getBoldText(domain) + " tracked Count:  " + sslcalls,
				getBoldText(domain) + " not tracked Count:  " + sslcalls);
		return sslcalls;
	}

	public int getStdParmValues(String domaine) {

		int noOfCalls = 0;
		try {
			Har har = getproxyServer().getHar();
			List<HarEntry> entries = har.getLog().getEntries();

			for (int i = 0; i < entries.size(); i++) {

				String requestUrl = entries.get(i).getRequest().getUrl();

				Logs.log(requestUrl);
				if (requestUrl.contains(domaine) || requestUrl.equals(domaine)) {
					noOfCalls = noOfCalls + 1;
					generateInfoReport(getBoldText(domaine) + "  tracked :" + requestUrl);
					// generateInfoReport("URL tracked : " + requestUrl);
				}

			}
			System.out.println("noOfCalls :" + noOfCalls);
		} catch (Exception e) {
			// Logs.info(e.getMessage());
		}
		return noOfCalls;
	}

	public Hashtable<String, String> verifyOmnitureAttributes(String domain, String omnitureAttributes) {

		Hashtable<String, String> stdValues = new Hashtable<>();
		String[] attributes = omnitureAttributes.split(",");
		String omnValuesNotTracked = null;
		boolean valueTracked = false;
		int loop = 0;
		while (!valueTracked) {
			String trackedCalls = "";
			try {

				Har har = getproxyServer().getHar();
				List<HarEntry> entries = har.getLog().getEntries();

				for (int i = 0; i < entries.size(); i++) {

					String requestUrl = entries.get(i).getRequest().getUrl();

					Logs.log(requestUrl);
					if (requestUrl.contains(domain)) {
						List<HarNameValuePair> harNameValuePairs = entries.get(i).getRequest().getQueryString();
						// Logs.logAndConsole(requestUrl);
						trackedCalls = trackedCalls + "<br>" + requestUrl;
						// Logs.logAndConsole(harNameValuePairs.toString());
						stdValues = new Hashtable<>();
						for (HarNameValuePair harNameValuePair : harNameValuePairs) {
							stdValues.put(harNameValuePair.getName(), harNameValuePair.getValue());
						}
						for (int j = 0; j < attributes.length; j++) {
							try {
								if (stdValues.get(attributes[j]).toString() != null)
									valueTracked = true;
							} catch (Exception e) {
								stdValues = new Hashtable<>();
							}

						}

					} // end of if

					if (valueTracked)
						break;
					else
						stdValues = new Hashtable<>();

				}
				loop++;
				if (loop > 2)
					break;

				if (valueTracked)
					break;

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		generateReport(valueTracked, domain + getBoldText(omnitureAttributes) + " tracked <br>" + stdValues.toString(),
				domain + getBoldText(omnitureAttributes) + " not tracked <br>" + stdValues.toString());
		return stdValues;
	}

	public boolean moveToElementandClick(By moveToLocator, By locator, String locatorName) {
		boolean flag = false;
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(moveToLocator)).build().perform();
			Thread.sleep(1000);
			click(locator, locatorName);
			flag = true;
		} catch (Exception e1) {
			try {
				click(moveToLocator, locatorName);
				click(locator, locatorName);
				flag = true;
			} catch (Exception e2) {

			}
		}
		return flag;
	}

	public boolean JavascriptmoveToElementandClick(By moveToLocator, By locator, String locatorName) {
		boolean flag = false;
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(moveToLocator)).build().perform();
			Thread.sleep(1000);
			// click(locator, locatorName);

			flag = true;
		} catch (Exception e1) {
			try {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				generateInfoReport("click Performed on" + locatorName);
				js.executeScript("arguments[0].click()", locator);
				flag = true;
			} catch (Exception e2) {

			}
		}
		return flag;
	}

	public boolean Dragprogressbar(By locator, int dragoffset) {
		boolean flag = false;

		try {

			WebElement sliderLocation = driver.findElement(locator);
			Actions action = new Actions(driver);
			action.dragAndDropBy(sliderLocation, dragoffset, dragoffset).build().perform();
			Thread.sleep(500);
			System.out.println("sliding completed");

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flag;
	}

	public void infositePollVerification(WebDriver driver, By by, By bySubMit, String environment) {
		infositePollSubmit(getDriver(), by, bySubMit, environment);
	}

	public void infositePollSubmit(WebDriver driver, By by, By bySubMit, String environment) {
		List<WebElement> elements = driver.findElements(by);
		startNewHar();
		Logs.logAndConsole("No of questions identified " + elements.size());
		generateInfoReport("No of questions identified " + elements.size());
		if (elements.size() > 0) {
			try {

				for (int i = 1; i <= elements.size(); i++) {
					scrollToObject(driver.findElement(By.xpath("(//*[@class='question-item'])[" + i + "]")));
					generatePassReportWithScreenShot("Below is the screenshot of Poll Question before submit");
					staticWait(2);
					driver.findElement(By.xpath("(//*[@class='question-item'][" + i + "]//label//div/span)[1]"))
							.click();
					generateInfoReport("Click Perfomed on First radio button of the Poll options");
				}
				// (//*[@class='questions-list']//ul//li//span)[1]

			} catch (Exception e) {
				e.getMessage();
				generateFailReport("Unable to Choose Poll ");
			}

			try {
				staticWait(2);
				driver.findElement(bySubMit).click();
				generateInfoReport("Click Perfomed on Poll Submit button");
				staticWait(3);
				verifyInfositeQuestionnaireID(environment);

			} catch (Exception e) {
				e.getMessage();
				generateFailReport("Unable to click on  Poll submit ");
			}
		} else {
			generateInfoReport("No Poll questions Present on current article Page");
		}

	}

	public void verifyInfositeQuestionnaireID(String environment) {
		// startNewHar();
		try {
			String domainName = "https://ssl.o.webmd.com/b/ss";
			String omnValue = "submit,qna";
			staticWait(2);
			scrollToObject(driver.findElement(By.xpath("//*[@class='question-item answered']")));
			generatePassReportWithScreenShot("Below is the screenshot of Poll submit results");
			verifySslCalls("www." + environment + "medscape.com/public/vptrack");
			verifySslCalls(
					"https://api." + environment + "medscape.com/servicegateway/v2/auth/qnaservice/questionnaire");
			verifyOmnitureValues(getproxyServer(), domainName, "mlink,mmodule,mpage,mpgtitle", omnValue,
					"equals,contains,notnull,notnull");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void VerifyinfositeArticlenavigationToHome(WebDriver driver, BrowserMobProxyServer server, String SFID,
			String env, String ProgramURL) throws Exception {
		generatePassReport(
				"================================================ Clicking on Articles_From Articles to Home ================================================");
		String winHandleBefore = driver.getWindowHandle();
		getDriver().get(ProgramURL);
		try {
			if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
				driver.findElement(InfositeObjectRepo.Iconsent).click();
			}
			if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
				driver.findElement(InfositeObjectRepo.accept).click();

			}

		} catch (Exception e) {

		}
		List<WebElement> allLinks = new ArrayList<>();

		List<WebElement> intialallLinks = driver.findElements(InfositeObjectRepo.allNavLinks);
		for (int l = 0; l < intialallLinks.size(); l++) {
			if (intialallLinks.get(l).getAttribute("href").contains("mailto")) {

			} else if (intialallLinks.get(l).isDisplayed()) {
				allLinks.add(intialallLinks.get(l));
			}
		}
		List<WebElement> allLinks_1 = new ArrayList<>();
		List<WebElement> intialallLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
		for (int k = 0; k < intialallLinks_1.size(); k++) {
			if (intialallLinks_1.get(k).getAttribute("href").contains("mailto")
					|| intialallLinks_1.get(k).getAttribute("href").contains("tel:")) {

			} else if (intialallLinks_1.get(k).isDisplayed()) {
				allLinks_1.add(intialallLinks_1.get(k));
			}
		}
		// *[@id='navigation-module']//a
		// List<WebElement> homepageArticles =
		// driver.findElements(By.xpath("//section[@class!='nav-buttons-container']//*[@data-module='RouterLink']"));

		List<WebElement> homepageArticles = driver.findElements(InfositeObjectRepo.HomepageLinks);
		if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
			if (homepageArticles.contains(driver.findElement(InfositeObjectRepo.registartionform))) {
				homepageArticles.remove(driver.findElement(InfositeObjectRepo.registartionform));// removing
																									// registartion form
																									// if it is present
																									// in home Page
			}
		}
		List<WebElement> homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);
		List<WebElement> navAndhomeLinks = new ArrayList<>();
		if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
			homepageArticlesnav.remove(driver.findElement(InfositeObjectRepo.registartionform));
		}
		for (int p = 0; p < homepageArticlesnav.size(); p++) {
			if (homepageArticlesnav.get(p).isDisplayed()) {
				navAndhomeLinks.add(homepageArticlesnav.get(p));
			}
		}

		if (homepageArticles.size() == 0 && allLinks.size() == 0 && homepageArticlesnav.size() == 0) {
			generateInfoReport("No Articles present in Infosite");
		}
		if (allLinks.size() > 0) {
			generatePassReport("No of Navigation link Articles available in Infosite are:  " + allLinks.size());
			String links = "";
			links = getAllLinksAndTitles(allLinks, links);
			if (allLinks.size() > 0) {
				generatePassReport("All Article Links and URL's: <br>" + links);
			}
		} else if (allLinks_1.size() > 0) {
			generatePassReport("No of Navigation link Articles available in Infosite are:  " + allLinks.size());
			String links_1 = "";
			links_1 = getAllLinksAndTitles(allLinks_1, links_1);
			if (allLinks_1.size() > 0) {
				generatePassReport("All Article Links and URL's: <br>" + links_1);
			}
		} else if (homepageArticlesnav.size() > 0) {

			generatePassReport("No of Navigation link Articles available in Infosite:  " + homepageArticlesnav.size());
			String hnlinks = "";
			hnlinks = getAllLinksAndTitles(homepageArticlesnav, hnlinks);
			if (homepageArticlesnav.size() > 0) {
				generatePassReport("All Article Links and URL's : <br>  " + hnlinks);
			}
		} else if (homepageArticles.size() > 0) {
			generatePassReport("No of Navigation link Articles available in Infosite:  " + homepageArticles.size());
			String hlinks = "";
			hlinks = getAllLinksAndTitles(homepageArticles, hlinks);
			if (homepageArticles.size() > 0) {
				generatePassReport("All Article Links and URL's :<br>" + hlinks);
			}
		}
		if (allLinks.size() > 0) {
			int k = allLinks.size() - 1;
			for (int i = k; i >= 0; i--) {

				try {
					if (allLinks.get(i).isDisplayed() && !allLinks.get(i).getAttribute("href").contains("mailto")) {
						server.newHar();

						generatePassReport(
								"************************************************************************************************");
						clickByWebElement(allLinks.get(i),
								getTextForReport(allLinks, i) + " : " + allLinks.get(i).getAttribute("href"));
						Thread.sleep(7000);
						allLinks = driver.findElements(InfositeObjectRepo.allNavLinks);
						String DestinationURL = getStdParmValuesForQueryString(server,
								"www." + env + "medscape.com/infosites/" + SFID + "/articles");
						if (allLinks.get(i).getAttribute("href").contains("article")) {
							Hashtable<String, String> trackermarker = getStdParmValues(server,
									"www." + env + "medscape.com/infosites/" + SFID + "/articles");

							generateReport(trackermarker.size() > 0 && DestinationURL != null,
									"Destination URL: " + getBoldText(DestinationURL),
									getBoldText(trackermarker.toString()));
						}
						Hashtable<String, String> hashtablefordestinationurlweblog = getMatchedParamURLInfositeNot(
								getproxyServer(), env, "www." + env + "medscape.com/public/vptrack.wxml", SFID,
								"nav-link");
						generateReport(hashtablefordestinationurlweblog.size() > 0,
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call  tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString(),
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString());
						Hashtable<String, String> hashtable = getMatchedParamURLInfosite(getproxyServer(), env,
								"ssl.o.webmd.com/b/ss/webmd", SFID, "mmodule");
						generateReport(hashtable.size() > 0, getBoldText("Attributes Tracked in 1st Ominiture  call:")
								+ "<br>" + getBoldText("g:") + hashtable.get("g") + "<br>" + getBoldText("mmodule :")
								+ hashtable.get("mmodule") + "<br>" + getBoldText("mpage:") + hashtable.get("mpage")
								+ "<br>" + getBoldText("lnktxt :") + hashtable.get("lnktxt") + "<br>"
								+ getBoldText("cstm :") + hashtable.get("cstm"),
								"Unable to Track ssl call with mmodule,mlink,mpage etc");
						verifyInfositenavLinkredirection(SFID, env);
						Hashtable<String, String> hashtablefordestinationurl = getMatchedParamURLInfosite(
								getproxyServer(), env, "ssl.o.webmd.com/b/ss/webmd", SFID, "c7");
						generateReport(hashtablefordestinationurl.size() > 0,
								getBoldText("Attributes Tracked in 2nd  Ominiture call:") + "<br>" + getBoldText("g:")
										+ hashtablefordestinationurl.get("g") + "<br>" + getBoldText("pageName :")
										+ hashtablefordestinationurl.get("pageName"),
								"Unable to Track 2nd  ssl call");

					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else if (allLinks_1.size() > 0) {
			for (int i = allLinks_1.size() - 1; i >= 0; i--) {
				try {

					if (allLinks_1.get(i).isDisplayed() && !allLinks_1.get(i).getAttribute("href").contains("mailto")) {
						server.newHar();
						generatePassReport(
								"************************************************************************************************");
						clickByWebElement(allLinks_1.get(i),
								getTextForReport(allLinks_1, i) + " : " + allLinks_1.get(i).getAttribute("href"));
						Thread.sleep(7000);
						allLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
						String DestinationURL = getStdParmValuesForQueryString(server,
								"www." + env + "medscape.com/infosites/" + SFID + "/articles");
						if (allLinks_1.get(i).getAttribute("href").contains("article")) {
							Hashtable<String, String> trackermarker = getStdParmValues(server,
									"www." + env + "medscape.com/infosites/" + SFID + "/articles");

							generateReport(trackermarker.size() > 0 && DestinationURL != null,
									"Destination URL: " + getBoldText(DestinationURL),
									getBoldText(trackermarker.toString()));
						}
						Hashtable<String, String> hashtablefordestinationurlweblog = getMatchedParamURLInfositeNot(
								getproxyServer(), env, "www." + env + "medscape.com/public/vptrack.wxml", SFID,
								"nav-link");
						generateReport(hashtablefordestinationurlweblog.size() > 0,
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call  tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString(),
								getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
										+ " <br>" + hashtablefordestinationurlweblog.toString());
						Hashtable<String, String> hashtable = getMatchedParamURLInfosite(getproxyServer(), env,
								"ssl.o.webmd.com/b/ss/webmd", SFID, "mmodule");
						generateReport(hashtable.size() > 0, getBoldText("Attributes Tracked in 1st Ominiture  call:")
								+ "<br>" + getBoldText("g:") + hashtable.get("g") + "<br>" + getBoldText("mmodule :")
								+ hashtable.get("mmodule") + "<br>" + getBoldText("mpage:") + hashtable.get("mpage")
								+ "<br>" + getBoldText("lnktxt :") + hashtable.get("lnktxt") + "<br>"
								+ getBoldText("cstm :") + hashtable.get("cstm"),
								"Unable to Track ssl call with mmodule,mlink,mpage etc");
						verifyInfositenavLinkredirection(SFID, env);
						Hashtable<String, String> hashtablefordestinationurl = getMatchedParamURLInfosite(
								getproxyServer(), env, "ssl.o.webmd.com/b/ss/webmd", SFID, "c7");
						generateReport(hashtablefordestinationurl.size() > 0,
								getBoldText("Attributes Tracked in 2nd  Ominiture call:") + "<br>" + getBoldText("g:")
										+ hashtablefordestinationurl.get("g") + "<br>" + getBoldText("pageName :")
										+ hashtablefordestinationurl.get("pageName"),
								"Unable to Track 2nd  ssl call");

					}
				} catch (Exception e) {
					e.printStackTrace();
					Logs.log(e.getMessage());
				}
			}
		} else if (homepageArticlesnav.size() > 0) {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			for (int o = homepageArticlesnav.size() - 1; o >= 0; o--) {
				server.newHar();
				generatePassReport(
						"*****************************************************************************************************************************************************");
				generateInfoReport("Click Performed on article:  " + getBoldText(homepageArticlesnav.get(o).getText())
						+ "  :" + homepageArticlesnav.get(o).getAttribute("href"));
				executor.executeScript("arguments[0].click();", homepageArticlesnav.get(o));
				staticWait(3);
				Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
						"www." + env + "medscape.com/public/vptrack.wxml");
				generateReport(hashtable.size() > 0 && hashtable.toString().contains(SFID),
						getBoldText("Web log Call:www." + env + "medscape.com/public/vptrack.wxml call  tracked")
								+ " <br>" + hashtable.toString(),
						getBoldText(
								"Web log Call:www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
								+ " <br>" + hashtable.toString());

				staticWait(3);
				Hashtable<String, String> hashtablessl = getStdParmValues(getproxyServer(),
						"ssl.o.webmd.com/b/ss/webmd");
				generateReport(hashtablessl.size() > 0, getBoldText("Attributes Tracked in  Ominiture call:") + "<br>"
						+ getBoldText("g:") + hashtablessl.get("g") + "<br>" + getBoldText("pageName :")
						+ hashtablessl.get("pageName") + "<br>" + getBoldText("pid :") + hashtablessl.get("pid"),
						"Unable to Track ssl ominiture call");
				getDriver().navigate().back();
				try {
					if (driver.findElements(By.className("accept-button")).size() > 0) {
						driver.findElement(By.className("accept-button")).click();
					}
					if (driver.findElements(By.className("accept")).size() > 0) {
						driver.findElement(By.className("accept")).click();

					}

				} catch (Exception e) {

				}
				staticWait(2);
				navAndhomeLinks.clear();
				homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);

				if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
					homepageArticlesnav.remove(driver.findElement(InfositeObjectRepo.registartionform));
				}
				for (int p = 0; p < homepageArticlesnav.size(); p++) {
					if (homepageArticlesnav.get(p).isDisplayed()) {
						navAndhomeLinks.add(homepageArticlesnav.get(p));
					}
				}

			}
			homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);
			generateInfoReport("Click Performed on article:" + homepageArticlesnav.get(0).getText() + ":"
					+ homepageArticlesnav.get(0).getAttribute("href"));
			executor.executeScript("arguments[0].click();", homepageArticlesnav.get(0));
			staticWait(3);
			getDriver().navigate().refresh();
			staticWait(2);
			try {
				if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
					driver.findElement(InfositeObjectRepo.Iconsent).click();
				}
				if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
					driver.findElement(InfositeObjectRepo.accept).click();

				}

			} catch (Exception e) {

			}

			staticWait(2);
			List<WebElement> navLinksMenufinal = new ArrayList<>();
			List<WebElement> navLinksMenu = driver.findElements(InfositeObjectRepo.allNavLinks);
			for (int u = 0; u < navLinksMenu.size(); u++) {
				if (navLinksMenu.get(u).isDisplayed()) {
					navLinksMenufinal.add(navLinksMenu.get(u));
				}
			}
			staticWait(2);
			generatePassReport(
					"****************************************Started Verification for Navigation Menu Links****************************************");
			for (int y = navLinksMenufinal.size() - 1; y >= 0; y--) {
				startNewHar();
				String homeart = navLinksMenufinal.get(y).getAttribute("href");
				generatePassReport(
						"*********************************************************************************************************************************************************");
				generateInfoReport("Click Performed on article:" + navLinksMenufinal.get(y).getText() + ":"
						+ navLinksMenufinal.get(y).getAttribute("href"));
				executor.executeScript("arguments[0].click();", navLinksMenufinal.get(y));
				staticWait(3);
				if (homeart.contains("article")) {
					String DestinationURL = getStdParmValuesForQueryString(server,
							"www." + env + "medscape.com/infosites/" + SFID + "/articles");
					Hashtable<String, String> trackermarker = getStdParmValues(server,
							"www." + env + "medscape.com/infosites/" + SFID + "/articles");

					generateReport(trackermarker.size() > 0 && DestinationURL != null,
							"Destination URL: " + getBoldText(DestinationURL), getBoldText(trackermarker.toString()));
				}
				Hashtable<String, String> hashtablefordestinationurlweblog = getMatchedParamURLInfositeNot(
						getproxyServer(), env, "www." + env + "medscape.com/public/vptrack.wxml", SFID, "nav-link");
				generateReport(hashtablefordestinationurlweblog.size() > 0,
						getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call  tracked") + " <br>"
								+ hashtablefordestinationurlweblog.toString(),
						getBoldText("www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked") + " <br>"
								+ hashtablefordestinationurlweblog.toString());
				Hashtable<String, String> hashtable = getMatchedParamURLInfosite(getproxyServer(), env,
						"ssl.o.webmd.com/b/ss/webmd", SFID, "mmodule");
				generateReport(hashtable.size() > 0,
						getBoldText("Attributes Tracked in 1st Ominiture  call:") + "<br>" + getBoldText("g:")
								+ hashtable.get("g") + "<br>" + getBoldText("mmodule :") + hashtable.get("mmodule")
								+ "<br>" + getBoldText("mpage:") + hashtable.get("mpage") + "<br>"
								+ getBoldText("lnktxt :") + hashtable.get("lnktxt") + "<br>" + getBoldText("cstm :")
								+ hashtable.get("cstm"),
						"Unable to Track ssl call with mmodule,mlink,mpage etc");
				verifyInfositenavLinkredirection(SFID, env);
				Hashtable<String, String> hashtablefordestinationurl = getMatchedParamURLInfosite(getproxyServer(), env,
						"ssl.o.webmd.com/b/ss/webmd", SFID, "c7");
				generateReport(hashtablefordestinationurl.size() > 0,
						getBoldText("Attributes Tracked in 2nd  Ominiture call:") + "<br>" + getBoldText("g:")
								+ hashtablefordestinationurl.get("g") + "<br>" + getBoldText("pageName :")
								+ hashtablefordestinationurl.get("pageName"),
						"Unable to Track 2nd  ssl call");
				navLinksMenufinal.clear();
				navLinksMenu = driver.findElements(InfositeObjectRepo.allNavLinks);
				for (int q = 0; q < navLinksMenu.size(); q++) {
					/*
					 * if(!navLinksMenu.get(q).getAttribute("href").contains("isarticle")) { }else
					 */

					if (navLinksMenu.get(q).isDisplayed()) {
						navLinksMenufinal.add(navLinksMenu.get(q));
					}
				}
			}
		} else if (homepageArticles.size() > 0) {
			for (int m = homepageArticles.size() - 1; m >= 0; m--) {
				try {
					if (homepageArticles.get(m).isDisplayed()) {
						server.newHar();
						generatePassReport(
								"*****************************************************************************************************************************************************");
						// clickByWebElement(homepageArticles.get(m),getTextForReport(homepageArticles,
						// m) + " : " + homepageArticles.get(m).getAttribute("href"));
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						generateInfoReport("Click Performed on article:" + homepageArticles.get(m).getText() + ":"
								+ homepageArticles.get(m).getAttribute("href"));
						executor.executeScript("arguments[0].click();", homepageArticles.get(m));
						staticWait(6);
						homepageArticles = driver.findElements(InfositeObjectRepo.HomepageLinks);
						if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
							if (homepageArticles.contains(driver.findElement(InfositeObjectRepo.registartionform))) {
								homepageArticles.remove(driver.findElement(InfositeObjectRepo.registartionform));// removing
																													// reg
																													// form

							}
						}
						Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
								"www." + env + "medscape.com/public/vptrack.wxml");
						generateReport(hashtable.size() > 0 && hashtable.toString().contains(SFID),
								getBoldText(
										"Web log Call:www." + env + "medscape.com/public/vptrack.wxml call  tracked")
										+ " <br>" + hashtable.toString(),
								getBoldText("Web log Call:www." + env
										+ "medscape.com/public/vptrack.wxml weblog call not tracked") + " <br>"
										+ hashtable.toString());
						staticWait(6);
						Hashtable<String, String> hashtablessl = getStdParmValues(getproxyServer(),
								"ssl.o.webmd.com/b/ss/webmd");
						generateReport(hashtablessl.size() > 0,
								getBoldText("Attributes Tracked in  Ominiture call:") + "<br>" + getBoldText("g:")
										+ hashtablessl.get("g") + "<br>" + getBoldText("pageName :")
										+ hashtablessl.get("pageName") + "<br>" + getBoldText("pid :")
										+ hashtablessl.get("pid"),
								"Unable to Track ssl ominiture call");
					}

				} catch (Exception e) {
					e.printStackTrace();
					Logs.log(e.getMessage());
				}

			}
		}
	}

	public boolean VerifyinfositeNextLink(WebDriver driver, BrowserMobProxyServer server, String SFID, String env)
			throws Exception {
		boolean Flag = false;
		startNewHar();
		if (driver.findElements(InfositeObjectRepo.Next_Link_withinArticle).size() > 0) {

			if (driver.findElements(InfositeObjectRepo.Next_Link_withinArticle).size() > 0
					&& driver.findElements(InfositeObjectRepo.backbtn).size() > 0) {

				generateInfoReport("Back Button is displayed on Current article Page: "+getBoldText(driver.getCurrentUrl()));
				Flag = false;
				return Flag;
			} else {
				generatePassReport("Next Button is Available on current Page : "+getBoldText(driver.getCurrentUrl()));
				scrollToObject(driver.findElement(InfositeObjectRepo.Next_Link_withinArticle));
				generatePassReportWithScreenShot("Below Screenshot of Next Link");
				moveToElementandClick(InfositeObjectRepo.Next_Link_withinArticle,
						InfositeObjectRepo.Next_Link_withinArticle, "Next Article");
				staticWait(6);
				Hashtable<String, String> hashtable = getStdParmValues(getproxyServer(),
						"www." + env + "medscape.com/public/vptrack.wxml");
				generateReport(hashtable.size() > 0 && hashtable.toString().contains(SFID),
						getBoldText("Web log Call:www." + env + "medscape.com/public/vptrack.wxml call  tracked")
								+ " <br>" + hashtable.toString(),
						getBoldText(
								"Web log Call:www." + env + "medscape.com/public/vptrack.wxml weblog call not tracked")
								+ " <br>" + hashtable.toString());
				Thread.sleep(5000);
				Hashtable<String, String> hashtablessl = getStdParmValues(getproxyServer(),
						"ssl.o.webmd.com/b/ss/webmd");
				generateReport(hashtablessl.size() > 0, getBoldText("Attributes Tracked in  Ominiture call:") + "<br>"
						+ getBoldText("g:") + hashtablessl.get("g") + "<br>" + getBoldText("pageName :")
						+ hashtablessl.get("pageName") + "<br>" + getBoldText("pid :") + hashtablessl.get("pid"),
						"Unable to Track ssl ominiture call");
				hashtable.clear();
				hashtablessl.clear();
				Flag = true;
				return Flag;
			}
		} else {
			generateInfoReport("In Current Article Page:"+getBoldText(driver.getCurrentUrl())+"  There is no 'Next' Link Available to navigate to Next Article Page");
			return Flag;
		}
		

	}

	public void VerifyinfositeWithinArticlenavigation(WebDriver driver, BrowserMobProxyServer server, String SFID,
			String env, String url) throws Exception {
		driver.get(url);
		boolean isNextPresent = false;
		staticWait(6);
		driver.manage().window().maximize();
		try {
			if (driver.findElements(InfositeObjectRepo.Iconsent).size() > 0) {
				driver.findElement(InfositeObjectRepo.Iconsent).click();
			}
			if (driver.findElements(InfositeObjectRepo.accept).size() > 0) {
				driver.findElement(InfositeObjectRepo.accept).click();
			}
		} catch (Exception e) {

		}
		staticWait(2);
		List<WebElement> intialallLinks = driver.findElements(InfositeObjectRepo.allNavLinks);
		List<WebElement> articles = new ArrayList<>();
		for (int l = 0; l < intialallLinks.size(); l++) {

			if (intialallLinks.get(l).isDisplayed()&&(!intialallLinks.get(l).getAttribute("href").contains("mailto")||!intialallLinks.get(l).getAttribute("href").contains("tel:"))) {
				articles.add(intialallLinks.get(l));
			}
		}
		List<WebElement> allLinks_1 = new ArrayList<>();
		List<WebElement> intialallLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
		for (int m = 0; m < intialallLinks_1.size(); m++) {
			if (intialallLinks_1.get(m).getAttribute("href").contains("mailto")
					|| intialallLinks_1.get(m).getAttribute("href").contains("tel:")||!intialallLinks_1.get(m).getAttribute("href").contains("article")) {

			} else if (intialallLinks_1.get(m).isDisplayed()) {
				allLinks_1.add(intialallLinks_1.get(m));
			}
		}
		
		List<WebElement> homepageArticlesnav = driver.findElements(InfositeObjectRepo.homepageAndNav);
		List<WebElement> navAndhomeLinks = new ArrayList<>();
		if (driver.findElements(InfositeObjectRepo.registartionform).size() > 0) {
			homepageArticlesnav.remove(driver.findElement(InfositeObjectRepo.registartionform));
		}
		for (int p = 0; p < homepageArticlesnav.size(); p++) {
			if (homepageArticlesnav.get(p).isDisplayed()) {
				navAndhomeLinks.add(homepageArticlesnav.get(p));
			}
		}
		if (articles.size() > 0) {
			for (int k = 0; k < articles.size(); k++) {
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				if (articles.get(k).getAttribute("href").contains("article")) {
					generateInfoReport("click performed on  :" + getBoldText(articles.get(k).getAttribute("href")));
					executor.executeScript("arguments[0].click();", articles.get(k));
					staticWait(6);

				}
				while (VerifyinfositeNextLink(driver, server, SFID, env)) {
					generateInfoReport(
							"**************************************************************************************************************");
				k++;
				
				}

				try {
					intialallLinks = driver.findElements(InfositeObjectRepo.allNavLinks);
					articles = new ArrayList<>();
					for (int w = 0; w< intialallLinks.size(); w++) {

						if (intialallLinks.get(w).isDisplayed()&&(!intialallLinks.get(w).getAttribute("href").contains("mailto")||!intialallLinks.get(w).getAttribute("href").contains("tel:"))) {
							articles.add(intialallLinks.get(w));
						}
					}
				} catch (Exception e) {

				}

			}
		}else if(allLinks_1.size()>0) {
			for (int k = 0; k < allLinks_1.size(); k++) {
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				if (allLinks_1.get(k).getAttribute("href").contains("article")) {
					generateInfoReport("click performed on  :" + getBoldText(allLinks_1.get(k).getAttribute("href")));
					executor.executeScript("arguments[0].click();", allLinks_1.get(k));
					staticWait(6);

				}
				while (VerifyinfositeNextLink(driver, server, SFID, env)) {
					generateInfoReport(
							"**************************************************************************************************************");
				k++;
				
				}
				try {
					intialallLinks_1 = driver.findElements(InfositeObjectRepo.allNavLinks_1);
					allLinks_1 = new ArrayList<>();
					for (int w = 0; w< intialallLinks_1.size(); w++) {

						if (intialallLinks_1.get(w).isDisplayed()&&(!intialallLinks_1.get(w).getAttribute("href").contains("mailto")||!intialallLinks_1.get(w).getAttribute("href").contains("tel:"))) {
							allLinks_1.add(intialallLinks.get(w));
						}
					}
				} catch (Exception e) {

				}
				

			}
			
		}else if(navAndhomeLinks.size()>0) {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", navAndhomeLinks.get(1));
			List<WebElement> navLinksMenufinal = new ArrayList<>();
			List<WebElement> navLinksMenu = driver.findElements(InfositeObjectRepo.allNavLinks);
			for (int u = 0; u < navLinksMenu.size(); u++) {
				if (navLinksMenu.get(u).isDisplayed()&&(!navLinksMenu.get(u).getAttribute("href").contains("mailto")||!navLinksMenu.get(u).getAttribute("href").contains("tel:"))) {
					navLinksMenufinal.add(navLinksMenu.get(u));
				}
		}
if(navLinksMenufinal.size()>0) {
	for (int k = 0; k < navLinksMenufinal.size(); k++) {
		JavascriptExecutor executorjs = (JavascriptExecutor) driver;
		if (navLinksMenufinal.get(k).getAttribute("href").contains("article")) {
			generateInfoReport("click performed on  :" + getBoldText(navLinksMenufinal.get(k).getAttribute("href")));
			executorjs.executeScript("arguments[0].click();", navLinksMenufinal.get(k));
			staticWait(6);

		}
		while (VerifyinfositeNextLink(driver, server, SFID, env)) {
			generateInfoReport(
					"**************************************************************************************************************");
		k++;
		
		}
		try {
			navLinksMenufinal.clear();
			navLinksMenu.clear();
			navLinksMenu = driver.findElements(InfositeObjectRepo.allNavLinks);
			
			for (int w = 0; w< intialallLinks_1.size(); w++) {

				if (navLinksMenu.get(w).isDisplayed()&&(!navLinksMenu.get(w).getAttribute("href").contains("mailto")||!navLinksMenu.get(w).getAttribute("href").contains("tel:"))) {
					navLinksMenufinal.add(navLinksMenu.get(w));
				}
			}
		} catch (Exception e) {

		}
		

	}
}
			
	}

}
}

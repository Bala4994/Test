package com.webmd.automation.utilities;
import java.io.IOException;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import org.apache.commons.codec.binary.Base64;

/**
 * Java program to encode and decode String in Java using Base64 encoding algorithm
 * @author
 */
public class PasswordEncoder{

    public static void main(String args[]) throws IOException {
    	
    	JPasswordField pf = new JPasswordField();
		int okCxl = JOptionPane.showConfirmDialog(null, pf, "Enter Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		 String testdata="";
		if (okCxl == JOptionPane.OK_OPTION) {
		 testdata = new String(pf.getPassword());
		  //System.err.println("You entered: " + password);
		}
        String orig = testdata;

        //encoding  byte array into base 64
        byte[] encoded = Base64.encodeBase64(orig.getBytes());     
      
        System.out.println("Original String: " + orig );
        System.out.println("Encoded String : " + new String(encoded));
      
        //decoding byte array into base64
        byte[] decoded = Base64.decodeBase64(encoded);      
        System.out.println("Decoded  String : " + new String(decoded));

    }
}
